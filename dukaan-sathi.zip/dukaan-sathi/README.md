# Dukaan Sathi · दुकान साथी

**From order to delivery, everyone stays in the loop.**

Dukaan Sathi is a coordination platform for small hardware retailers and building-material distributors in India.
Both sides work from **one shared, traceable order record**: what was requested, confirmed, dispatched, received and
how any difference was resolved. Orders can be placed and questioned in **English or Hindi**, by typing or by voice.
Every answer comes from a **real MCP server** (Streamable HTTP), the same one that powers the website.

> Hackathon prototype. *Raj Hardware Store* and *Sharma Building Supplies* are fictional, and all orders are
> synthetic sample data. Prices and stock levels are illustrative, not market quotes.

![DS-1042: 50 dispatched, 48 received, two-bag discrepancy flagged](docs/screenshots/ds-1042-discrepancy.png)

---

## What is real in this repository

| | |
|---|---|
| ✅ **MCP server** | Official MCP Python SDK (`mcp` 2.3.0, `MCPServer`), **Streamable HTTP** at `http://127.0.0.1:8001/mcp`. 15 typed tools with structured output. Negotiates **2025-11-25** through the initialize handshake (and 2026-07-28 for clients that ask). Bearer-token auth, DNS-rebinding protection, rate limit. |
| ✅ **Website → MCP** | React → FastAPI gateway → **real MCP client** over Streamable HTTP → MCP server → SQLite. The gateway reads no business data itself. Every response carries the MCP tool trace, and the UI shows it. |
| ✅ **Order lifecycle** | Draft → submit → confirm (full or partial) → dispatch (challan, e-way bill, vehicle) → receipt (line by line, damage, photo) → automatic comparison → notes, acknowledgement → resolution. Every step is a timestamped audit event. |
| ✅ **Discrepancy logic** | Deterministic: confirmed → dispatched → received in one canonical unit. Short, excess and damaged quantities are flagged without assigning blame. Originals are never overwritten. |
| ✅ **Bilingual assistant** | Rule-based English, Hindi (Devanagari) and Hinglish intent parser. It calls MCP tools and answers in the user's language. Writes always need confirmation. **No external LLM is connected.** |
| ✅ **Voice experience** | Alexa-*inspired* web simulator (Web Speech API, en-IN / hi-IN, text-to-speech) calling the same MCP tools. |
| ✅ **Alexa custom skill** | `POST /alexa` with Amazon signature verification, plus interaction models for **en-IN and hi-IN**. You can connect it to your own Echo (e.g. Echo Plus 2nd gen, L9D29R) in development mode. Steps: [docs/alexa-echo-setup.md](docs/alexa-echo-setup.md). It needs your own free Amazon developer account and a tunnel; **I could not test it on a physical device from the build environment.** |
| ⚠️ **Not included** | Live GPS, real distributor/billing integrations, production authentication, gated Alexa+ add-on tooling. |

## Architecture

```mermaid
flowchart LR
  subgraph Clients
    W[React website :5173<br/>dashboard · orders · assistant · voice demo]
    E[Echo device<br/>Alexa custom skill en-IN / hi-IN]
    X[Any MCP client<br/>MCP Inspector · scripts/mcp_smoke_test.py]
  end
  W -- REST/JSON --> G
  E -- HTTPS tunnel --> G
  G[FastAPI API gateway :8000<br/>assistant · Alexa verification · demo reset]
  G -- MCP client · Streamable HTTP<br/>Bearer token · protocol 2025-11-25 --> M
  X -- Streamable HTTP + token --> M
  M[MCP server :8001/mcp<br/>15 tools · official Python SDK] --> S[Business services<br/>units · state machine · comparison · permissions]
  S --> D[(SQLite<br/>orders · dispatches · receipts<br/>discrepancies · audit events)]
```

More detail: [docs/architecture.md](docs/architecture.md).

---

## Quick start on Windows (one command)

**Prerequisites:** Python **3.13** (3.11–3.14 work; 3.13 is what this was tested with), Node.js **22 LTS** (≥ 20.19),
and Git or the downloaded folder. Docker is not needed.

```powershell
cd dukaan-sathi
powershell -ExecutionPolicy Bypass -File .\run-demo.ps1
```

On the first run this creates `backend\.venv`, installs the Python and npm packages, copies `.env.example` to `.env`,
starts the three services in separate windows, checks their health endpoints and opens the browser.

| Service | URL |
|---|---|
| Website | http://127.0.0.1:5173 (landing) · http://127.0.0.1:5173/app (demo) |
| API gateway | http://127.0.0.1:8000/api/health |
| MCP server | **http://127.0.0.1:8001/mcp** (health: http://127.0.0.1:8001/health) |
| Alexa endpoint | http://127.0.0.1:8000/alexa (public only through a tunnel) |

Stop everything: `powershell -ExecutionPolicy Bypass -File .\stop-demo.ps1`

Optional: download local copies of the photos with `powershell -ExecutionPolicy Bypass -File .\scripts\fetch-photos.ps1`.
Without them the site loads the photos from the Pexels CDN, or shows an illustration if you're offline.

### Manual setup (step by step)

```powershell
# 1-3. Environment and backend dependencies
cd dukaan-sathi
copy .env.example .env
py -3.13 -m venv backend\.venv
backend\.venv\Scripts\python.exe -m pip install -r backend\requirements-dev.txt

# 4-5. Database initialisation and seeding (also happens automatically on first start)
cd backend
.\.venv\Scripts\python.exe -m app.seed full

# 6. MCP server (window 1, from backend\)
.\.venv\Scripts\python.exe -m app.mcp_server.server

# 7. API gateway (window 2, from backend\)
.\.venv\Scripts\python.exe -m app.gateway.main

# 8. Website (window 3, from frontend\)
cd ..\frontend
npm install
npm run dev

# 9. Open http://127.0.0.1:5173
```

10. **Test a real MCP tool call:** see [below](#testing-a-real-mcp-tool-call).
11. **Reset the demo:** website → *Demo controls*, or `.\.venv\Scripts\python.exe -m app.seed live` (or `full`) in `backend\`.
12. **Stop:** close the three windows (Ctrl+C), or run `stop-demo.ps1`.

If `py -3.13` isn't available, use `python -m venv backend\.venv` with any Python 3.11–3.14. All dependencies are
pinned to versions with Windows wheels (plain `uvicorn`, no compiled extras). If a package ever fails to build on
Python 3.14, install Python 3.13 and re-run with `-Install`.

---

## Demonstrate the 50-versus-48 discrepancy

1. **Demo controls → "Reset for live recording & open DS-1042".** DS-1042 is *in transit*: 50 bags of OPC 53 cement
   confirmed and dispatched under challan `SBS/DC/26-27/0412`.
2. As **Raj Hardware Store** (retailer), click **Record receipt**, enter **48**, click **Review**, then **Record receipt**.
3. The MCP tool `record_delivery` compares the quantities and opens **DSC-2004 — short delivery, 2 bags**:
   *"Received quantity is 2 bags below the recorded dispatched quantity… Cause not yet determined."* New timeline
   events are highlighted, and the dashboard now shows 4 in transit / 2 need review.
4. Switch the role to **Sharma Building Supplies** (sidebar): same order, same numbers. **Acknowledge / add note**.
5. Open **Voice experience** and ask *"What happened to DS-1042?"* or *"मेरी सीमेंट डिलीवरी चेक करो"*.
6. **Record resolution** ("Remaining 2 bags to be supplied with the next dispatch"). The order becomes *Delivered ·
   resolved*, and 50 / 50 / 48 stay exactly as recorded.

The "full" reset gives the specified starting dashboard: **12 orders · 4 in transit · 2 need review · 6 delivered**.

## Check that the website really calls MCP over Streamable HTTP

* **On every page:** the dashed *"Served by MCP tool …"* strip shows the tool name, transport (`streamable-http`), negotiated protocol (`2025-11-25`) and timing.
  Expand it for inputs and results.
* **MCP activity** (bottom-right button) and **MCP console** (`/app/mcp`): a live log of every call the gateway makes, tagged *Website / Assistant / Voice demo / Alexa (Echo)*, plus the tool list from `tools/list`.
* **Stop the MCP server window.** The header indicator turns red, pages show *"Cannot reach the MCP server"* with a Retry button, and the assistant says it can't look up records. Start it again and everything recovers.
* **Server log:** the MCP server window prints `POST /mcp` for every website action.
* **Audit trail:** writes are performed by the MCP server and tagged with the caller's channel. Timeline entries show *Website*, *Voice demo*, *Alexa (Echo)* or *MCP client*.

## Testing a real MCP tool call

**Python client (no website involved):**

```powershell
backend\.venv\Scripts\python.exe scripts\mcp_smoke_test.py
```

It connects to `http://127.0.0.1:8001/mcp`, lists the 15 tools, runs a read (`get_order_status DS-1042`), a safe write
(`create_draft_order`: a 1-bag draft only the retailer sees), and shows a rejected write (retailer calling `record_dispatch`).

**MCP Inspector:** `npx @modelcontextprotocol/inspector` → Transport *Streamable HTTP* → URL `http://127.0.0.1:8001/mcp` →
Authentication → Bearer token `local-dev-retailer-token` (or `local-dev-distributor-token` for distributor tools) → Connect → Tools.

**Raw JSON-RPC (PowerShell):**

```powershell
$h = @{ Authorization = "Bearer local-dev-retailer-token"; Accept = "application/json, text/event-stream"; "MCP-Protocol-Version" = "2025-11-25" }
$body = '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"get_order_status","arguments":{"order_id":"DS-1042"}}}'
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8001/mcp -Headers $h -ContentType "application/json" -Body $body
```

Requests without a valid token get `401`. The token decides the role, and the service layer enforces it: the website
hides buttons too, but that is not what keeps a retailer from dispatching.

## MCP tools

| Tool | Who | What it does |
|---|---|---|
| `search_products` | any | Catalogue search by words (English/Hindi), category, size, grade or SKU. Flags ambiguity (e.g. "cement" → 3 grades). |
| `create_draft_order` | retailer | Validated draft from SKUs, quantities and units. |
| `validate_order` | any | Specs, units, quantity format, partial availability. Read-only. |
| `submit_order` | retailer | Sends a reviewed draft to the distributor. |
| `confirm_order` | distributor | Confirms full or partial quantities, optional revised date. |
| `list_orders` | any | Filters: status, unresolved difference, search, category, dates. |
| `get_order_status` | any | Full order record with the per-line comparison. |
| `get_order_timeline` | any | Chronological audit events with actor and channel. |
| `list_discrepancies` | any | Differences with notes and resolutions. |
| `get_dashboard_summary` | any | Counts computed from persisted records. |
| `record_dispatch` | distributor | Challan, quantities, e-way bill, vehicle, expected date (milestones, no GPS). |
| `record_delivery` | retailer | Counted quantities per line + damage; opens discrepancies automatically. |
| `report_discrepancy` | both | Manual report after receipt (e.g. damage found later). |
| `add_discrepancy_note` | both | Note or formal acknowledgement. |
| `resolve_discrepancy` | both | Resolution on top of preserved evidence; `under_review` keeps it open. |

Errors are consistent JSON: `{"error": {"code": "not_found | validation_failed | permission_denied | invalid_state_transition", "message": "...", "message_hi": "...", "details": {...}}}`.

## Hindi and English

* The **English / हिन्दी** toggle switches the whole interface (stored per browser).
* The assistant and voice demo understand Devanagari Hindi, Hinglish and English, for example: *"ऑर्डर DS-1042 कहाँ है?"*,
  *"किन ऑर्डर में कमी है?"*, *"OPC 53 सीमेंट की पचास बोरी ऑर्डर कर दो"*, *"mera order 1042 kahan hai"*, *"मेरी दुकान का हिसाब बताओ"* (shop summary).
* Trade vocabulary is mapped deliberately: *बोरी / कट्टा* → bags, *सरिया* → TMT bar, *पीस / नग* → pieces, *किलो* → kg.
* Voice input uses the browser's `hi-IN` / `en-IN` recognition (Chrome or Edge). Typed input always works.

## Alexa

* **Web simulator:** `/app/voice`, *"Dukaan Sathi Voice Experience"*. It is an independent prototype, not an Amazon product.
* **Your Echo (optional):** the repo includes a complete custom skill (`alexa/skill-package/`, en-IN + hi-IN) and a
  signature-verified endpoint. Follow [docs/alexa-echo-setup.md](docs/alexa-echo-setup.md). When it is connected, calls from
  the Echo appear live on the website tagged **Alexa (Echo)**.
* **Alexa+ MCP add-ons:** the hackathon FAQ says some gated Alexa+ add-on tools are not available to participants.
  This project does not claim an Alexa+ connection. See [docs/alexa-echo-setup.md](docs/alexa-echo-setup.md#alexa-mcp-pathway).
* Test the skill logic without an Amazon account: `backend\.venv\Scripts\python.exe scripts\alexa_local_test.py`.

## Remote access (optional)

The MCP endpoint and the Alexa endpoint can be exposed over HTTPS with a tunnel such as Cloudflare Tunnel. Read
[docs/remote-deployment.md](docs/remote-deployment.md) first: set real tokens, never expose the database, and expect
quick-tunnel URLs to change on every restart.

## Tests

```powershell
cd backend
.\.venv\Scripts\python.exe -m pytest -q
```

40 tests cover catalogue lookup, draft persistence, invalid specs, unit safety and explicit conversions, confirmation,
dispatch, receipt, the 50→48 discrepancy, no shortage on equal quantities, excess detection, no blame attribution,
history preservation on resolution, invalid transitions and permissions, dashboard counts, MCP tool discovery with an
independent client, real MCP tool calls and role enforcement, the website API calling MCP over Streamable HTTP, MCP
outage handling, bilingual intent parsing, Alexa verification helpers and the Alexa handler end to end.

## Project structure

```
dukaan-sathi/
├─ backend/
│  ├─ app/
│  │  ├─ config.py, db.py, seed.py      # settings, SQLite schema, synthetic dataset
│  │  ├─ domain/                        # rules (units, comparison), models, actors/permissions, errors
│  │  ├─ services/                      # catalog, order lifecycle, dashboard
│  │  ├─ mcp_server/server.py           # MCP server (Streamable HTTP, 15 tools, auth)
│  │  └─ gateway/                       # FastAPI app, MCP client, assistant (nlu/engine), alexa (handler/verifier)
│  ├─ tests/                            # pytest suite
│  └─ requirements*.txt
├─ frontend/                            # React 19 + TypeScript + Vite 8 + Tailwind 4
├─ alexa/skill-package/                 # skill.json + interaction models (en-IN, hi-IN); alexa/test-requests/
├─ scripts/                             # mcp_smoke_test.py, alexa_local_test.py, fetch-photos.ps1
├─ docs/                                # architecture, demo script, Alexa setup, deployment, sources, screenshots
├─ data/                                # SQLite database (created at first start)
├─ run-demo.ps1 / stop-demo.ps1
├─ SUBMISSION.md · LICENSE (MIT) · .env.example
```

## Security notes

* Demo roles are simulated: a bearer token maps to one of two fictional businesses. Production needs real identity,
  authentication and per-user authorization.
* The browser never receives MCP tokens. They live in the gateway's environment.
* Through a public tunnel hostname, the gateway serves **only** `/alexa`, and only signature-verified Amazon requests
  (optionally restricted to your skill ID). Everything else returns 403.
* The MCP server rejects requests without a token, validates Host/Origin headers, rate-limits per token, and refuses to
  start in public mode with the default tokens.
* Uploads accept only JPEG/PNG/WebP up to 5 MB, checked by file signature and stored with random names.
* All inputs are validated server-side (Pydantic + business rules). Errors never include stack traces.

## Known limitations

See [SUBMISSION.md](SUBMISSION.md#known-limitations). In short: synthetic data, simulated roles, milestone tracking
without GPS, no external system integrations, a rule-based (not LLM) assistant, and Echo connectivity that depends on
your own Amazon developer account (untested on a physical device by the author of this code).

## Sources, photos and licence

Factual claims on the website are cited on the page and logged in
[docs/sources-and-image-attributions.md](docs/sources-and-image-attributions.md), together with photo credits (Pexels License).
Code: [MIT](LICENSE).
