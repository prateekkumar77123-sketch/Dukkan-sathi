# Dukaan Sathi — hackathon submission

## Project name

Dukaan Sathi (दुकान साथी)

## One-line description

AI-powered order coordination and delivery discrepancy management for hardware retailers and distributors.

## Full project description

**The problem.** Small hardware and building-material shops in India order from distributors through some mix of phone
calls, chat messages, sales representatives, invoices, notebooks and billing software. Practices vary, and some
businesses already use software. Where the confirmation, the dispatch and the receipt are recorded in different places,
simple questions take follow-up calls: *Was my order confirmed? Has it left the godown? We expected 50 bags and counted
48. What did the challan say?* Neither side can easily show what was agreed and when a difference was first noticed.
This context is real: India has more than 7.83 crore enterprises registered on the Udyam portals (PIB), goods move on
delivery challans and e-way bills under GST rules (CBIC), and cement and steel are sold by BIS grade (IS 269, IS 1786).
We have **not** measured how often shortages happen. The demo uses a labelled, simulated example instead.

**The users.** A retailer (fictional *Raj Hardware Store*, Jaipur) and a distributor (fictional *Sharma Building
Supplies*).

**The solution.** One shared order record that both parties work from:

1. The retailer asks naturally, in English, Hindi or Hinglish, by text or voice ("OPC 53 सीमेंट की 50 बोरी ऑर्डर करो").
2. Products, grades, sizes and units are resolved against the catalogue and validated deterministically. 50 kg is never
   50 bags; "cement" alone prompts a choice of grade.
3. The distributor confirms full or partial quantities, then records the dispatch (challan, e-way bill, vehicle,
   expected date).
4. The retailer counts and records what arrived, line by line, with damage notes and an optional photo.
5. The system compares confirmed → dispatched → received and opens a discrepancy for any short, excess or damaged
   quantity. It states where the numbers differ, *"2 bags below the recorded dispatched quantity — cause not yet
   determined"*, and never who is to blame.
6. Both sides add notes and record a resolution. Original quantities are never overwritten.

**How the assistant uses MCP.** The website, the bilingual assistant, the Alexa-inspired voice experience and an
optional Alexa custom skill all go through one **self-hosted MCP server** (official Python SDK, **Streamable HTTP**,
protocol **2025-11-25**). The FastAPI gateway runs a real MCP client. Every screen shows which tool produced its data,
and a live console lists every call.

**Why discrepancy detection matters.** A short delivery is cheap to settle when both sides look at the same numbers on
the same day, and expensive when it surfaces weeks later in a ledger reconciliation. A neutral, timestamped record of
dispatch versus receipt, linked to the exact order line, turns "your word against mine" into "here is what each of us
recorded".

## What we built (implemented MVP)

* React + TypeScript website: landing page, dashboard (live counts), orders list with filters and search, order detail
  with quantity flow and audit timeline, create-order (natural language + manual), distributor workspace,
  deliveries & differences, product catalogue, assistant, **Dukaan Sathi Voice Experience**, MCP console, demo
  controls, about/architecture. Full **English/Hindi** interface. Responsive.
* MCP server with 15 typed tools (search, draft, validate, submit, confirm, list, status, timeline, discrepancies,
  dashboard, dispatch, delivery, report, note, resolve), bearer-token roles enforced in the service layer,
  DNS-rebinding protection and a rate limit.
* FastAPI gateway with an MCP client over Streamable HTTP, per-call tracing, graceful outage handling.
* Deterministic rules: canonical units, explicit conversions, state machine, comparison, permissions.
* SQLite with reproducible synthetic seed data (12 orders: 4 in transit, 2 need review, 6 delivered; DS-1042 =
  50 confirmed / 50 dispatched / 48 received) and an explicit reset (full or live-recording mode).
* Rule-based bilingual intent parser (English, Devanagari Hindi, Hinglish). Answers are built only from tool results.
  Writes need confirmation.
* Alexa custom skill: signature-verified `/alexa` endpoint and interaction models for **en-IN and hi-IN**, ready to
  connect to the developer's own Echo in development mode.
* 40 automated backend tests. Windows one-command launcher (`run-demo.ps1`).

**Future possibilities (not built):** integrations with real distributor ERP/billing and inventory systems, e-way bill
and e-invoice lookups, WhatsApp notifications, photo-based counting, multiple distributors and branches, credit-note
accounting, real authentication, an optional LLM provider for open-ended questions, and an approved Alexa+ MCP add-on.

## Technical architecture

* **Frontend:** React 19, TypeScript, Vite 8, Tailwind CSS 4, lucide-react, Web Speech API (recognition + synthesis,
  en-IN / hi-IN).
* **API gateway:** Python 3.13, FastAPI, Uvicorn, Pydantic. Holds MCP tokens, adds the caller channel, returns tool
  traces, hosts the assistant and the Alexa endpoint.
* **MCP client:** `mcp` SDK `Client` over `streamable_http_client`, initialize handshake → protocol 2025-11-25.
* **MCP server:** `mcp.server.mcpserver.MCPServer`, Streamable HTTP (stateless, JSON responses) at `/mcp`, Starlette
  middleware for bearer auth and rate limiting, `TransportSecuritySettings` for Host/Origin validation.
* **Business logic:** pure-Python services and rules shared by every channel.
* **Database:** SQLite (WAL), transactions per state change, append-only audit events.
* **Voice:** browser speech (web simulator) and an Alexa custom skill (en-IN, hi-IN) with Amazon request-signature
  verification via `cryptography`.

Diagram: `docs/architecture.md` and the website's About page.

## Demo scenario

Order **DS-1042**: Raj Hardware Store orders **50 bags of OPC 53 cement** from Sharma Building Supplies. The
distributor confirms **50** and dispatches **50** (challan SBS/DC/26-27/0412). The retailer records **48 received**.
Dukaan Sathi opens **DSC-2004 — short delivery, 2 bags**, linked to the order line, with neutral wording. The
distributor acknowledges ("checking the loading register"). Either party records the resolution ("remaining 2 bags
with the next dispatch"). The order becomes *Delivered · resolved*, and the original 50 / 50 / 48 remain untouched in
the record and timeline. The same story can be queried by voice in English or Hindi.

Video: _<add your YouTube/Vimeo link>_ · Repository: _<add your public repo link>_

## Built with

Python · FastAPI · Uvicorn · Pydantic · Model Context Protocol Python SDK (`mcp` 2.3.0) · Streamable HTTP · SQLite ·
httpx · cryptography · certifi · python-dotenv · pytest · React · TypeScript · Vite · Tailwind CSS · React Router ·
lucide-react · Fontsource (Inter, Noto Sans Devanagari) · Web Speech API · Alexa Skills Kit (custom skill interaction
model + web-service endpoint) · PowerShell · Pexels (photos)

## Known limitations

* One fictional retailer and one fictional distributor; synthetic data; illustrative prices and stock.
* Demo roles are simulated (static bearer tokens per role); not production authentication.
* Milestone tracking only. No live GPS.
* No integration with real distributor, billing, inventory, e-way bill or payment systems.
* The assistant is rule-based (no external LLM connected), so it understands the supported intents and phrasings, not
  open-ended questions.
* The web Voice Experience is a simulation inspired by Alexa. It is not an Amazon product.
* The Alexa custom skill depends on the developer's own Amazon developer account and a tunnel. It was tested with sample
  Alexa requests and automated tests, **not** on a physical Echo by the code author. No Alexa+ add-on connection is claimed.
* Browser voice recognition needs Chrome or Edge (Hindi recognition quality depends on the browser). Typed input always works.
* Stock photos were selected from Pexels listings and must be reviewed before recording.

## Future scope

Real distributor and inventory integrations, e-invoice / e-way-bill validation, notifications (SMS/WhatsApp) on each
milestone, multi-distributor ordering, photo evidence analysis, credit-note ledger, proper multi-tenant authentication
(OAuth 2.1), a hosted deployment with a stable MCP URL, an optional LLM provider behind the same intent interface, and
an approved Alexa+ MCP add-on. All of this is future work.

## Product feedback (to complete honestly before submitting)

The hackathon asks for feedback on the tools, APIs and SDKs used. Below are notes on what **actually happened while this
code was being built** (by the AI coding assistant). Check each one against your own experience, keep what's true for
you, and add your own.

### Model Context Protocol Python SDK (`mcp` 2.3.0)

* **Used for:** the MCP server (`MCPServer`, Streamable HTTP, typed tools) and the gateway's MCP client.
* **Worked well (observed):** Pydantic return types automatically produced `outputSchema` + `structuredContent`.
  `Context.headers` made per-request bearer-token roles straightforward. Stateless + JSON-response mode was simple to
  run behind a gateway. The same server negotiated 2025-11-25 (handshake) and 2026-07-28 (auto) without code changes.
  Importing the removed `mcp.server.fastmcp` raised a clear message pointing to the v2 migration guide.
* **Friction (observed):** v1 examples (`FastMCP`, `streamablehttp_client`) no longer apply in v2, so the installed
  package source had to be read to find `MCPServer`, `Client(mode=...)` and `create_mcp_http_client`. The transport
  uses `httpx2`, so custom headers go through a pre-built client. `ToolError` text reaches clients prefixed with
  "Error executing tool …:", so structured error codes had to be parsed out of the message. Stateless mode logs
  "Terminating session: None" on every request.
* **Your notes:** onboarding/documentation ease ___ · would you use it again? ___ · feature requests ___

### FastAPI / Uvicorn / Pydantic

* **Used for:** the website API, validation, the Alexa endpoint.
* **Observed:** no notable issues. Plain `uvicorn` (no `[standard]` extras) was chosen to avoid compiled
  dependencies on Windows.
* **Your notes:** ___

### React 19 + Vite 8 + Tailwind CSS 4

* **Used for:** the website.
* **Observed issue:** in the Chromium version used for testing, `element.scrollIntoView()` returned a Promise. An effect
  written as `useEffect(() => ref.current?.scrollIntoView(...))` returned that Promise to React, which crashed with
  "destroy is not a function". Fixed by using block-bodied effects.
* **Your notes:** ___

### Web Speech API (browser)

* **Used for:** voice input and spoken replies in the Voice Experience (en-IN, hi-IN).
* **Observed:** availability differs by browser (Chrome/Edge). A typed fallback is essential.
* **Your notes (test on your laptop):** Hindi recognition accuracy ___ · voices available ___

### Alexa Skills Kit (custom skill) / Alexa+ documentation

* **Used for:** the optional Echo integration (en-IN + hi-IN models, signature-verified HTTPS endpoint).
* **Observed:** the developer docs were not reachable from the build environment, so the Hindi script guidance and the
  request-verification requirements were taken from search summaries of Amazon's pages. Gated Alexa+ add-on tooling
  was not available, as the FAQ states.
* **Your notes (after connecting your Echo Plus):** console setup ease ___ · Hindi recognition ___ · errors/workarounds ___

### Anything else

* Errors you hit on Windows, install time, what you'd want from the organisers' templates: ___

## Research and image sources

* Factual claims and their sources: `docs/sources-and-image-attributions.md` (also on the website's About page).
* Photo credits and licence notes: same file.
* Licence: MIT (`LICENSE`). Third-party photos are under the Pexels License and are not relicensed.
