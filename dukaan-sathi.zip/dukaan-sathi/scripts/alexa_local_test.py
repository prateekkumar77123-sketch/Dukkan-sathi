"""Run the Alexa skill handler locally against the running MCP server — no Amazon account needed.

It feeds the sample requests in alexa/test-requests/ (en-IN and hi-IN) straight into the same handler that
serves POST /alexa, and prints what the Echo would say. The HTTP endpoint itself always verifies Amazon's
request signature, so this script calls the handler in-process instead of weakening that check.

Usage (repository root, MCP server running):
  Windows:  backend\\.venv\\Scripts\\python.exe scripts\\alexa_local_test.py
"""

from __future__ import annotations

import asyncio
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from app.gateway.alexa.handler import AlexaHandler  # noqa: E402
from app.gateway.assistant.engine import AssistantEngine  # noqa: E402
from app.gateway.mcp_client import MCPGateway  # noqa: E402


async def main() -> None:
    handler = AlexaHandler(AssistantEngine(MCPGateway()))
    for path in sorted((ROOT / "alexa" / "test-requests").glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        out = await handler.handle(payload)
        ssml = out["response"]["outputSpeech"]["ssml"]
        speech = re.sub(r"<[^>]+>", "", ssml)
        print(f"\n▶ {path.name}  [{payload['request']['locale']}]\n  Alexa: {speech}")
        if out.get("sessionAttributes", {}).get("pending_action"):
            print("  (waiting for 'yes' / 'no' — nothing has been written yet)")


if __name__ == "__main__":
    asyncio.run(main())
