"""Independent MCP client test — talks to the Dukaan Sathi MCP server directly over Streamable HTTP.

It does NOT go through the website or the gateway. It:
  1. connects and negotiates the protocol (initialize handshake → 2025-11-25),
  2. lists the tools,
  3. runs a READ  (get_order_status DS-1042),
  4. runs a safe WRITE (create_draft_order: a 1-bag draft visible only to the retailer),
  5. shows that a disallowed write is rejected (retailer trying record_dispatch).

Usage (from the repository root, with the MCP server running):
  Windows:  backend\\.venv\\Scripts\\python.exe scripts\\mcp_smoke_test.py
  macOS/Linux: backend/.venv/bin/python scripts/mcp_smoke_test.py
Options: --url http://127.0.0.1:8001/mcp  --token <bearer token>  --mode legacy|auto
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os

from mcp import Client
from mcp.client.streamable_http import streamable_http_client
from mcp.shared._httpx_utils import create_mcp_http_client


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default=os.getenv("MCP_URL", "http://127.0.0.1:8001/mcp"))
    ap.add_argument("--token", default=os.getenv("MCP_RETAILER_TOKEN", "local-dev-retailer-token"))
    ap.add_argument("--mode", default="legacy", help="legacy = initialize handshake (2025-11-25); auto = newest supported")
    args = ap.parse_args()

    http = create_mcp_http_client(headers={"Authorization": f"Bearer {args.token}", "X-Dukaan-Source": "mcp"})
    async with http, Client(streamable_http_client(args.url, http_client=http), mode=args.mode) as client:
        print(f"Connected to {args.url}")
        print(f"  server: {client.server_info.name if client.server_info else '?'}  protocol: {client.protocol_version}")

        tools = (await client.list_tools()).tools
        print(f"\n{len(tools)} tools:")
        for t in tools:
            kind = "read " if t.annotations and t.annotations.read_only_hint else "write"
            print(f"  [{kind}] {t.name}")

        print("\nREAD  get_order_status(order_id='DS-1042')")
        r = await client.call_tool("get_order_status", {"order_id": "DS-1042"})
        o = r.structured_content
        ln = o["lines"][0]
        print(f"  {o['id']} · {o['status']} · {ln['product_name']}: confirmed {ln['confirmed_qty']}, "
              f"dispatched {ln['dispatched_qty']}, received {ln['received_qty']}")
        for d in o["discrepancies"]:
            print(f"  {d['id']} [{d['status']}] {d['description']}")

        print("\nWRITE create_draft_order(1 bag PPC cement)  — a draft only the retailer can see")
        r = await client.call_tool("create_draft_order", {"lines": [{"sku": "CEM-PPC-50", "quantity": 1, "unit": "bag"}],
                                                          "notes": "Created by scripts/mcp_smoke_test.py"})
        print("  " + (r.structured_content["message"] if not r.is_error else r.content[0].text))

        print("\nREJECTED WRITE record_dispatch as retailer (only distributors may dispatch)")
        r = await client.call_tool("record_dispatch", {"order_id": "DS-1038", "challan_ref": "TEST"})
        err = r.content[0].text
        print(f"  is_error={r.is_error}: {json.loads(err[err.index('{'):])['error']['message']}")
    print("\nDone. Reset the demo data afterwards from Demo controls or:  python -m app.seed full  (in backend/)")


if __name__ == "__main__":
    asyncio.run(main())
