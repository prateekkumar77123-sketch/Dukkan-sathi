<#
  Downloads local copies of the Pexels photos used on the website into frontend\public\images\photos\
  so the demo does not depend on remote image links. Pexels License: free to use; attribution is not
  required, but credits are shown on the site and in docs\sources-and-image-attributions.md.

  Run from the repository root:
    powershell -ExecutionPolicy Bypass -File .\scripts\fetch-photos.ps1

  Please look at each downloaded photo before recording, and replace any you don't want to use.
#>
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Dest = Join-Path $Root "frontend\public\images\photos"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null

$photos = @(
  @{ File = "hardware-shop.jpg";       Id = 19756443; Page = "https://www.pexels.com/photo/man-working-at-hardware-store-19756443/" },
  @{ File = "truck-with-sacks.jpg";    Id = 15733306; Page = "https://www.pexels.com/photo/truck-filled-with-sacks-15733306/" },
  @{ File = "cement-bags.jpg";         Id = 29519165; Page = "https://www.pexels.com/photo/stack-of-cement-bags-in-warehouse-setting-29519165/" },
  @{ File = "hardware-storefront.jpg"; Id = 29151932; Page = "https://www.pexels.com/photo/old-hardware-storefront-with-tools-and-supplies-29151932/" },
  @{ File = "construction-delhi.jpg";  Id = 30580529; Page = "https://www.pexels.com/photo/construction-worker-renovating-interior-in-delhi-30580529/" },
  @{ File = "indian-market.jpg";       Id = 16747112; Page = "https://www.pexels.com/photo/traditional-indian-market-16747112/" }
)

foreach ($p in $photos) {
  $url = "https://images.pexels.com/photos/$($p.Id)/pexels-photo-$($p.Id).jpeg?auto=compress&cs=tinysrgb&w=1600"
  $out = Join-Path $Dest $p.File
  try {
    Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing -Headers @{ "User-Agent" = "Mozilla/5.0 (Dukaan Sathi demo setup)" }
    $kb = [math]::Round((Get-Item $out).Length / 1KB)
    Write-Host ("  saved {0,-26} {1,6} KB   source: {2}" -f $p.File, $kb, $p.Page) -ForegroundColor Green
  } catch {
    Write-Host ("  could not download {0}: {1}" -f $p.File, $_.Exception.Message) -ForegroundColor Yellow
    Write-Host "    The website will fall back to the Pexels CDN, then to an illustration." -ForegroundColor Yellow
  }
}
Write-Host "`nDone. Open $Dest and check each photo before recording."
