"""Reproducible synthetic demo data.

All businesses, people and orders here are fictional and clearly marked as sample data.
Prices are illustrative placeholders for the demo, not market quotes.

Two modes:
  full  – DS-1042 already has its 48-bag receipt and an open 2-bag discrepancy (12 orders:
          4 in transit, 2 need review, 6 delivered — 2 of them with resolved differences).
  live  – identical, except DS-1042 stops at "in transit" so the receipt can be recorded live
          on camera.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, time, timedelta, timezone
from typing import Any, Literal

from app.db import DATA_TABLES, init_schema, iso, now_iso, transaction
from app.domain.actors import DISTRIBUTOR_ID, RETAILER_ID, actor_for_role
from app.domain.rules import compare_line, fmt_qty, qty_with_unit
from app.services.orders import KIND_LABELS, RESOLUTION_LABELS, _insert_discrepancy, record_event

IST = timezone(timedelta(hours=5, minutes=30))

PARTIES = [
    (RETAILER_ID, "retailer", "Raj Hardware Store", "राज हार्डवेयर स्टोर", "Jaipur, Rajasthan", "Raj"),
    (DISTRIBUTOR_ID, "distributor", "Sharma Building Supplies", "शर्मा बिल्डिंग सप्लाइज़", "Jaipur, Rajasthan",
     "Anil Sharma"),
]

# (sku, name, name_hi, category, grade, size, spec, spec_hi, unit, alt_unit, alt_per_unit, standard, hsn, gst,
#  price_paise, keywords)
PRODUCTS: list[tuple[Any, ...]] = [
    ("CEM-OPC53-50", "OPC 53 Grade Cement", "OPC 53 ग्रेड सीमेंट", "Cement", "OPC 53", "50 kg bag",
     "Ordinary Portland Cement, 53 grade, 50 kg bag", "ऑर्डिनरी पोर्टलैंड सीमेंट, 53 ग्रेड, 50 किलो बोरी",
     "bag", None, None, "IS 269:2015", "2523", 18.0, 39000, "cement opc 53 portland bag bori"),
    ("CEM-OPC43-50", "OPC 43 Grade Cement", "OPC 43 ग्रेड सीमेंट", "Cement", "OPC 43", "50 kg bag",
     "Ordinary Portland Cement, 43 grade, 50 kg bag", "ऑर्डिनरी पोर्टलैंड सीमेंट, 43 ग्रेड, 50 किलो बोरी",
     "bag", None, None, "IS 269:2015", "2523", 18.0, 37000, "cement opc 43 portland bag bori"),
    ("CEM-PPC-50", "PPC Cement (fly ash based)", "PPC सीमेंट (फ्लाई ऐश आधारित)", "Cement", "PPC", "50 kg bag",
     "Portland Pozzolana Cement, fly ash based, 50 kg bag", "पोर्टलैंड पोज़ोलाना सीमेंट, फ्लाई ऐश आधारित, 50 किलो बोरी",
     "bag", None, None, "IS 1489 (Part 1):2015", "2523", 18.0, 36000, "cement ppc pozzolana fly ash bag bori"),
    ("TMT-500D-08", "TMT Bar Fe 500D, 8 mm", "TMT सरिया Fe 500D, 8 मिमी", "Steel", "Fe 500D", "8 mm",
     "TMT bar, Fe 500D, 8 mm dia, 12 m length (approx. 4.74 kg per bar)",
     "TMT सरिया, Fe 500D, 8 मिमी, 12 मीटर लंबाई (लगभग 4.74 किलो प्रति सरिया)",
     "piece", None, None, "IS 1786:2008", None, None, 29400, "tmt bar rod sariya steel fe500d 8mm"),
    ("TMT-500D-10", "TMT Bar Fe 500D, 10 mm", "TMT सरिया Fe 500D, 10 मिमी", "Steel", "Fe 500D", "10 mm",
     "TMT bar, Fe 500D, 10 mm dia, 12 m length (approx. 7.41 kg per bar)",
     "TMT सरिया, Fe 500D, 10 मिमी, 12 मीटर लंबाई (लगभग 7.41 किलो प्रति सरिया)",
     "piece", None, None, "IS 1786:2008", None, None, 45900, "tmt bar rod sariya steel fe500d 10mm"),
    ("TMT-500D-12", "TMT Bar Fe 500D, 12 mm", "TMT सरिया Fe 500D, 12 मिमी", "Steel", "Fe 500D", "12 mm",
     "TMT bar, Fe 500D, 12 mm dia, 12 m length (approx. 10.67 kg per bar)",
     "TMT सरिया, Fe 500D, 12 मिमी, 12 मीटर लंबाई (लगभग 10.67 किलो प्रति सरिया)",
     "piece", None, None, "IS 1786:2008", None, None, 66200, "tmt bar rod sariya steel fe500d 12mm"),
    ("TMT-500D-16", "TMT Bar Fe 500D, 16 mm", "TMT सरिया Fe 500D, 16 मिमी", "Steel", "Fe 500D", "16 mm",
     "TMT bar, Fe 500D, 16 mm dia, 12 m length (approx. 18.96 kg per bar)",
     "TMT सरिया, Fe 500D, 16 मिमी, 12 मीटर लंबाई (लगभग 18.96 किलो प्रति सरिया)",
     "piece", None, None, "IS 1786:2008", None, None, 117600, "tmt bar rod sariya steel fe500d 16mm"),
    ("PVC-PIPE-1IN", "uPVC Pipe 1 inch", "uPVC पाइप 1 इंच", "Pipes", None, "1 inch",
     "uPVC pressure pipe, 1 inch, 6 m length", "uPVC प्रेशर पाइप, 1 इंच, 6 मीटर लंबाई",
     "length", None, None, None, None, None, 26000, "pvc upvc pipe 1inch"),
    ("PVC-PIPE-2IN", "uPVC Pipe 2 inch", "uPVC पाइप 2 इंच", "Pipes", None, "2 inch",
     "uPVC pressure pipe, 2 inch, 6 m length", "uPVC प्रेशर पाइप, 2 इंच, 6 मीटर लंबाई",
     "length", None, None, None, None, None, 54000, "pvc upvc pipe 2inch"),
    ("PVC-PIPE-4IN", "uPVC Pipe 4 inch", "uPVC पाइप 4 इंच", "Pipes", None, "4 inch",
     "uPVC pressure pipe, 4 inch, 6 m length", "uPVC प्रेशर पाइप, 4 इंच, 6 मीटर लंबाई",
     "length", None, None, None, None, None, 135000, "pvc upvc pipe 4inch"),
    ("SCR-WOOD-8x1-PK100", "Wood Screws 8 × 1 inch (pack of 100)", "लकड़ी के पेंच 8 × 1 इंच (100 का पैकेट)",
     "Fasteners", None, "8 × 1 inch", "CSK Phillips wood screws, No. 8 × 1 inch, pack of 100 pieces",
     "CSK फिलिप्स लकड़ी के पेंच, नंबर 8 × 1 इंच, 100 पीस का पैकेट",
     "pack", "piece", 100, None, None, None, 18000, "screw screws wood pack packet 8x1"),
    ("SCR-DRY-6x1-PC", "Drywall Screws 6 × 1 inch (loose)", "ड्राईवॉल पेंच 6 × 1 इंच (खुले)",
     "Fasteners", None, "6 × 1 inch", "Black phosphate drywall screws, No. 6 × 1 inch, sold per piece",
     "काले फॉस्फेट ड्राईवॉल पेंच, नंबर 6 × 1 इंच, प्रति पीस", "piece", None, None, None, None, None, 150,
     "screw screws drywall loose piece 6x1"),
    ("BW-18G", "Binding Wire 18 gauge", "बाइंडिंग तार 18 गेज", "Steel", None, "18 gauge",
     "Annealed binding wire, 18 gauge, sold by weight", "एनील्ड बाइंडिंग तार, 18 गेज, वज़न से बिक्री",
     "kg", None, None, None, None, None, 8500, "binding wire tar taar 18 gauge kg"),
    ("PUTTY-40", "Wall Putty (40 kg bag)", "वॉल पुट्टी (40 किलो बोरी)", "Finishes", None, "40 kg bag",
     "White cement based wall putty, 40 kg bag", "व्हाइट सीमेंट आधारित वॉल पुट्टी, 40 किलो बोरी",
     "bag", None, None, None, None, None, 78000, "wall putty putti bag bori"),
    ("CND-25MM", "PVC Electrical Conduit 25 mm", "PVC इलेक्ट्रिकल कंड्यूट 25 मिमी", "Electrical", None, "25 mm",
     "Rigid PVC electrical conduit, 25 mm, 3 m length", "रिजिड PVC इलेक्ट्रिकल कंड्यूट, 25 मिमी, 3 मीटर लंबाई",
     "length", "metre", 3, None, None, None, 7000, "conduit electrical pvc pipe 25mm wiring"),
]

STOCK = {
    "CEM-OPC53-50": 420, "CEM-OPC43-50": 120, "CEM-PPC-50": 300, "TMT-500D-08": 900, "TMT-500D-10": 600,
    "TMT-500D-12": 350, "TMT-500D-16": 0, "PVC-PIPE-1IN": 200, "PVC-PIPE-2IN": 140, "PVC-PIPE-4IN": 40,
    "SCR-WOOD-8x1-PK100": 10, "SCR-DRY-6x1-PC": 5000, "BW-18G": 250, "PUTTY-40": 90, "CND-25MM": 400,
}

PRICE = {p[0]: p[14] for p in PRODUCTS}
UNIT = {p[0]: p[8] for p in PRODUCTS}
NAME = {p[0]: (p[1], p[2]) for p in PRODUCTS}


def at_ist(day_offset: int, hh: int, mm: int) -> str:
    today = datetime.now(IST).date()
    dt = datetime.combine(today + timedelta(days=day_offset), time(hh, mm), tzinfo=IST)
    return iso(dt)


def date_ist(day_offset: int) -> str:
    return (datetime.now(IST).date() + timedelta(days=day_offset)).isoformat()


RET = actor_for_role("retailer", "web")
DIS = actor_for_role("distributor", "web")


def _items(lines: list[tuple[str, float]], lang: str) -> str:
    if lang == "hi":
        return ", ".join(f"{NAME[s][1]} {qty_with_unit(q, UNIT[s], 'hi')}" for s, q in lines)
    return ", ".join(f"{qty_with_unit(q, UNIT[s])} {NAME[s][0]}" for s, q in lines)


def _seed_order(
    conn: sqlite3.Connection,
    oid: str,
    *,
    created: tuple[int, int, int],
    lines: list[tuple[str, float]],
    submitted: tuple[int, int, int] | None = None,
    confirmed: tuple[int, int, int] | None = None,
    confirm_qty: dict[str, float] | None = None,
    distributor_notes: str | None = None,
    dispatch: dict[str, Any] | None = None,
    receipt: dict[str, Any] | None = None,
    acknowledgements: list[tuple[tuple[int, int, int], str]] | None = None,
    resolution: dict[str, Any] | None = None,
    notes: str | None = None,
    requested_delivery: int | None = None,
) -> None:
    c_at = at_ist(*created)
    conn.execute(
        """INSERT INTO orders (id, retailer_id, distributor_id, status, created_at, requested_delivery_date, notes,
                               is_sample, updated_at)
           VALUES (?, ?, ?, 'draft', ?, ?, ?, 1, ?)""",
        (oid, RETAILER_ID, DISTRIBUTOR_ID, c_at, date_ist(requested_delivery) if requested_delivery is not None else None,
         notes, c_at),
    )
    line_ids: dict[str, int] = {}
    for i, (sku, qty) in enumerate(lines, start=1):
        cur = conn.execute(
            "INSERT INTO order_lines (order_id, line_no, product_id, unit, requested_qty, unit_price_paise) VALUES (?,?,?,?,?,?)",
            (oid, i, sku, UNIT[sku], qty, PRICE[sku]),
        )
        line_ids[sku] = cur.lastrowid
    record_event(conn, oid, RET, "draft_created", f"Order draft created: {_items(lines, 'en')}",
                 f"ऑर्डर ड्राफ्ट बना: {_items(lines, 'hi')}", {"sample": True}, c_at)
    status = "draft"
    if submitted:
        s_at = at_ist(*submitted)
        conn.execute("UPDATE orders SET submitted_at = ? WHERE id = ?", (s_at, oid))
        record_event(conn, oid, RET, "order_submitted", "Retailer reviewed and submitted the order to the distributor",
                     "रिटेलर ने ऑर्डर जाँचकर डिस्ट्रीब्यूटर को भेजा", {"sample": True}, s_at)
        status = "pending_confirmation"
    cq = {sku: (confirm_qty or {}).get(sku, qty) for sku, qty in lines}
    if confirmed:
        k_at = at_ist(*confirmed)
        for sku, q in cq.items():
            conn.execute("UPDATE order_lines SET confirmed_qty = ? WHERE id = ?", (q, line_ids[sku]))
        conn.execute("UPDATE orders SET confirmed_at = ?, distributor_notes = ? WHERE id = ?", (k_at, distributor_notes, oid))
        parts, parts_hi = [], []
        for sku, qty in lines:
            q = cq[sku]
            if q < qty:
                parts.append(f"{qty_with_unit(q, UNIT[sku])} of {fmt_qty(qty)} requested {NAME[sku][0]}")
                parts_hi.append(f"{NAME[sku][1]}: {fmt_qty(qty)} में से {qty_with_unit(q, UNIT[sku], 'hi')}")
            else:
                parts.append(f"{qty_with_unit(q, UNIT[sku])} {NAME[sku][0]}")
                parts_hi.append(f"{NAME[sku][1]} {qty_with_unit(q, UNIT[sku], 'hi')}")
        record_event(conn, oid, DIS, "order_confirmed", "Distributor confirmed " + "; ".join(parts),
                     "डिस्ट्रीब्यूटर ने पुष्टि की: " + "; ".join(parts_hi), {"notes": distributor_notes, "sample": True}, k_at)
        status = "confirmed"
    dq = dict(cq)
    if dispatch:
        d_at = at_ist(*dispatch["at"])
        dq.update(dispatch.get("qty", {}))
        for sku, q in dq.items():
            conn.execute("UPDATE order_lines SET dispatched_qty = ? WHERE id = ?", (q, line_ids[sku]))
        conn.execute(
            """INSERT INTO dispatches (order_id, challan_ref, eway_bill_ref, vehicle_ref, driver_note, notes, dispatched_at,
                                       expected_delivery_date, recorded_by, recorded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (oid, dispatch["challan"], dispatch.get("eway"), dispatch.get("vehicle"), dispatch.get("driver_note"),
             dispatch.get("notes"), d_at, date_ist(dispatch["expected"]), DIS.display_name, d_at),
        )
        items = [(s, q) for s, q in dq.items()]
        record_event(conn, oid, DIS, "dispatch_recorded",
                     f"Dispatch recorded under challan {dispatch['challan']}: {_items(items, 'en')}",
                     f"चालान {dispatch['challan']} के तहत डिस्पैच दर्ज: {_items(items, 'hi')}",
                     {"challan_ref": dispatch["challan"], "sample": True}, d_at)
        status = "in_transit"
    flagged = False
    if receipt:
        r_at = at_ist(*receipt["at"])
        rq = dict(dq)
        rq.update(receipt.get("qty", {}))
        damaged = receipt.get("damaged", {})
        for sku, q in rq.items():
            conn.execute("UPDATE order_lines SET received_qty = ?, damaged_qty = ? WHERE id = ?",
                         (q, damaged.get(sku, 0), line_ids[sku]))
        conn.execute(
            "INSERT INTO receipts (order_id, received_at, condition_notes, recorded_by, recorded_at) VALUES (?,?,?,?,?)",
            (oid, r_at, receipt.get("notes"), RET.display_name, r_at),
        )
        items = [(s, q) for s, q in rq.items()]
        record_event(conn, oid, RET, "receipt_recorded", f"Retailer recorded receipt of {_items(items, 'en')}",
                     f"रिटेलर ने प्राप्ति दर्ज की: {_items(items, 'hi')}", {"condition_notes": receipt.get("notes"), "sample": True}, r_at)
        for sku, q in rq.items():
            line = conn.execute("SELECT * FROM order_lines WHERE id = ?", (line_ids[sku],)).fetchone()
            cmp = compare_line(confirmed=cq[sku], dispatched=dq[sku], received=q, damaged=damaged.get(sku, 0), unit=UNIT[sku])
            pname, pname_hi = NAME[sku]
            if cmp.outcome in ("short", "excess"):
                diff = abs(cmp.receipt_variance or 0)
                did = _insert_discrepancy(conn, order_id=oid, line=line, kind=cmp.outcome, expected=dq[sku], observed=q,
                                          difference=diff, detected_by="system", description=f"{pname}: {cmp.summary}",
                                          description_hi=f"{pname_hi}: {cmp.summary_hi}", at=r_at)
                label, label_hi = KIND_LABELS[cmp.outcome]
                record_event(conn, oid, None, "discrepancy_flagged",
                             f"System flagged a {label} of {qty_with_unit(diff, UNIT[sku])} on {pname} ({did}): "
                             f"{fmt_qty(dq[sku])} dispatched, {fmt_qty(q)} received",
                             f"सिस्टम ने {pname_hi} पर {qty_with_unit(diff, UNIT[sku], 'hi')} की {label_hi} दर्ज की ({did}): "
                             f"{fmt_qty(dq[sku])} भेजी गई, {fmt_qty(q)} मिली",
                             {"discrepancy_id": did, "kind": cmp.outcome, "difference": diff}, r_at)
                flagged = True
            if damaged.get(sku, 0) > 0:
                dmg = damaged[sku]
                did = _insert_discrepancy(
                    conn, order_id=oid, line=line, kind="damaged", expected=None, observed=dmg, difference=dmg,
                    detected_by="retailer",
                    description=f"{pname}: {qty_with_unit(dmg, UNIT[sku])} reported damaged at receipt.",
                    description_hi=f"{pname_hi}: प्राप्ति के समय {qty_with_unit(dmg, UNIT[sku], 'hi')} क्षतिग्रस्त बताई गई।",
                    at=r_at)
                record_event(conn, oid, RET, "damage_reported",
                             f"{qty_with_unit(dmg, UNIT[sku])} of {pname} reported damaged ({did})",
                             f"{pname_hi} की {qty_with_unit(dmg, UNIT[sku], 'hi')} क्षतिग्रस्त बताई गई ({did})",
                             {"discrepancy_id": did, "damaged": dmg}, r_at)
                flagged = True
        if not flagged:
            record_event(conn, oid, None, "quantities_matched",
                         "All received quantities match the recorded dispatch. Order marked delivered.",
                         "सभी प्राप्त मात्राएँ डिस्पैच से मेल खाती हैं। ऑर्डर डिलीवर माना गया।", {}, r_at)
        status = "needs_review" if flagged else "delivered"
    discs = conn.execute("SELECT * FROM discrepancies WHERE order_id = ?", (oid,)).fetchall()
    for when, text in acknowledgements or []:
        a_at = at_ist(*when)
        for d in discs:
            conn.execute(
                """INSERT INTO discrepancy_notes (discrepancy_id, author_role, author_name, kind, note, source, created_at)
                   VALUES (?, 'distributor', ?, 'acknowledgement', ?, 'web', ?)""",
                (d["id"], DIS.display_name, text, a_at),
            )
            conn.execute("UPDATE discrepancies SET status = 'acknowledged' WHERE id = ?", (d["id"],))
            record_event(conn, oid, DIS, "discrepancy_acknowledged",
                         f"Distributor acknowledged discrepancy {d['id']}: “{text}”",
                         f"distributor ने अंतर {d['id']} स्वीकार किया: “{text}”", {"discrepancy_id": d["id"]}, a_at)
    if resolution:
        z_at = at_ist(*resolution["at"])
        actor = RET if resolution.get("by") == "retailer" else DIS
        rtype = resolution["type"]
        label, label_hi = RESOLUTION_LABELS[rtype]
        for d in discs:
            fu = d["difference_qty"] if rtype == "supply_remaining" else None
            conn.execute(
                """INSERT INTO resolutions (discrepancy_id, resolution_type, follow_up_qty, notes, decided_by_role,
                                            decided_by_name, source, decided_at) VALUES (?,?,?,?,?,?, 'web', ?)""",
                (d["id"], rtype, fu, resolution["notes"], actor.role, actor.display_name, z_at),
            )
            conn.execute("UPDATE discrepancies SET status = 'resolved' WHERE id = ?", (d["id"],))
            record_event(conn, oid, actor, "resolution_recorded",
                         f"{actor.role.title()} recorded resolution for {d['id']}: {label}. “{resolution['notes']}”",
                         f"{actor.role} ने {d['id']} का समाधान दर्ज किया: {label_hi}। “{resolution['notes']}”",
                         {"discrepancy_id": d["id"], "resolution_type": rtype}, z_at)
        record_event(conn, oid, None, "order_resolved",
                     "All differences on this order now have a recorded resolution. Original quantities are preserved.",
                     "इस ऑर्डर के सभी अंतरों का समाधान दर्ज है। मूल मात्राएँ सुरक्षित हैं।", {}, z_at)
        status = "resolved"
    last = conn.execute("SELECT MAX(at) FROM audit_events WHERE order_id = ?", (oid,)).fetchone()[0]
    conn.execute("UPDATE orders SET status = ?, updated_at = ? WHERE id = ?", (status, last, oid))


def seed_database(conn: sqlite3.Connection, mode: Literal["full", "live"] = "full") -> None:
    init_schema(conn)
    with transaction(conn):
        for table in DATA_TABLES:
            conn.execute(f"DELETE FROM {table}")
        conn.execute("DELETE FROM sqlite_sequence")
        conn.executemany("INSERT INTO parties VALUES (?, ?, ?, ?, ?, ?)", PARTIES)
        conn.executemany(
            """INSERT INTO products (id, name, name_hi, category, grade, size, spec, spec_hi, unit, alt_unit, alt_per_unit,
                                     standard, hsn, gst_rate, price_paise, keywords)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            PRODUCTS,
        )
        conn.executemany(
            "INSERT INTO distributor_stock VALUES (?, ?, ?)", [(DISTRIBUTOR_ID, s, q) for s, q in STOCK.items()]
        )

        # --- delivered / resolved history -------------------------------------------------
        _seed_order(conn, "DS-1031", created=(-12, 9, 40), lines=[("CEM-PPC-50", 100)], submitted=(-12, 9, 44),
                    confirmed=(-12, 10, 5), dispatch={"at": (-12, 13, 30), "challan": "SBS/DC/26-27/0381",
                    "vehicle": "RJ14 XX 0381", "expected": -12}, receipt={"at": (-12, 17, 10), "notes": "All bags dry and intact."})
        _seed_order(conn, "DS-1032", created=(-11, 11, 15), lines=[("TMT-500D-10", 150)], submitted=(-11, 11, 18),
                    confirmed=(-11, 12, 0), dispatch={"at": (-10, 9, 30), "challan": "SBS/DC/26-27/0386",
                    "eway": "Sample EWB 1810 0000 0386", "vehicle": "RJ14 XX 0386", "expected": -10},
                    receipt={"at": (-10, 14, 5), "qty": {"TMT-500D-10": 146}, "notes": "Counted bundles twice: 146 bars."},
                    acknowledgements=[((-10, 15, 0), "Checking the loading register for this challan.")],
                    resolution={"at": (-9, 11, 20), "type": "supply_remaining", "by": "distributor",
                                "notes": "4 bars of 10 mm to be sent with the next dispatch to Raj Hardware Store."})
        _seed_order(conn, "DS-1033", created=(-9, 10, 0), lines=[("PVC-PIPE-2IN", 20), ("SCR-WOOD-8x1-PK100", 10)],
                    submitted=(-9, 10, 2), confirmed=(-9, 10, 40), dispatch={"at": (-9, 15, 0),
                    "challan": "SBS/DC/26-27/0391", "vehicle": "RJ14 XX 0391", "expected": -8},
                    receipt={"at": (-8, 11, 30)})
        _seed_order(conn, "DS-1034", created=(-8, 12, 10), lines=[("PUTTY-40", 40)], submitted=(-8, 12, 12),
                    confirmed=(-8, 13, 0), dispatch={"at": (-7, 10, 15), "challan": "SBS/DC/26-27/0395",
                    "vehicle": "RJ14 XX 0395", "expected": -7}, receipt={"at": (-7, 16, 40)})
        _seed_order(conn, "DS-1035", created=(-7, 9, 20), lines=[("CEM-OPC53-50", 60)], submitted=(-7, 9, 22),
                    confirmed=(-7, 9, 50), dispatch={"at": (-6, 10, 0), "challan": "SBS/DC/26-27/0399",
                    "vehicle": "RJ14 XX 0399", "expected": -6},
                    receipt={"at": (-6, 13, 45), "damaged": {"CEM-OPC53-50": 3}, "notes": "3 bags torn at the seam during unloading."},
                    acknowledgements=[((-6, 14, 30), "Noted. Please keep the torn bags aside for inspection.")],
                    resolution={"at": (-5, 12, 0), "type": "credit_note", "by": "distributor",
                                "notes": "Credit for 3 bags agreed against the next invoice."})
        _seed_order(conn, "DS-1036", created=(-6, 16, 0), lines=[("BW-18G", 25), ("CND-25MM", 30)],
                    submitted=(-6, 16, 3), confirmed=(-5, 9, 30), dispatch={"at": (-5, 12, 30),
                    "challan": "SBS/DC/26-27/0404", "vehicle": "RJ14 XX 0404", "expected": -5},
                    receipt={"at": (-5, 17, 0)})

        # --- needs review --------------------------------------------------------------------
        _seed_order(conn, "DS-1037", created=(-4, 10, 30), lines=[("PVC-PIPE-4IN", 30)], submitted=(-4, 10, 33),
                    confirmed=(-4, 11, 10), dispatch={"at": (-3, 9, 45), "challan": "SBS/DC/26-27/0407",
                    "vehicle": "RJ14 XX 0407", "expected": -3},
                    receipt={"at": (-3, 13, 20), "damaged": {"PVC-PIPE-4IN": 2}, "notes": "2 lengths cracked near the socket end."})

        # --- in transit ------------------------------------------------------------------------
        _seed_order(conn, "DS-1038", created=(-3, 11, 0), lines=[("TMT-500D-08", 200)], submitted=(-3, 11, 2),
                    confirmed=(-3, 11, 40), dispatch={"at": (-1, 9, 10), "challan": "SBS/DC/26-27/0409",
                    "eway": "Sample EWB 1810 0000 0409", "vehicle": "RJ14 XX 0409", "expected": 0,
                    "driver_note": "Unload at side gate (sample note)."})
        _seed_order(conn, "DS-1039", created=(-2, 10, 0), lines=[("CEM-OPC43-50", 30), ("BW-18G", 15)],
                    submitted=(-2, 10, 1), confirmed=(-2, 10, 45), dispatch={"at": (-1, 11, 40),
                    "challan": "SBS/DC/26-27/0411", "vehicle": "RJ14 XX 0411", "expected": 0})
        _seed_order(conn, "DS-1040", created=(-2, 12, 20), lines=[("CND-25MM", 50), ("SCR-WOOD-8x1-PK100", 12)],
                    submitted=(-2, 12, 22), confirmed=(-2, 13, 5), confirm_qty={"SCR-WOOD-8x1-PK100": 10},
                    distributor_notes="Only 10 packs of 8 × 1 inch screws in stock; balance 2 packs next week.",
                    dispatch={"at": (-1, 16, 30), "challan": "SBS/DC/26-27/0413", "vehicle": "RJ14 XX 0413",
                    "expected": 1})
        _seed_order(conn, "DS-1041", created=(-2, 15, 30), lines=[("CEM-PPC-50", 80)], submitted=(-2, 15, 31),
                    confirmed=(-2, 16, 10), dispatch={"at": (-1, 11, 0), "challan": "SBS/DC/26-27/0410",
                    "vehicle": "RJ14 XX 0410", "expected": 1})

        # --- the primary story: DS-1042 ----------------------------------------------------------
        primary: dict[str, Any] = dict(
            created=(-1, 10, 5), lines=[("CEM-OPC53-50", 50)], submitted=(-1, 10, 7), confirmed=(-1, 10, 16),
            dispatch={"at": (-1, 12, 20), "challan": "SBS/DC/26-27/0412", "vehicle": "RJ14 XX 1042",
                      "driver_note": "Driver: Mahesh (fictional sample name).", "expected": -1 if mode == "full" else 0},
            requested_delivery=-1,
        )
        if mode == "full":
            primary["receipt"] = {"at": (-1, 15, 10), "qty": {"CEM-OPC53-50": 48},
                                  "notes": "Counted 48 bags at unloading. Bags dry and intact."}
            primary["acknowledgements"] = [((-1, 15, 25), "Checking the loading register and with the driver. Will update by tomorrow.")]
        _seed_order(conn, "DS-1042", **primary)

        conn.execute("INSERT INTO meta VALUES ('seeded_at', ?)", (now_iso(),))
        conn.execute("INSERT INTO meta VALUES ('seed_mode', ?)", (mode,))


if __name__ == "__main__":  # python -m app.seed [full|live]
    import sys

    from app.db import connect

    m = sys.argv[1] if len(sys.argv) > 1 else "full"
    if m not in ("full", "live"):
        raise SystemExit("usage: python -m app.seed [full|live]")
    c = connect()
    seed_database(c, m)  # type: ignore[arg-type]
    c.close()
    print(f"Demo data reset ({m} mode).")
