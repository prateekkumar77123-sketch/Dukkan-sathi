"""Dukaan Sathi MCP server — Streamable HTTP transport, official MCP Python SDK.

Run:  python -m app.mcp_server.server        (listens on http://127.0.0.1:8001/mcp)

Every tool calls the same business services and SQLite database that the website uses.
Callers authenticate with a bearer token; the token decides the demo role (retailer or
distributor), and the service layer enforces what that role may do.
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict, deque
from collections.abc import Callable
from typing import Annotated, Any, TypeVar

import uvicorn
from mcp.server.mcpserver import Context, MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations
from mcp_types.version import HANDSHAKE_PROTOCOL_VERSIONS, MODERN_PROTOCOL_VERSIONS
from pydantic import Field
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Receive, Scope, Send

from app.config import settings
from app.db import connect, ensure_database
from app.domain.actors import Actor, actor_for_role
from app.domain.errors import DomainError, PermissionDenied
from app.domain.models import (
    ActionResult,
    ConfirmLineInput,
    DashboardSummary,
    DiscrepancyListResult,
    DispatchLineInput,
    LineInput,
    OrderListResult,
    OrderOut,
    ProductSearchResult,
    ReceiptLineInput,
    TimelineResult,
    ValidationResult,
)
from app.services import catalog, dashboard, orders

log = logging.getLogger("dukaan.mcp")

INSTRUCTIONS = """\
Dukaan Sathi coordinates orders between a hardware retailer (Raj Hardware Store) and a building-material
distributor (Sharma Building Supplies). All businesses and orders are synthetic demo data.

Typical flow: search_products -> create_draft_order -> submit_order (retailer) -> confirm_order (distributor)
-> record_dispatch (distributor) -> record_delivery (retailer). Received quantities are compared with dispatched
quantities automatically; differences become discrepancies (DSC-xxxx) that either party can acknowledge
(add_discrepancy_note) and resolve (resolve_discrepancy). Order ids look like DS-1042.

Rules: never invent SKUs - resolve them with search_products. Units are never interchangeable (50 kg is not
50 bags). Ask the human to confirm before calling any tool that creates or changes a record. Recorded
quantities are never overwritten; resolutions are added on top of the original evidence. A discrepancy states
where the numbers differ, not who is at fault.
"""

mcp = MCPServer(
    name="dukaan-sathi",
    title="Dukaan Sathi order coordination",
    description="Shared order, dispatch, receipt and discrepancy records for hardware retailers and distributors.",
    instructions=INSTRUCTIONS,
    version="1.0.0",
)

READ = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=False)
WRITE = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=False)

T = TypeVar("T")


def _actor(ctx: Context) -> Actor:
    headers = {k.lower(): v for k, v in (ctx.headers or {}).items()}
    role = _role_for_token(headers.get("authorization", ""))
    if role is None:  # the HTTP middleware already rejects these; defence in depth for other transports
        raise ToolError(PermissionDenied("Missing or invalid bearer token.").to_json())
    return actor_for_role(role, headers.get("x-dukaan-source", "mcp"))


def _role_for_token(auth_header: str) -> str | None:
    if not auth_header.lower().startswith("bearer "):
        return None
    token = auth_header[7:].strip()
    if token and token == settings.retailer_token:
        return "retailer"
    if token and token == settings.distributor_token:
        return "distributor"
    return None


def _run(ctx: Context, fn: Callable[..., T], **kwargs: Any) -> T:
    """Open a connection, run one service call, and translate domain errors into MCP tool errors."""
    actor = _actor(ctx)
    conn = connect()
    try:
        return fn(conn, actor, **kwargs)
    except DomainError as exc:
        raise ToolError(exc.to_json()) from exc
    finally:
        conn.close()


# ------------------------------------------------------------------ catalogue


@mcp.tool(annotations=READ)
def search_products(
    ctx: Context,
    query: Annotated[str, Field(description="Words, Hindi or English, e.g. 'OPC 53 cement', '8 mm sariya'")] = "",
    category: Annotated[str | None, Field(description="Cement, Steel, Pipes, Fasteners, Finishes or Electrical")] = None,
    size: Annotated[str | None, Field(description="Size such as '8 mm' or '2 inch'")] = None,
    grade: Annotated[str | None, Field(description="Grade such as 'OPC 53' or 'Fe 500D'")] = None,
    sku: Annotated[str | None, Field(description="Exact SKU")] = None,
    in_stock_only: bool = False,
    limit: Annotated[int, Field(ge=1, le=50)] = 20,
) -> ProductSearchResult:
    """Search the distributor catalogue by words, category, size, grade or SKU.

    Returns canonical units, specifications, illustrative prices and current availability. When a request
    matches several variants (e.g. 'cement' or 'TMT bar' without a diameter), needs_clarification is true and
    the human must pick one - never guess.
    """
    return _run(ctx, lambda conn, actor, **kw: catalog.search_products(conn, **kw), query=query, category=category,
                size=size, grade=grade, sku=sku, in_stock_only=in_stock_only, limit=limit)


# ------------------------------------------------------------------ order creation


@mcp.tool(annotations=WRITE)
def create_draft_order(
    ctx: Context,
    lines: Annotated[list[LineInput], Field(min_length=1, max_length=25)],
    distributor_id: str = "DIS-SHARMA",
    requested_delivery_date: Annotated[str | None, Field(description="YYYY-MM-DD")] = None,
    notes: str | None = None,
) -> ActionResult:
    """Retailer only. Create an order DRAFT from catalogue SKUs, quantities and units.

    Lines are validated deterministically (SKU exists, unit is allowed, quantity is a valid number). A draft is
    not sent to the distributor until submit_order is called after the human confirms it.
    """
    return _run(ctx, orders.create_draft_order, lines=lines, distributor_id=distributor_id,
                requested_delivery_date=requested_delivery_date, notes=notes)


@mcp.tool(annotations=READ)
def validate_order(
    ctx: Context,
    order_id: Annotated[str | None, Field(description="Existing order id, e.g. DS-1042")] = None,
    lines: Annotated[list[LineInput] | None, Field(description="Or validate these lines without saving")] = None,
    distributor_id: str = "DIS-SHARMA",
) -> ValidationResult:
    """Check specifications, units, quantity format and the distributor's current availability.

    Partial availability is reported honestly per line. Nothing is written.
    """
    return _run(ctx, orders.validate_order, order_id=order_id, lines=lines, distributor_id=distributor_id)


@mcp.tool(annotations=WRITE)
def submit_order(ctx: Context, order_id: str) -> ActionResult:
    """Retailer only. Send a reviewed draft to the distributor (status becomes pending_confirmation)."""
    return _run(ctx, orders.submit_order, order_id=order_id)


@mcp.tool(annotations=WRITE)
def confirm_order(
    ctx: Context,
    order_id: str,
    lines: Annotated[
        list[ConfirmLineInput] | None,
        Field(description="Per-line confirmed quantities. Omit to confirm every line in full."),
    ] = None,
    revised_delivery_date: Annotated[str | None, Field(description="YYYY-MM-DD, if the date changes")] = None,
    notes: str | None = None,
) -> ActionResult:
    """Distributor only. Confirm requested quantities, or record a partial quantity when stock is short."""
    return _run(ctx, orders.confirm_order, order_id=order_id, lines=lines,
                revised_delivery_date=revised_delivery_date, notes=notes)


# ------------------------------------------------------------------ reads


@mcp.tool(annotations=READ)
def list_orders(
    ctx: Context,
    status: Annotated[
        str | None,
        Field(description="Comma-separated: draft, pending_confirmation, confirmed, in_transit, delivered, "
                          "needs_review, resolved"),
    ] = None,
    has_discrepancy: Annotated[bool | None, Field(description="true = only orders with an unresolved difference")] = None,
    search: Annotated[str | None, Field(description="Order id or product words")] = None,
    category: str | None = None,
    date_from: Annotated[str | None, Field(description="YYYY-MM-DD")] = None,
    date_to: Annotated[str | None, Field(description="YYYY-MM-DD")] = None,
    limit: Annotated[int, Field(ge=1, le=200)] = 50,
) -> OrderListResult:
    """List orders visible to the caller, newest first, with optional filters."""
    return _run(ctx, orders.list_orders, status=status, has_discrepancy=has_discrepancy, search=search,
                category=category, date_from=date_from, date_to=date_to, limit=limit)


@mcp.tool(annotations=READ)
def get_order_status(ctx: Context, order_id: Annotated[str, Field(description="e.g. DS-1042 or 1042")]) -> OrderOut:
    """Full current record of one order: status, every line's requested / confirmed / dispatched / received
    quantities with the automatic comparison, dispatch and receipt details, discrepancies and next action."""
    return _run(ctx, orders.get_order, order_id=order_id)


@mcp.tool(annotations=READ)
def get_order_timeline(ctx: Context, order_id: str) -> TimelineResult:
    """Chronological audit history of an order. Each event records who acted, when, and through which channel
    (web, assistant, voice, alexa or a direct MCP client)."""
    return _run(ctx, orders.get_timeline, order_id=order_id)


@mcp.tool(annotations=READ)
def list_discrepancies(
    ctx: Context,
    status: Annotated[str | None, Field(description="open, acknowledged, under_review, resolved or unresolved")] = None,
    order_id: str | None = None,
) -> DiscrepancyListResult:
    """List delivery discrepancies with their notes and resolutions (unresolved first)."""
    return _run(ctx, orders.list_discrepancies, status=status, order_id=order_id)


@mcp.tool(annotations=READ)
def get_dashboard_summary(ctx: Context) -> DashboardSummary:
    """Order counts and attention lists for the caller, computed live from persisted records."""
    return _run(ctx, lambda conn, actor: dashboard.get_dashboard_summary(conn, actor))


# ------------------------------------------------------------------ fulfilment


@mcp.tool(annotations=WRITE)
def record_dispatch(
    ctx: Context,
    order_id: str,
    challan_ref: Annotated[str, Field(description="Delivery challan / dispatch reference")],
    lines: Annotated[
        list[DispatchLineInput] | None, Field(description="Per-line dispatched quantities. Omit to dispatch the confirmed quantities.")
    ] = None,
    dispatched_at: Annotated[str | None, Field(description="ISO-8601 date-time; defaults to now")] = None,
    expected_delivery_date: Annotated[str | None, Field(description="YYYY-MM-DD")] = None,
    eway_bill_ref: str | None = None,
    vehicle_ref: str | None = None,
    driver_note: str | None = None,
    notes: str | None = None,
) -> ActionResult:
    """Distributor only. Record what was loaded for delivery. Milestone tracking only - no live GPS."""
    return _run(ctx, orders.record_dispatch, order_id=order_id, challan_ref=challan_ref, lines=lines,
                dispatched_at=dispatched_at, expected_delivery_date=expected_delivery_date,
                eway_bill_ref=eway_bill_ref, vehicle_ref=vehicle_ref, driver_note=driver_note, notes=notes)


@mcp.tool(annotations=WRITE)
def record_delivery(
    ctx: Context,
    order_id: str,
    lines: Annotated[list[ReceiptLineInput], Field(min_length=1, description="Received quantity for EVERY line")],
    received_at: Annotated[str | None, Field(description="ISO-8601 date-time; defaults to now")] = None,
    condition_notes: str | None = None,
    evidence_file: Annotated[
        str | None, Field(pattern=r"^[a-f0-9]{32}\.(jpg|png|webp)$", description="Evidence photo id from the website upload")
    ] = None,
) -> ActionResult:
    """Retailer only. Record counted quantities at the shop. The system compares them with the dispatch record
    and automatically opens a discrepancy for any short, excess or damaged quantity."""
    return _run(ctx, orders.record_delivery, order_id=order_id, lines=lines, received_at=received_at,
                condition_notes=condition_notes, evidence_file=evidence_file)


@mcp.tool(annotations=WRITE)
def report_discrepancy(
    ctx: Context,
    order_id: str,
    line_id: int,
    kind: Annotated[str, Field(description="short, excess, damaged or other")],
    quantity: float,
    description: str,
) -> ActionResult:
    """Retailer or distributor. Manually report a difference found after receipt (e.g. damage noticed later)."""
    return _run(ctx, orders.report_discrepancy, order_id=order_id, line_id=line_id, kind=kind, quantity=quantity,
                description=description)


@mcp.tool(annotations=WRITE)
def add_discrepancy_note(
    ctx: Context,
    discrepancy_id: Annotated[str, Field(description="e.g. DSC-2004")],
    note: str,
    acknowledge: Annotated[bool, Field(description="true to formally acknowledge the discrepancy")] = False,
) -> ActionResult:
    """Retailer or distributor. Add a note to a discrepancy, optionally acknowledging it."""
    return _run(ctx, orders.add_discrepancy_note, discrepancy_id=discrepancy_id, note=note, acknowledge=acknowledge)


@mcp.tool(annotations=WRITE)
def resolve_discrepancy(
    ctx: Context,
    discrepancy_id: str,
    resolution_type: Annotated[
        str, Field(description="supply_remaining, credit_note, under_review, no_adjustment or other")
    ],
    notes: Annotated[str, Field(description="The decision and why")],
    follow_up_qty: float | None = None,
) -> ActionResult:
    """Retailer or distributor. Record a resolution. Original order, dispatch and receipt values are preserved;
    under_review keeps the discrepancy open."""
    return _run(ctx, orders.resolve_discrepancy, discrepancy_id=discrepancy_id, resolution_type=resolution_type,
                notes=notes, follow_up_qty=follow_up_qty)


# ------------------------------------------------------------------ HTTP plumbing


@mcp.custom_route("/health", methods=["GET"])
async def health(_: Request) -> JSONResponse:
    tools = await mcp.list_tools()
    return JSONResponse({
        "status": "ok",
        "server": "dukaan-sathi",
        "transport": "streamable-http",
        "endpoint": "/mcp",
        "handshake_protocol_versions": list(HANDSHAKE_PROTOCOL_VERSIONS),
        "modern_protocol_versions": list(MODERN_PROTOCOL_VERSIONS),
        "tool_count": len(tools),
        "auth": "bearer token required on /mcp",
    })


class BearerAuthMiddleware:
    """Reject /mcp requests without a known bearer token, and apply a simple per-token rate limit."""

    def __init__(self, app: ASGIApp, per_minute: int = 300):
        self.app = app
        self.per_minute = per_minute
        self.hits: dict[str, deque[float]] = defaultdict(deque)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or not scope["path"].startswith("/mcp"):
            await self.app(scope, receive, send)
            return
        headers = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        role = _role_for_token(headers.get("authorization", ""))
        if role is None:
            body = {"error": {"code": "unauthorized", "message": "Bearer token required for the Dukaan Sathi MCP endpoint."}}
            await JSONResponse(body, status_code=401, headers={"WWW-Authenticate": 'Bearer realm="dukaan-sathi"'})(scope, receive, send)
            return
        window = self.hits[role]
        now = time.monotonic()
        while window and now - window[0] > 60:
            window.popleft()
        if len(window) >= self.per_minute:
            await JSONResponse({"error": {"code": "rate_limited", "message": "Too many requests; slow down."}},
                               status_code=429)(scope, receive, send)
            return
        window.append(now)
        await self.app(scope, receive, send)


def build_app():
    security = TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=settings.mcp_allowed_hosts(),
        allowed_origins=[f"http://{h}" for h in ("localhost:5173", "127.0.0.1:5173", "localhost:6274", "127.0.0.1:6274")]
        + ([settings.mcp_public_url.rstrip("/").rsplit("/mcp", 1)[0]] if settings.mcp_public_url else []),
    )
    app = mcp.streamable_http_app(
        streamable_http_path="/mcp",
        json_response=True,
        stateless_http=True,
        transport_security=security,
        host=settings.mcp_host,
    )
    app.add_middleware(BearerAuthMiddleware, per_minute=max(60, settings.write_rate_limit_per_minute * 5))
    return app


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if settings.mcp_public_url and settings.uses_default_tokens:
        raise SystemExit(
            "MCP_PUBLIC_URL is set but the default development tokens are still in use. "
            "Set MCP_RETAILER_TOKEN and MCP_DISTRIBUTOR_TOKEN to long random values in .env first."
        )
    ensure_database()
    log.info("Dukaan Sathi MCP server on http://%s:%s/mcp (protocols: %s)", settings.mcp_host, settings.mcp_port,
             ", ".join([*HANDSHAKE_PROTOCOL_VERSIONS[-1:], *MODERN_PROTOCOL_VERSIONS]))
    uvicorn.run(build_app(), host=settings.mcp_host, port=settings.mcp_port, log_level="info")


if __name__ == "__main__":
    main()
