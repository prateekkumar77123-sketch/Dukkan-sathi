"""SQLite access: schema, connections and transactions.

Both the MCP server (which owns all business reads and writes) and the gateway's
admin-only demo reset use this module, so there is exactly one database file.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path

from app.config import settings

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS parties (
    id            TEXT PRIMARY KEY,
    kind          TEXT NOT NULL CHECK (kind IN ('retailer', 'distributor')),
    name          TEXT NOT NULL,
    name_hi       TEXT NOT NULL,
    city          TEXT NOT NULL,
    contact_name  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id              TEXT PRIMARY KEY,           -- SKU
    name            TEXT NOT NULL,
    name_hi         TEXT NOT NULL,
    category        TEXT NOT NULL,
    grade           TEXT,
    size            TEXT,
    spec            TEXT NOT NULL,
    spec_hi         TEXT NOT NULL,
    unit            TEXT NOT NULL,              -- canonical unit
    alt_unit        TEXT,                       -- optional convertible unit
    alt_per_unit    INTEGER,                    -- how many alt units make one canonical unit
    standard        TEXT,                       -- e.g. BIS standard reference
    hsn             TEXT,
    gst_rate        REAL,
    price_paise     INTEGER NOT NULL,           -- illustrative, not a market quote
    keywords        TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS distributor_stock (
    distributor_id  TEXT NOT NULL REFERENCES parties(id),
    product_id      TEXT NOT NULL REFERENCES products(id),
    available_qty   REAL NOT NULL CHECK (available_qty >= 0),
    PRIMARY KEY (distributor_id, product_id)
);

CREATE TABLE IF NOT EXISTS orders (
    id                      TEXT PRIMARY KEY,
    retailer_id             TEXT NOT NULL REFERENCES parties(id),
    distributor_id          TEXT NOT NULL REFERENCES parties(id),
    status                  TEXT NOT NULL CHECK (status IN (
                                'draft', 'pending_confirmation', 'confirmed', 'in_transit',
                                'delivered', 'needs_review', 'resolved')),
    created_at              TEXT NOT NULL,
    submitted_at            TEXT,
    confirmed_at            TEXT,
    requested_delivery_date TEXT,
    revised_delivery_date   TEXT,
    notes                   TEXT,
    distributor_notes       TEXT,
    is_sample               INTEGER NOT NULL DEFAULT 0,
    updated_at              TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS order_lines (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id          TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    line_no           INTEGER NOT NULL,
    product_id        TEXT NOT NULL REFERENCES products(id),
    unit              TEXT NOT NULL,
    requested_qty     REAL NOT NULL CHECK (requested_qty > 0),
    confirmed_qty     REAL CHECK (confirmed_qty >= 0),
    dispatched_qty    REAL CHECK (dispatched_qty >= 0),
    received_qty      REAL CHECK (received_qty >= 0),
    damaged_qty       REAL CHECK (damaged_qty >= 0),
    unit_price_paise  INTEGER NOT NULL,
    UNIQUE (order_id, line_no)
);

CREATE TABLE IF NOT EXISTS dispatches (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id                TEXT NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
    challan_ref             TEXT NOT NULL,
    eway_bill_ref           TEXT,
    vehicle_ref             TEXT,
    driver_note             TEXT,
    notes                   TEXT,
    dispatched_at           TEXT NOT NULL,
    expected_delivery_date  TEXT,
    recorded_by             TEXT NOT NULL,
    recorded_at             TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS receipts (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id         TEXT NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
    received_at      TEXT NOT NULL,
    condition_notes  TEXT,
    evidence_file    TEXT,
    recorded_by      TEXT NOT NULL,
    recorded_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS discrepancies (
    id              TEXT PRIMARY KEY,
    order_id        TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    line_id         INTEGER NOT NULL REFERENCES order_lines(id) ON DELETE CASCADE,
    kind            TEXT NOT NULL CHECK (kind IN ('short', 'excess', 'damaged', 'other')),
    expected_qty    REAL,
    observed_qty    REAL,
    difference_qty  REAL NOT NULL,
    unit            TEXT NOT NULL,
    status          TEXT NOT NULL CHECK (status IN ('open', 'acknowledged', 'under_review', 'resolved')),
    detected_by     TEXT NOT NULL,              -- 'system' or the reporting role
    detected_at     TEXT NOT NULL,
    description     TEXT NOT NULL,
    description_hi  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS discrepancy_notes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    discrepancy_id  TEXT NOT NULL REFERENCES discrepancies(id) ON DELETE CASCADE,
    author_role     TEXT NOT NULL,
    author_name     TEXT NOT NULL,
    kind            TEXT NOT NULL CHECK (kind IN ('note', 'acknowledgement')),
    note            TEXT NOT NULL,
    source          TEXT NOT NULL,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS resolutions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    discrepancy_id   TEXT NOT NULL REFERENCES discrepancies(id) ON DELETE CASCADE,
    resolution_type  TEXT NOT NULL CHECK (resolution_type IN (
                         'supply_remaining', 'credit_note', 'under_review', 'no_adjustment', 'other')),
    follow_up_qty    REAL,
    notes            TEXT NOT NULL,
    decided_by_role  TEXT NOT NULL,
    decided_by_name  TEXT NOT NULL,
    source           TEXT NOT NULL,
    decided_at       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    at          TEXT NOT NULL,
    actor_role  TEXT NOT NULL,
    actor_name  TEXT NOT NULL,
    event_type  TEXT NOT NULL,
    summary     TEXT NOT NULL,
    summary_hi  TEXT NOT NULL,
    source      TEXT NOT NULL,
    data        TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS meta (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_lines_order ON order_lines(order_id);
CREATE INDEX IF NOT EXISTS idx_events_order ON audit_events(order_id, at);
CREATE INDEX IF NOT EXISTS idx_disc_order ON discrepancies(order_id);
"""

DATA_TABLES = (
    "audit_events",
    "resolutions",
    "discrepancy_notes",
    "discrepancies",
    "receipts",
    "dispatches",
    "order_lines",
    "orders",
    "distributor_stock",
    "products",
    "parties",
    "meta",
)


def utc_now() -> datetime:
    return datetime.now(UTC).replace(microsecond=0)


def iso(dt: datetime) -> str:
    """Store every timestamp as UTC ISO-8601 with a trailing Z."""
    return dt.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def now_iso() -> str:
    return iso(utc_now())


def connect(db_path: Path | None = None) -> sqlite3.Connection:
    path = db_path or settings.database_path
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """BEGIN IMMEDIATE ... COMMIT, rolling back on any exception."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)


def is_seeded(conn: sqlite3.Connection) -> bool:
    row = conn.execute("SELECT value FROM meta WHERE key = 'seeded_at'").fetchone()
    return row is not None


def ensure_database(db_path: Path | None = None) -> None:
    """Create the schema and seed sample data on first start only (never on reload)."""
    from app.seed import seed_database

    conn = connect(db_path)
    try:
        init_schema(conn)
        if not is_seeded(conn):
            seed_database(conn, mode="full")
    finally:
        conn.close()
