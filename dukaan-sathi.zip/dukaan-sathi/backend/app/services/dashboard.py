"""Dashboard figures, always computed from the persisted order records."""

from __future__ import annotations

import sqlite3

from app.db import now_iso
from app.domain.actors import Actor
from app.domain.models import DashboardSummary, StatusCount
from app.services.orders import _scope_clause, recent_events, summarise_order


def get_dashboard_summary(conn: sqlite3.Connection, actor: Actor) -> DashboardSummary:
    where, params = _scope_clause(actor)
    rows = conn.execute(f"SELECT o.* FROM orders o WHERE {where} ORDER BY o.created_at DESC", params).fetchall()
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    submitted = [r for r in rows if r["status"] != "draft"]
    party = conn.execute("SELECT name, name_hi FROM parties WHERE id = ?", (actor.party_id,)).fetchone()
    open_disc = conn.execute(
        f"""SELECT COUNT(*) FROM discrepancies d JOIN orders o ON o.id = d.order_id
            WHERE {where} AND d.status != 'resolved'""",
        params,
    ).fetchone()[0]

    def pick(statuses: tuple[str, ...], limit: int = 6):
        return [summarise_order(conn, r) for r in rows if r["status"] in statuses][:limit]

    order_of_statuses = ["draft", "pending_confirmation", "confirmed", "in_transit", "needs_review", "delivered", "resolved"]
    return DashboardSummary(
        role=actor.role,
        party_name=party["name"],
        party_name_hi=party["name_hi"],
        is_sample_data=any(r["is_sample"] for r in rows),
        total_orders=len(submitted),
        in_transit=counts.get("in_transit", 0),
        needs_review=counts.get("needs_review", 0),
        delivered=counts.get("delivered", 0) + counts.get("resolved", 0),
        resolved=counts.get("resolved", 0),
        pending_confirmation=counts.get("pending_confirmation", 0),
        confirmed_awaiting_dispatch=counts.get("confirmed", 0),
        drafts=counts.get("draft", 0),
        open_discrepancies=open_disc,
        status_breakdown=[StatusCount(status=s, count=counts.get(s, 0)) for s in order_of_statuses if counts.get(s, 0)],
        attention=pick(("needs_review",)),
        pending_confirmations=pick(("pending_confirmation", "draft") if actor.role == "retailer" else ("pending_confirmation",)),
        shipments=pick(("confirmed", "in_transit")),
        recent_orders=[summarise_order(conn, r) for r in submitted[:6]],
        recent_activity=recent_events(conn, actor, 8),
        computed_at=now_iso(),
    )
