"""Product catalogue search and lookup."""

from __future__ import annotations

import re
import sqlite3

from app.domain.actors import DISTRIBUTOR_ID
from app.domain.errors import NotFoundError
from app.domain.models import ProductOut, ProductSearchResult
from app.domain.rules import unit_label

# Hindi / Hinglish trade words mapped to the English tokens used in product keywords.
TERM_MAP = {
    "सीमेंट": "cement", "सिमेंट": "cement", "cement": "cement", "siment": "cement",
    "सरिया": "tmt", "सरिये": "tmt", "saria": "tmt", "sariya": "tmt", "sariya,": "tmt", "छड़": "tmt", "rebar": "tmt",
    "पाइप": "pipe", "pipe": "pipe", "pipes": "pipe",
    "पेंच": "screw", "स्क्रू": "screw", "screws": "screw", "screw": "screw",
    "तार": "wire", "वायर": "wire", "taar": "wire", "tar": "wire",
    "पुट्टी": "putty", "पुटी": "putty", "putti": "putty",
    "कंड्यूट": "conduit", "कंड्यूट्स": "conduit", "conduits": "conduit",
    "बाइंडिंग": "binding", "ओपीसी": "opc", "पीपीसी": "ppc", "टीएमटी": "tmt",
    "इंच": "inch", "मिमी": "mm", "एमएम": "mm",
}

STOPWORDS = {
    "the", "a", "an", "of", "for", "from", "and", "me", "show", "find", "need", "i", "want", "order", "grade",
    "को", "का", "की", "के", "में", "और", "से", "चाहिए", "दिखाओ", "ऑर्डर",
}

LOW_STOCK_THRESHOLD = 20


def normalise_text(text: str) -> str:
    t = text.lower().replace("’", "'").replace("”", '"').replace("“", '"')
    # 2", 2-inch, 2 inch, 2 इंच -> 2inch ; 8 mm, 8-mm, 8मिमी -> 8mm
    t = re.sub(r"(\d+(?:\.\d+)?)\s*(?:\"|-?\s*inch(?:es)?|-?\s*इंच)", r"\1inch ", t)
    t = re.sub(r"(\d+(?:\.\d+)?)\s*-?\s*(?:mm|मिमी|एमएम|millimet(?:er|re)s?)\b", r"\1mm ", t)
    t = re.sub(r"(\d+(?:\.\d+)?)\s*-?\s*(?:mm|मिमी|एमएम)", r"\1mm ", t)
    t = re.sub(r"fe\s*-?\s*500\s*-?\s*d", "fe500d", t)
    t = re.sub(r"opc\s*-?\s*(53|43)", r"opc \1", t)
    return t


def tokens(text: str) -> list[str]:
    out: list[str] = []
    for raw in re.split(r"[\s,.;:!?()/]+", normalise_text(text)):
        if not raw:
            continue
        tok = TERM_MAP.get(raw, raw)
        if tok in STOPWORDS:
            continue
        out.append(tok)
    return out


def _row_to_product(row: sqlite3.Row, available: float) -> ProductOut:
    if available <= 0:
        availability = "out_of_stock"
    elif available < LOW_STOCK_THRESHOLD:
        availability = "low_stock"
    else:
        availability = "in_stock"
    return ProductOut(
        sku=row["id"],
        name=row["name"],
        name_hi=row["name_hi"],
        category=row["category"],
        grade=row["grade"],
        size=row["size"],
        spec=row["spec"],
        spec_hi=row["spec_hi"],
        unit=row["unit"],
        unit_label=unit_label(row["unit"]),
        unit_label_hi=unit_label(row["unit"], lang="hi"),
        alt_unit=row["alt_unit"],
        alt_per_unit=row["alt_per_unit"],
        standard=row["standard"],
        hsn=row["hsn"],
        gst_rate=row["gst_rate"],
        price_inr=row["price_paise"] / 100,
        available_qty=available,
        availability=availability,  # type: ignore[arg-type]
    )


def _stock(conn: sqlite3.Connection, distributor_id: str) -> dict[str, float]:
    rows = conn.execute(
        "SELECT product_id, available_qty FROM distributor_stock WHERE distributor_id = ?", (distributor_id,)
    ).fetchall()
    return {r["product_id"]: r["available_qty"] for r in rows}


def get_product(conn: sqlite3.Connection, sku: str, distributor_id: str = DISTRIBUTOR_ID) -> ProductOut:
    row = conn.execute("SELECT * FROM products WHERE upper(id) = upper(?)", (sku.strip(),)).fetchone()
    if row is None:
        raise NotFoundError(
            f"No catalogue product has SKU '{sku}'. Use search_products to find a valid SKU.",
            message_hi=f"'{sku}' SKU वाला कोई उत्पाद कैटलॉग में नहीं है।",
            details={"sku": sku},
        )
    return _row_to_product(row, _stock(conn, distributor_id).get(row["id"], 0))


def search_products(
    conn: sqlite3.Connection,
    query: str = "",
    *,
    category: str | None = None,
    size: str | None = None,
    grade: str | None = None,
    sku: str | None = None,
    in_stock_only: bool = False,
    limit: int = 20,
    distributor_id: str = DISTRIBUTOR_ID,
) -> ProductSearchResult:
    rows = conn.execute("SELECT * FROM products ORDER BY category, id").fetchall()
    stock = _stock(conn, distributor_id)
    query_tokens = tokens(query or "")

    scored: list[tuple[int, sqlite3.Row]] = []
    for row in rows:
        if sku and row["id"].upper() != sku.strip().upper():
            continue
        if category and row["category"].lower() != category.strip().lower():
            continue
        if size and normalise_text(size).strip().replace(" ", "") != normalise_text(row["size"] or "").strip().replace(" ", ""):
            continue
        if grade and (grade.strip().lower() not in (row["grade"] or "").lower()):
            continue
        if in_stock_only and stock.get(row["id"], 0) <= 0:
            continue
        haystack = set(tokens(" ".join([row["id"], row["name"], row["category"], row["grade"] or "",
                                        row["size"] or "", row["keywords"]])))
        haystack |= {row["id"].lower()}
        if query_tokens:
            score = sum(1 for t in query_tokens if t in haystack)
            if score == 0:
                continue
        else:
            score = 1
        scored.append((score, row))

    if not scored:
        return ProductSearchResult(
            query=query, count=0, products=[], needs_clarification=False,
            clarification=f"No catalogue products match '{query}'.",
            clarification_hi=f"'{query}' से मेल खाता कोई उत्पाद नहीं मिला।",
        )

    best = max(s for s, _ in scored)
    matches = [r for s, r in scored if s == best][: max(1, min(limit, 50))]
    products = [_row_to_product(r, stock.get(r["id"], 0)) for r in matches]

    needs_clarification = False
    clarification = clarification_hi = None
    if query_tokens and len(products) > 1:
        needs_clarification = True
        options = ", ".join(f"{p.name} ({p.sku})" for p in products[:6])
        options_hi = ", ".join(f"{p.name_hi} ({p.sku})" for p in products[:6])
        clarification = f"'{query}' matches {len(products)} different products. Please choose one: {options}."
        clarification_hi = f"'{query}' से {len(products)} अलग उत्पाद मेल खाते हैं। कृपया एक चुनें: {options_hi}।"

    return ProductSearchResult(
        query=query,
        count=len(products),
        products=products,
        needs_clarification=needs_clarification,
        clarification=clarification,
        clarification_hi=clarification_hi,
    )
