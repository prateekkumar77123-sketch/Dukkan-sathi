"""Order lifecycle: draft → submitted → confirmed → dispatched → received → (discrepancy) → resolved.

Every state change runs in a transaction and writes an audit event. Quantities recorded at each
stage (confirmed / dispatched / received) are written once and never overwritten by later steps,
so the original evidence is always preserved.
"""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import UTC, date, datetime, timedelta
from typing import Any

from app.db import iso, now_iso, transaction, utc_now
from app.domain.actors import Actor
from app.domain.errors import InvalidTransition, NotFoundError, ValidationFailed
from app.domain.models import (
    ActionResult,
    ConfirmLineInput,
    DiscrepancyListResult,
    DiscrepancyNoteOut,
    DiscrepancyOut,
    DispatchLineInput,
    DispatchOut,
    LineComparisonOut,
    LineInput,
    LineValidation,
    OrderLineOut,
    OrderListResult,
    OrderOut,
    OrderSummaryOut,
    PartyOut,
    ReceiptLineInput,
    ReceiptOut,
    ResolutionOut,
    TimelineEventOut,
    TimelineResult,
    ValidationResult,
)
from app.domain.rules import (
    compare_line,
    convert_to_canonical,
    fmt_qty,
    qty_with_unit,
    unit_label,
    validate_quantity,
)
from app.services.catalog import get_product

EWAY_BILL_THRESHOLD_INR = 50_000

STATUS_LABELS = {
    "draft": ("Draft", "ड्राफ्ट"),
    "pending_confirmation": ("Awaiting distributor confirmation", "डिस्ट्रीब्यूटर की पुष्टि बाकी"),
    "confirmed": ("Confirmed, awaiting dispatch", "पुष्टि हो गई, डिस्पैच बाकी"),
    "in_transit": ("In transit", "रास्ते में"),
    "delivered": ("Delivered", "डिलीवर हो गया"),
    "needs_review": ("Needs review", "जाँच ज़रूरी"),
    "resolved": ("Delivered, difference resolved", "डिलीवर, अंतर का समाधान हुआ"),
}

RESOLUTION_LABELS = {
    "supply_remaining": ("Remaining quantity to be supplied", "बाकी मात्रा भेजी जाएगी"),
    "credit_note": ("Credit / adjustment agreed", "क्रेडिट / समायोजन पर सहमति"),
    "under_review": ("Quantity difference under review", "अंतर की जाँच चल रही है"),
    "no_adjustment": ("No adjustment required", "कोई समायोजन ज़रूरी नहीं"),
    "other": ("Other agreed resolution", "अन्य सहमत समाधान"),
}

KIND_LABELS = {
    "short": ("short delivery", "कम डिलीवरी"),
    "excess": ("excess delivery", "अधिक डिलीवरी"),
    "damaged": ("damaged quantity", "क्षतिग्रस्त माल"),
    "other": ("other difference", "अन्य अंतर"),
}


# ---------------------------------------------------------------- helpers


def normalise_order_id(raw: str) -> str:
    """Accept '1042', 'ds1042', 'DS 1042', 'डीएस-1042' and return 'DS-1042'."""
    text = (raw or "").strip()
    digits = re.findall(r"\d+", text)
    if not digits:
        raise ValidationFailed(
            f"'{raw}' is not a valid order number. Order numbers look like DS-1042.",
            message_hi=f"'{raw}' सही ऑर्डर नंबर नहीं है। ऑर्डर नंबर DS-1042 जैसा होता है।",
            details={"order_id": raw},
        )
    return f"DS-{int(''.join(digits))}"


def _paise_to_inr(p: float) -> float:
    return round(p / 100, 2)


def _parse_ts(value: str | None, field: str) -> datetime | None:
    if value in (None, ""):
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValidationFailed(
            f"{field} must be an ISO-8601 date-time, e.g. 2026-10-23T15:10:00+05:30.",
            message_hi=f"{field} सही तारीख-समय प्रारूप में होना चाहिए।",
            details={"field": field, "value": value},
        ) from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    if dt > utc_now() + timedelta(minutes=5):
        raise ValidationFailed(
            f"{field} cannot be in the future.",
            message_hi=f"{field} भविष्य का नहीं हो सकता।",
            details={"field": field, "value": value},
        )
    return dt


def _parse_date(value: str | None, field: str) -> str | None:
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(value[:10]).isoformat()
    except ValueError as exc:
        raise ValidationFailed(
            f"{field} must be a date in YYYY-MM-DD format.",
            message_hi=f"{field} YYYY-MM-DD प्रारूप में होनी चाहिए।",
            details={"field": field, "value": value},
        ) from exc


def _clean_text(value: str | None, field: str, max_len: int = 1000) -> str | None:
    if value is None:
        return None
    text = value.strip()
    if not text:
        return None
    if len(text) > max_len:
        raise ValidationFailed(
            f"{field} is too long (maximum {max_len} characters).",
            message_hi=f"{field} बहुत लंबा है (अधिकतम {max_len} अक्षर)।",
            details={"field": field},
        )
    return text


def record_event(
    conn: sqlite3.Connection,
    order_id: str,
    actor: Actor | None,
    event_type: str,
    summary: str,
    summary_hi: str,
    data: dict[str, Any] | None = None,
    at: str | None = None,
) -> None:
    conn.execute(
        """INSERT INTO audit_events (order_id, at, actor_role, actor_name, event_type, summary, summary_hi, source, data)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            order_id,
            at or now_iso(),
            actor.role if actor else "system",
            actor.display_name if actor else "Dukaan Sathi (automatic check)",
            event_type,
            summary,
            summary_hi,
            actor.source if actor else "system",
            json.dumps(data or {}, ensure_ascii=False),
        ),
    )


def _order_row(conn: sqlite3.Connection, actor: Actor, order_id: str) -> sqlite3.Row:
    oid = normalise_order_id(order_id)
    row = conn.execute("SELECT * FROM orders WHERE id = ?", (oid,)).fetchone()
    visible = row is not None and (
        (actor.role == "retailer" and row["retailer_id"] == actor.party_id)
        or (actor.role == "distributor" and row["distributor_id"] == actor.party_id and row["status"] != "draft")
    )
    if not visible:
        raise NotFoundError(
            f"Order {oid} was not found.",
            message_hi=f"ऑर्डर {oid} नहीं मिला।",
            details={"order_id": oid},
        )
    return row


def _require_status(row: sqlite3.Row, allowed: tuple[str, ...], action: str, action_hi: str) -> None:
    if row["status"] not in allowed:
        cur_en, cur_hi = STATUS_LABELS[row["status"]]
        raise InvalidTransition(
            f"Cannot {action} order {row['id']} because its status is '{cur_en}'.",
            message_hi=f"ऑर्डर {row['id']} की स्थिति '{cur_hi}' है, इसलिए {action_hi} नहीं किया जा सकता।",
            details={"order_id": row["id"], "status": row["status"], "allowed_from": list(allowed)},
        )


def _party(conn: sqlite3.Connection, party_id: str) -> PartyOut:
    r = conn.execute("SELECT * FROM parties WHERE id = ?", (party_id,)).fetchone()
    return PartyOut(id=r["id"], name=r["name"], name_hi=r["name_hi"], city=r["city"], contact_name=r["contact_name"])


def _line_rows(conn: sqlite3.Connection, order_id: str) -> list[sqlite3.Row]:
    return conn.execute(
        """SELECT l.*, p.name AS product_name, p.name_hi AS product_name_hi, p.category, p.spec, p.spec_hi,
                  p.grade, p.size
           FROM order_lines l JOIN products p ON p.id = l.product_id
           WHERE l.order_id = ? ORDER BY l.line_no""",
        (order_id,),
    ).fetchall()


def _headline(lines: list[sqlite3.Row]) -> tuple[str, str]:
    if not lines:
        return "No items", "कोई आइटम नहीं"
    first = lines[0]
    en = f"{qty_with_unit(first['requested_qty'], first['unit'])} {first['product_name']}"
    hi = f"{first['product_name_hi']} — {qty_with_unit(first['requested_qty'], first['unit'], 'hi')}"
    if len(lines) > 1:
        extra = len(lines) - 1
        en += f" + {extra} more item{'s' if extra > 1 else ''}"
        hi += f" + {extra} और आइटम"
    return en, hi


def _discrepancies(conn: sqlite3.Connection, where: str, params: tuple) -> list[DiscrepancyOut]:
    rows = conn.execute(
        f"""SELECT d.*, l.product_id AS sku, p.name AS product_name, p.name_hi AS product_name_hi
            FROM discrepancies d JOIN order_lines l ON l.id = d.line_id JOIN products p ON p.id = l.product_id
            WHERE {where} ORDER BY d.detected_at, d.id""",
        params,
    ).fetchall()
    out: list[DiscrepancyOut] = []
    for r in rows:
        notes = conn.execute(
            "SELECT * FROM discrepancy_notes WHERE discrepancy_id = ? ORDER BY created_at, id", (r["id"],)
        ).fetchall()
        res = conn.execute(
            "SELECT * FROM resolutions WHERE discrepancy_id = ? ORDER BY decided_at, id", (r["id"],)
        ).fetchall()
        out.append(
            DiscrepancyOut(
                id=r["id"],
                order_id=r["order_id"],
                line_id=r["line_id"],
                sku=r["sku"],
                product_name=r["product_name"],
                product_name_hi=r["product_name_hi"],
                kind=r["kind"],
                expected_qty=r["expected_qty"],
                observed_qty=r["observed_qty"],
                difference_qty=r["difference_qty"],
                unit=r["unit"],
                unit_label=unit_label(r["unit"], r["difference_qty"]),
                unit_label_hi=unit_label(r["unit"], lang="hi"),
                status=r["status"],
                detected_by=r["detected_by"],
                detected_at=r["detected_at"],
                description=r["description"],
                description_hi=r["description_hi"],
                notes=[
                    DiscrepancyNoteOut(
                        author_role=n["author_role"], author_name=n["author_name"], kind=n["kind"],
                        note=n["note"], source=n["source"], created_at=n["created_at"],
                    )
                    for n in notes
                ],
                resolutions=[
                    ResolutionOut(
                        resolution_type=x["resolution_type"], follow_up_qty=x["follow_up_qty"], notes=x["notes"],
                        decided_by_role=x["decided_by_role"], decided_by_name=x["decided_by_name"],
                        source=x["source"], decided_at=x["decided_at"],
                    )
                    for x in res
                ],
            )
        )
    return out


def _allowed_actions(status: str, has_open: bool) -> dict[str, list[str]]:
    retailer: list[str] = []
    distributor: list[str] = []
    if status == "draft":
        retailer += ["submit_order"]
    elif status == "pending_confirmation":
        distributor += ["confirm_order"]
    elif status == "confirmed":
        distributor += ["record_dispatch"]
    elif status == "in_transit":
        retailer += ["record_delivery"]
    if status in ("delivered", "needs_review", "resolved"):
        retailer += ["report_discrepancy"]
        distributor += ["report_discrepancy"]
    if has_open:
        retailer += ["add_discrepancy_note", "resolve_discrepancy"]
        distributor += ["add_discrepancy_note", "resolve_discrepancy"]
    return {"retailer": retailer, "distributor": distributor}


NEXT_ACTION = {
    "draft": ("Retailer to review and submit the order.", "रिटेलर ऑर्डर जाँचकर भेजें।"),
    "pending_confirmation": ("Distributor to confirm quantities.", "डिस्ट्रीब्यूटर मात्रा की पुष्टि करें।"),
    "confirmed": ("Distributor to record dispatch.", "डिस्ट्रीब्यूटर डिस्पैच दर्ज करें।"),
    "in_transit": ("Retailer to count goods and record receipt.", "रिटेलर माल गिनकर प्राप्ति दर्ज करें।"),
    "needs_review": ("Both parties to review the difference and record a resolution.",
                     "दोनों पक्ष अंतर देखें और समाधान दर्ज करें।"),
}


def build_order(conn: sqlite3.Connection, row: sqlite3.Row) -> OrderOut:
    lines = _line_rows(conn, row["id"])
    line_out: list[OrderLineOut] = []
    total_paise = 0.0
    partially_confirmed = False
    for ln in lines:
        cmp = compare_line(
            confirmed=ln["confirmed_qty"], dispatched=ln["dispatched_qty"], received=ln["received_qty"],
            damaged=ln["damaged_qty"], unit=ln["unit"],
        )
        if ln["confirmed_qty"] is not None and ln["confirmed_qty"] < ln["requested_qty"]:
            partially_confirmed = True
        qty_for_value = ln["confirmed_qty"] if ln["confirmed_qty"] is not None else ln["requested_qty"]
        value = qty_for_value * ln["unit_price_paise"]
        total_paise += value
        line_out.append(
            OrderLineOut(
                line_id=ln["id"], line_no=ln["line_no"], sku=ln["product_id"], product_name=ln["product_name"],
                product_name_hi=ln["product_name_hi"], category=ln["category"], spec=ln["spec"],
                spec_hi=ln["spec_hi"], grade=ln["grade"], size=ln["size"], unit=ln["unit"],
                unit_label=unit_label(ln["unit"], ln["requested_qty"]), unit_label_hi=unit_label(ln["unit"], lang="hi"),
                requested_qty=ln["requested_qty"], confirmed_qty=ln["confirmed_qty"],
                dispatched_qty=ln["dispatched_qty"], received_qty=ln["received_qty"], damaged_qty=ln["damaged_qty"],
                unit_price_inr=_paise_to_inr(ln["unit_price_paise"]), line_value_inr=_paise_to_inr(value),
                comparison=LineComparisonOut(
                    outcome=cmp.outcome, comparable=cmp.comparable, dispatch_variance=cmp.dispatch_variance,
                    receipt_variance=cmp.receipt_variance, summary=cmp.summary, summary_hi=cmp.summary_hi,
                ),
            )
        )
    d = conn.execute("SELECT * FROM dispatches WHERE order_id = ?", (row["id"],)).fetchone()
    r = conn.execute("SELECT * FROM receipts WHERE order_id = ?", (row["id"],)).fetchone()
    discrepancies = _discrepancies(conn, "d.order_id = ?", (row["id"],))
    open_count = sum(1 for x in discrepancies if x.status != "resolved")
    headline, headline_hi = _headline(lines)
    nxt = NEXT_ACTION.get(row["status"])
    return OrderOut(
        id=row["id"],
        status=row["status"],
        is_sample=bool(row["is_sample"]),
        retailer=_party(conn, row["retailer_id"]),
        distributor=_party(conn, row["distributor_id"]),
        created_at=row["created_at"],
        submitted_at=row["submitted_at"],
        confirmed_at=row["confirmed_at"],
        requested_delivery_date=row["requested_delivery_date"],
        revised_delivery_date=row["revised_delivery_date"],
        notes=row["notes"],
        distributor_notes=row["distributor_notes"],
        lines=line_out,
        dispatch=None if d is None else DispatchOut(
            challan_ref=d["challan_ref"], eway_bill_ref=d["eway_bill_ref"], vehicle_ref=d["vehicle_ref"],
            driver_note=d["driver_note"], notes=d["notes"], dispatched_at=d["dispatched_at"],
            expected_delivery_date=d["expected_delivery_date"], recorded_by=d["recorded_by"],
        ),
        receipt=None if r is None else ReceiptOut(
            received_at=r["received_at"], condition_notes=r["condition_notes"], evidence_file=r["evidence_file"],
            recorded_by=r["recorded_by"],
        ),
        discrepancies=discrepancies,
        open_discrepancy_count=open_count,
        partially_confirmed=partially_confirmed,
        total_value_inr=_paise_to_inr(total_paise),
        headline=headline,
        headline_hi=headline_hi,
        next_action=nxt[0] if nxt else None,
        next_action_hi=nxt[1] if nxt else None,
        allowed_actions=_allowed_actions(row["status"], open_count > 0),
    )


def summarise_order(conn: sqlite3.Connection, row: sqlite3.Row) -> OrderSummaryOut:
    lines = _line_rows(conn, row["id"])
    headline, headline_hi = _headline(lines)
    total = sum(
        (ln["confirmed_qty"] if ln["confirmed_qty"] is not None else ln["requested_qty"]) * ln["unit_price_paise"]
        for ln in lines
    )
    open_count = conn.execute(
        "SELECT COUNT(*) FROM discrepancies WHERE order_id = ? AND status != 'resolved'", (row["id"],)
    ).fetchone()[0]
    d = conn.execute("SELECT expected_delivery_date FROM dispatches WHERE order_id = ?", (row["id"],)).fetchone()
    expected = (d["expected_delivery_date"] if d else None) or row["revised_delivery_date"] or row["requested_delivery_date"]
    names = conn.execute(
        "SELECT (SELECT name FROM parties WHERE id = ?) AS r, (SELECT name FROM parties WHERE id = ?) AS d",
        (row["retailer_id"], row["distributor_id"]),
    ).fetchone()
    return OrderSummaryOut(
        id=row["id"], status=row["status"], is_sample=bool(row["is_sample"]), retailer_name=names["r"],
        distributor_name=names["d"], created_at=row["created_at"], expected_delivery_date=expected,
        headline=headline, headline_hi=headline_hi, line_count=len(lines), total_value_inr=_paise_to_inr(total),
        open_discrepancy_count=open_count, categories=sorted({ln["category"] for ln in lines}),
    )


def _touch(conn: sqlite3.Connection, order_id: str, status: str | None = None) -> None:
    if status:
        conn.execute("UPDATE orders SET status = ?, updated_at = ? WHERE id = ?", (status, now_iso(), order_id))
    else:
        conn.execute("UPDATE orders SET updated_at = ? WHERE id = ?", (now_iso(), order_id))


# ---------------------------------------------------------------- validation


def validate_lines(conn: sqlite3.Connection, distributor_id: str, lines: list[LineInput]) -> ValidationResult:
    if not lines:
        raise ValidationFailed("An order needs at least one line item.", message_hi="ऑर्डर में कम से कम एक आइटम होना चाहिए।")
    if len(lines) > 25:
        raise ValidationFailed("An order can have at most 25 line items.", message_hi="एक ऑर्डर में अधिकतम 25 आइटम हो सकते हैं।")
    results: list[LineValidation] = []
    seen: set[str] = set()
    total = 0.0
    for i, line in enumerate(lines, start=1):
        messages: list[str] = []
        messages_hi: list[str] = []
        try:
            product = get_product(conn, line.sku, distributor_id)
        except NotFoundError as exc:
            results.append(LineValidation(
                line_no=i, sku=line.sku, product_name=None, product_name_hi=None, spec=None,
                requested_qty=line.quantity, requested_unit=line.unit, canonical_qty=None, unit=None,
                conversion_note=None, valid=False, availability="unknown", available_qty=None,
                unit_price_inr=None, line_value_inr=None, messages=[exc.message], messages_hi=[exc.message_hi],
            ))
            continue
        try:
            conv = convert_to_canonical(
                line.quantity, line.unit, product_unit=product.unit, alt_unit=product.alt_unit,
                alt_per_unit=product.alt_per_unit, product_name=product.name,
            )
        except ValidationFailed as exc:
            results.append(LineValidation(
                line_no=i, sku=product.sku, product_name=product.name, product_name_hi=product.name_hi,
                spec=product.spec, requested_qty=line.quantity, requested_unit=line.unit, canonical_qty=None,
                unit=product.unit, conversion_note=None, valid=False, availability="unknown",
                available_qty=product.available_qty, unit_price_inr=product.price_inr, line_value_inr=None,
                messages=[exc.message], messages_hi=[exc.message_hi],
            ))
            continue
        valid = True
        if product.sku in seen:
            valid = False
            messages.append(f"{product.name} appears more than once; combine it into a single line.")
            messages_hi.append(f"{product.name_hi} एक से अधिक बार है; इसे एक ही लाइन में रखें।")
        seen.add(product.sku)
        if conv.converted:
            messages.append(f"Converted: {conv.explanation}.")
            messages_hi.append(f"इकाई बदली गई: {conv.explanation}।")
        available = product.available_qty
        if available <= 0:
            availability = "out_of_stock"
            messages.append(f"{product.name} is currently out of stock with this distributor.")
            messages_hi.append(f"{product.name_hi} अभी इस डिस्ट्रीब्यूटर के पास स्टॉक में नहीं है।")
        elif available < conv.canonical_qty:
            availability = "partial"
            messages.append(
                f"Only {qty_with_unit(available, product.unit)} available of the "
                f"{qty_with_unit(conv.canonical_qty, product.unit)} requested. The distributor may confirm a "
                "partial quantity."
            )
            messages_hi.append(
                f"माँगी गई {qty_with_unit(conv.canonical_qty, product.unit, 'hi')} में से केवल "
                f"{qty_with_unit(available, product.unit, 'hi')} उपलब्ध है।"
            )
        else:
            availability = "available"
            messages.append(f"Available: {qty_with_unit(conv.canonical_qty, product.unit)} {product.name}.")
            messages_hi.append(f"उपलब्ध: {product.name_hi} — {qty_with_unit(conv.canonical_qty, product.unit, 'hi')}।")
        value = conv.canonical_qty * product.price_inr
        total += value
        results.append(LineValidation(
            line_no=i, sku=product.sku, product_name=product.name, product_name_hi=product.name_hi,
            spec=product.spec, requested_qty=line.quantity, requested_unit=line.unit,
            canonical_qty=conv.canonical_qty, unit=product.unit, conversion_note=conv.explanation or None,
            valid=valid, availability=availability, available_qty=available, unit_price_inr=product.price_inr,
            line_value_inr=round(value, 2), messages=messages, messages_hi=messages_hi,
        ))
    all_valid = all(r.valid for r in results)
    fully = all_valid and all(r.availability == "available" for r in results)
    if not all_valid:
        summary = "Some lines need attention before this order can be placed."
        summary_hi = "ऑर्डर भेजने से पहले कुछ लाइनों को ठीक करना होगा।"
    elif not fully:
        summary = "The order is valid, but not every item is fully in stock. The distributor will confirm what they can supply."
        summary_hi = "ऑर्डर सही है, पर हर आइटम पूरा स्टॉक में नहीं है। डिस्ट्रीब्यूटर उपलब्ध मात्रा की पुष्टि करेंगे।"
    else:
        summary = "All items, specifications and units are valid and in stock."
        summary_hi = "सभी आइटम, स्पेसिफिकेशन और इकाइयाँ सही हैं और स्टॉक में हैं।"
    return ValidationResult(
        valid=all_valid, fully_available=fully, order_id=None, distributor_id=distributor_id, lines=results,
        total_value_inr=round(total, 2), summary=summary, summary_hi=summary_hi,
    )


def validate_order(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    order_id: str | None = None,
    lines: list[LineInput] | None = None,
    distributor_id: str = "DIS-SHARMA",
) -> ValidationResult:
    if order_id:
        row = _order_row(conn, actor, order_id)
        stored = _line_rows(conn, row["id"])
        result = validate_lines(
            conn, row["distributor_id"],
            [LineInput(sku=ln["product_id"], quantity=ln["requested_qty"], unit=ln["unit"]) for ln in stored],
        )
        result.order_id = row["id"]
        return result
    if lines is None:
        raise ValidationFailed("Provide either order_id or lines to validate.", message_hi="order_id या lines दें।")
    _check_distributor(conn, distributor_id)
    return validate_lines(conn, distributor_id, lines)


def _check_distributor(conn: sqlite3.Connection, distributor_id: str) -> None:
    row = conn.execute("SELECT kind FROM parties WHERE id = ?", (distributor_id,)).fetchone()
    if row is None or row["kind"] != "distributor":
        raise NotFoundError(
            f"Distributor '{distributor_id}' was not found.",
            message_hi=f"डिस्ट्रीब्यूटर '{distributor_id}' नहीं मिला।",
            details={"distributor_id": distributor_id},
        )


# ---------------------------------------------------------------- lifecycle actions


def _next_order_id(conn: sqlite3.Connection) -> str:
    row = conn.execute("SELECT id FROM orders").fetchall()
    numbers = [int(r["id"].split("-")[1]) for r in row if r["id"].startswith("DS-")]
    return f"DS-{(max(numbers) + 1) if numbers else 1001}"


def create_draft_order(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    lines: list[LineInput],
    distributor_id: str = "DIS-SHARMA",
    requested_delivery_date: str | None = None,
    notes: str | None = None,
) -> ActionResult:
    actor.require("retailer", action="create an order draft")
    _check_distributor(conn, distributor_id)
    req_date = _parse_date(requested_delivery_date, "requested_delivery_date")
    notes = _clean_text(notes, "notes")
    validation = validate_lines(conn, distributor_id, lines)
    if not validation.valid:
        problems = "; ".join(m for ln in validation.lines if not ln.valid for m in ln.messages)
        problems_hi = "; ".join(m for ln in validation.lines if not ln.valid for m in ln.messages_hi)
        raise ValidationFailed(
            f"The draft was not created: {problems}",
            message_hi=f"ड्राफ्ट नहीं बना: {problems_hi}",
            details={"validation": validation.model_dump()},
        )
    with transaction(conn):
        oid = _next_order_id(conn)
        ts = now_iso()
        conn.execute(
            """INSERT INTO orders (id, retailer_id, distributor_id, status, created_at, requested_delivery_date,
                                   notes, is_sample, updated_at)
               VALUES (?, ?, ?, 'draft', ?, ?, ?, 0, ?)""",
            (oid, actor.party_id, distributor_id, ts, req_date, notes, ts),
        )
        for i, ln in enumerate(validation.lines, start=1):
            conn.execute(
                """INSERT INTO order_lines (order_id, line_no, product_id, unit, requested_qty, unit_price_paise)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (oid, i, ln.sku, ln.unit, ln.canonical_qty, int(round((ln.unit_price_inr or 0) * 100))),
            )
        items = ", ".join(f"{qty_with_unit(ln.canonical_qty, ln.unit)} {ln.product_name}" for ln in validation.lines)
        items_hi = ", ".join(f"{ln.product_name_hi} {qty_with_unit(ln.canonical_qty, ln.unit, 'hi')}" for ln in validation.lines)
        record_event(conn, oid, actor, "draft_created", f"Order draft created: {items}",
                     f"ऑर्डर ड्राफ्ट बना: {items_hi}", {"lines": [ln.model_dump() for ln in validation.lines]}, ts)
    order = get_order(conn, actor, oid)
    return ActionResult(
        ok=True,
        message=f"Draft {oid} created for {order.headline}. Review it and submit to send it to {order.distributor.name}.",
        message_hi=f"ड्राफ्ट {oid} बन गया ({order.headline_hi})। जाँचकर {order.distributor.name_hi} को भेजें।",
        order=order,
    )


def submit_order(conn: sqlite3.Connection, actor: Actor, *, order_id: str) -> ActionResult:
    actor.require("retailer", action="submit an order")
    row = _order_row(conn, actor, order_id)
    _require_status(row, ("draft",), "submit", "भेजा")
    validation = validate_order(conn, actor, order_id=row["id"])
    if not validation.valid:
        raise ValidationFailed(
            f"Order {row['id']} no longer passes validation: {validation.summary}",
            message_hi=f"ऑर्डर {row['id']} अब सत्यापन में पास नहीं है।",
            details={"validation": validation.model_dump()},
        )
    with transaction(conn):
        ts = now_iso()
        conn.execute("UPDATE orders SET status = 'pending_confirmation', submitted_at = ?, updated_at = ? WHERE id = ?",
                     (ts, ts, row["id"]))
        record_event(conn, row["id"], actor, "order_submitted",
                     "Retailer reviewed and submitted the order to the distributor",
                     "रिटेलर ने ऑर्डर जाँचकर डिस्ट्रीब्यूटर को भेजा", {}, ts)
    order = get_order(conn, actor, row["id"])
    return ActionResult(
        ok=True,
        message=f"Order {row['id']} sent to {order.distributor.name} for confirmation.",
        message_hi=f"ऑर्डर {row['id']} पुष्टि के लिए {order.distributor.name_hi} को भेज दिया गया।",
        order=order,
    )


def confirm_order(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    order_id: str,
    lines: list[ConfirmLineInput] | None = None,
    revised_delivery_date: str | None = None,
    notes: str | None = None,
) -> ActionResult:
    actor.require("distributor", action="confirm an order")
    row = _order_row(conn, actor, order_id)
    _require_status(row, ("pending_confirmation",), "confirm", "पुष्टि")
    revised = _parse_date(revised_delivery_date, "revised_delivery_date")
    notes = _clean_text(notes, "notes")
    stored = {ln["id"]: ln for ln in _line_rows(conn, row["id"])}
    stock = {
        r["product_id"]: r["available_qty"]
        for r in conn.execute("SELECT product_id, available_qty FROM distributor_stock WHERE distributor_id = ?",
                              (row["distributor_id"],))
    }
    given = {c.line_id: c.confirmed_qty for c in (lines or [])}
    unknown = set(given) - set(stored)
    if unknown:
        raise ValidationFailed(
            f"Line ids {sorted(unknown)} do not belong to order {row['id']}.",
            message_hi=f"लाइन {sorted(unknown)} इस ऑर्डर की नहीं है।",
            details={"unknown_line_ids": sorted(unknown)},
        )
    decisions: dict[int, float] = {}
    for lid, ln in stored.items():
        qty = given.get(lid, ln["requested_qty"])
        validate_quantity(qty, ln["unit"], field=f"confirmed_qty (line {ln['line_no']})", allow_zero=True)
        if qty > ln["requested_qty"]:
            raise ValidationFailed(
                f"Line {ln['line_no']}: cannot confirm {qty_with_unit(qty, ln['unit'])}; the retailer requested "
                f"{qty_with_unit(ln['requested_qty'], ln['unit'])}. Suggest a revised quantity in the notes instead.",
                message_hi=f"लाइन {ln['line_no']}: माँगी गई मात्रा से अधिक की पुष्टि नहीं हो सकती।",
                details={"line_id": lid},
            )
        if qty > stock.get(ln["product_id"], 0):
            raise ValidationFailed(
                f"Line {ln['line_no']}: only {qty_with_unit(stock.get(ln['product_id'], 0), ln['unit'])} of "
                f"{ln['product_name']} in stock; confirm a partial quantity.",
                message_hi=f"लाइन {ln['line_no']}: स्टॉक में केवल {qty_with_unit(stock.get(ln['product_id'], 0), ln['unit'], 'hi')} है; "
                "आंशिक मात्रा की पुष्टि करें।",
                details={"line_id": lid, "available_qty": stock.get(ln["product_id"], 0)},
            )
        decisions[lid] = qty
    if all(q == 0 for q in decisions.values()):
        raise ValidationFailed(
            "At least one line must have a confirmed quantity above zero.",
            message_hi="कम से कम एक लाइन की पुष्टि मात्रा शून्य से अधिक होनी चाहिए।",
        )
    with transaction(conn):
        ts = now_iso()
        for lid, qty in decisions.items():
            conn.execute("UPDATE order_lines SET confirmed_qty = ? WHERE id = ?", (qty, lid))
        conn.execute(
            """UPDATE orders SET status = 'confirmed', confirmed_at = ?, revised_delivery_date = ?,
                      distributor_notes = ?, updated_at = ? WHERE id = ?""",
            (ts, revised, notes, ts, row["id"]),
        )
        parts = []
        parts_hi = []
        for lid, qty in decisions.items():
            ln = stored[lid]
            if qty < ln["requested_qty"]:
                parts.append(f"{qty_with_unit(qty, ln['unit'])} of {fmt_qty(ln['requested_qty'])} requested {ln['product_name']}")
                parts_hi.append(f"{ln['product_name_hi']}: {fmt_qty(ln['requested_qty'])} में से {qty_with_unit(qty, ln['unit'], 'hi')}")
            else:
                parts.append(f"{qty_with_unit(qty, ln['unit'])} {ln['product_name']}")
                parts_hi.append(f"{ln['product_name_hi']} {qty_with_unit(qty, ln['unit'], 'hi')}")
        summary = "Distributor confirmed " + "; ".join(parts)
        summary_hi = "डिस्ट्रीब्यूटर ने पुष्टि की: " + "; ".join(parts_hi)
        if revised:
            summary += f". Revised delivery date: {revised}"
            summary_hi += f"। नई डिलीवरी तारीख: {revised}"
        record_event(conn, row["id"], actor, "order_confirmed", summary, summary_hi,
                     {"confirmed": {str(k): v for k, v in decisions.items()}, "notes": notes}, ts)
    order = get_order(conn, actor, row["id"])
    partial = order.partially_confirmed
    return ActionResult(
        ok=True,
        message=f"Order {row['id']} confirmed" + (" with partial quantities." if partial else "."),
        message_hi=f"ऑर्डर {row['id']} की पुष्टि हो गई" + (" (आंशिक मात्रा)।" if partial else "।"),
        order=order,
    )


def record_dispatch(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    order_id: str,
    challan_ref: str,
    lines: list[DispatchLineInput] | None = None,
    dispatched_at: str | None = None,
    expected_delivery_date: str | None = None,
    eway_bill_ref: str | None = None,
    vehicle_ref: str | None = None,
    driver_note: str | None = None,
    notes: str | None = None,
) -> ActionResult:
    actor.require("distributor", action="record a dispatch")
    row = _order_row(conn, actor, order_id)
    _require_status(row, ("confirmed",), "record dispatch for", "डिस्पैच दर्ज")
    challan = _clean_text(challan_ref, "challan_ref", 60)
    if not challan:
        raise ValidationFailed("A delivery challan or dispatch reference is required.",
                               message_hi="डिलीवरी चालान या डिस्पैच संदर्भ ज़रूरी है।", details={"field": "challan_ref"})
    dispatched_dt = _parse_ts(dispatched_at, "dispatched_at") or utc_now()
    expected = _parse_date(expected_delivery_date, "expected_delivery_date")
    stored = {ln["id"]: ln for ln in _line_rows(conn, row["id"])}
    given = {d.line_id: d.dispatched_qty for d in (lines or [])}
    unknown = set(given) - set(stored)
    if unknown:
        raise ValidationFailed(f"Line ids {sorted(unknown)} do not belong to order {row['id']}.",
                               message_hi="कुछ लाइनें इस ऑर्डर की नहीं हैं।", details={"unknown_line_ids": sorted(unknown)})
    decisions: dict[int, float] = {}
    for lid, ln in stored.items():
        qty = given.get(lid, ln["confirmed_qty"] or 0)
        validate_quantity(qty, ln["unit"], field=f"dispatched_qty (line {ln['line_no']})", allow_zero=True)
        if qty > (ln["confirmed_qty"] or 0):
            raise ValidationFailed(
                f"Line {ln['line_no']}: dispatched quantity {qty_with_unit(qty, ln['unit'])} is more than the "
                f"confirmed {qty_with_unit(ln['confirmed_qty'] or 0, ln['unit'])}.",
                message_hi=f"लाइन {ln['line_no']}: डिस्पैच मात्रा पुष्टि की गई मात्रा से अधिक है।",
                details={"line_id": lid},
            )
        decisions[lid] = qty
    if all(q == 0 for q in decisions.values()):
        raise ValidationFailed("Nothing to dispatch: every dispatched quantity is zero.",
                               message_hi="डिस्पैच के लिए कुछ नहीं: सभी मात्राएँ शून्य हैं।")
    value_inr = sum(decisions[lid] * stored[lid]["unit_price_paise"] for lid in decisions) / 100
    warnings: list[str] = []
    warnings_hi: list[str] = []
    if value_inr > EWAY_BILL_THRESHOLD_INR and not (eway_bill_ref or "").strip():
        warnings.append(
            f"Consignment value is about ₹{value_inr:,.0f}. Under CGST Rule 138, movement of goods above ₹50,000 "
            "generally needs an e-way bill (exemptions apply). No e-way bill number was recorded."
        )
        warnings_hi.append(
            f"माल का मूल्य लगभग ₹{value_inr:,.0f} है। CGST नियम 138 के तहत ₹50,000 से अधिक के माल के लिए आम तौर पर "
            "ई-वे बिल ज़रूरी होता है (कुछ छूट लागू)। कोई ई-वे बिल नंबर दर्ज नहीं किया गया।"
        )
    with transaction(conn):
        ts = now_iso()
        for lid, qty in decisions.items():
            conn.execute("UPDATE order_lines SET dispatched_qty = ? WHERE id = ?", (qty, lid))
            conn.execute(
                """UPDATE distributor_stock SET available_qty = MAX(available_qty - ?, 0)
                   WHERE distributor_id = ? AND product_id = ?""",
                (qty, row["distributor_id"], stored[lid]["product_id"]),
            )
        conn.execute(
            """INSERT INTO dispatches (order_id, challan_ref, eway_bill_ref, vehicle_ref, driver_note, notes,
                                       dispatched_at, expected_delivery_date, recorded_by, recorded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (row["id"], challan, _clean_text(eway_bill_ref, "eway_bill_ref", 40), _clean_text(vehicle_ref, "vehicle_ref", 40),
             _clean_text(driver_note, "driver_note", 300), _clean_text(notes, "notes"), iso(dispatched_dt), expected,
             actor.display_name, ts),
        )
        conn.execute("UPDATE orders SET status = 'in_transit', updated_at = ? WHERE id = ?", (ts, row["id"]))
        parts = [f"{qty_with_unit(q, stored[l]['unit'])} {stored[l]['product_name']}" for l, q in decisions.items()]
        parts_hi = [f"{stored[l]['product_name_hi']} {qty_with_unit(q, stored[l]['unit'], 'hi')}" for l, q in decisions.items()]
        short = [l for l, q in decisions.items() if q < (stored[l]["confirmed_qty"] or 0)]
        summary = f"Dispatch recorded under challan {challan}: " + ", ".join(parts)
        summary_hi = f"चालान {challan} के तहत डिस्पैच दर्ज: " + ", ".join(parts_hi)
        if short:
            summary += " (less than confirmed on some lines)"
            summary_hi += " (कुछ लाइनों पर पुष्टि से कम)"
        record_event(conn, row["id"], actor, "dispatch_recorded", summary, summary_hi,
                     {"dispatched": {str(k): v for k, v in decisions.items()}, "challan_ref": challan,
                      "expected_delivery_date": expected, "warnings": warnings}, iso(dispatched_dt))
    order = get_order(conn, actor, row["id"])
    return ActionResult(
        ok=True,
        message=f"Dispatch recorded for {row['id']} (challan {challan})." + (" " + " ".join(warnings) if warnings else ""),
        message_hi=f"{row['id']} का डिस्पैच दर्ज हुआ (चालान {challan})।" + (" " + " ".join(warnings_hi) if warnings_hi else ""),
        order=order,
    )


def _next_discrepancy_id(conn: sqlite3.Connection) -> str:
    rows = conn.execute("SELECT id FROM discrepancies").fetchall()
    numbers = [int(r["id"].split("-")[1]) for r in rows if r["id"].startswith("DSC-")]
    return f"DSC-{(max(numbers) + 1) if numbers else 2001}"


def _insert_discrepancy(
    conn: sqlite3.Connection, *, order_id: str, line: sqlite3.Row, kind: str, expected: float | None,
    observed: float | None, difference: float, detected_by: str, description: str, description_hi: str, at: str,
) -> str:
    did = _next_discrepancy_id(conn)
    conn.execute(
        """INSERT INTO discrepancies (id, order_id, line_id, kind, expected_qty, observed_qty, difference_qty, unit,
                                      status, detected_by, detected_at, description, description_hi)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?)""",
        (did, order_id, line["id"], kind, expected, observed, difference, line["unit"], detected_by, at,
         description, description_hi),
    )
    return did


def record_delivery(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    order_id: str,
    lines: list[ReceiptLineInput],
    received_at: str | None = None,
    condition_notes: str | None = None,
    evidence_file: str | None = None,
) -> ActionResult:
    actor.require("retailer", action="record a delivery receipt")
    row = _order_row(conn, actor, order_id)
    _require_status(row, ("in_transit",), "record receipt for", "प्राप्ति दर्ज")
    received_dt = _parse_ts(received_at, "received_at") or utc_now()
    stored = {ln["id"]: ln for ln in _line_rows(conn, row["id"])}
    given = {r.line_id: r for r in lines}
    unknown = set(given) - set(stored)
    if unknown:
        raise ValidationFailed(f"Line ids {sorted(unknown)} do not belong to order {row['id']}.",
                               message_hi="कुछ लाइनें इस ऑर्डर की नहीं हैं।", details={"unknown_line_ids": sorted(unknown)})
    missing = [ln["line_no"] for lid, ln in stored.items() if lid not in given]
    if missing:
        raise ValidationFailed(
            f"Record a received quantity for every line. Missing line(s): {missing}.",
            message_hi=f"हर लाइन की प्राप्त मात्रा दर्ज करें। छूटी लाइनें: {missing}।",
            details={"missing_line_numbers": missing},
        )
    for lid, rec in given.items():
        ln = stored[lid]
        validate_quantity(rec.received_qty, ln["unit"], field=f"received_qty (line {ln['line_no']})", allow_zero=True)
        validate_quantity(rec.damaged_qty, ln["unit"], field=f"damaged_qty (line {ln['line_no']})", allow_zero=True)
        if rec.damaged_qty > rec.received_qty:
            raise ValidationFailed(
                f"Line {ln['line_no']}: damaged quantity cannot exceed the received quantity.",
                message_hi=f"लाइन {ln['line_no']}: क्षतिग्रस्त मात्रा प्राप्त मात्रा से अधिक नहीं हो सकती।",
                details={"line_id": lid},
            )
    created: list[str] = []
    with transaction(conn):
        ts = iso(received_dt)
        for lid, rec in given.items():
            conn.execute("UPDATE order_lines SET received_qty = ?, damaged_qty = ? WHERE id = ?",
                         (rec.received_qty, rec.damaged_qty, lid))
        conn.execute(
            """INSERT INTO receipts (order_id, received_at, condition_notes, evidence_file, recorded_by, recorded_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (row["id"], ts, _clean_text(condition_notes, "condition_notes"), evidence_file, actor.display_name, now_iso()),
        )
        parts = [f"{qty_with_unit(r.received_qty, stored[l]['unit'])} {stored[l]['product_name']}" for l, r in given.items()]
        parts_hi = [f"{stored[l]['product_name_hi']} {qty_with_unit(r.received_qty, stored[l]['unit'], 'hi')}" for l, r in given.items()]
        record_event(conn, row["id"], actor, "receipt_recorded", "Retailer recorded receipt of " + ", ".join(parts),
                     "रिटेलर ने प्राप्ति दर्ज की: " + ", ".join(parts_hi),
                     {"received": {str(l): {"received": r.received_qty, "damaged": r.damaged_qty} for l, r in given.items()},
                      "condition_notes": condition_notes}, ts)
        for lid, rec in given.items():
            ln = stored[lid]
            cmp = compare_line(confirmed=ln["confirmed_qty"], dispatched=ln["dispatched_qty"],
                               received=rec.received_qty, damaged=rec.damaged_qty, unit=ln["unit"])
            if cmp.outcome in ("short", "excess"):
                diff = abs(cmp.receipt_variance or 0)
                did = _insert_discrepancy(
                    conn, order_id=row["id"], line=ln, kind=cmp.outcome, expected=ln["dispatched_qty"],
                    observed=rec.received_qty, difference=diff, detected_by="system",
                    description=f"{ln['product_name']}: {cmp.summary}",
                    description_hi=f"{ln['product_name_hi']}: {cmp.summary_hi}", at=ts,
                )
                created.append(did)
                label, label_hi = KIND_LABELS[cmp.outcome]
                record_event(
                    conn, row["id"], None, "discrepancy_flagged",
                    f"System flagged a {label} of {qty_with_unit(diff, ln['unit'])} on {ln['product_name']} ({did}): "
                    f"{fmt_qty(ln['dispatched_qty'])} dispatched, {fmt_qty(rec.received_qty)} received",
                    f"सिस्टम ने {ln['product_name_hi']} पर {qty_with_unit(diff, ln['unit'], 'hi')} की {label_hi} दर्ज की ({did}): "
                    f"{fmt_qty(ln['dispatched_qty'])} भेजी गई, {fmt_qty(rec.received_qty)} मिली",
                    {"discrepancy_id": did, "line_id": lid, "kind": cmp.outcome, "difference": diff}, ts,
                )
            if rec.damaged_qty > 0:
                did = _insert_discrepancy(
                    conn, order_id=row["id"], line=ln, kind="damaged", expected=None, observed=rec.damaged_qty,
                    difference=rec.damaged_qty, detected_by="retailer",
                    description=f"{ln['product_name']}: {qty_with_unit(rec.damaged_qty, ln['unit'])} reported damaged at receipt.",
                    description_hi=f"{ln['product_name_hi']}: प्राप्ति के समय {qty_with_unit(rec.damaged_qty, ln['unit'], 'hi')} क्षतिग्रस्त बताई गई।",
                    at=ts,
                )
                created.append(did)
                record_event(
                    conn, row["id"], actor, "damage_reported",
                    f"{qty_with_unit(rec.damaged_qty, ln['unit'])} of {ln['product_name']} reported damaged ({did})",
                    f"{ln['product_name_hi']} की {qty_with_unit(rec.damaged_qty, ln['unit'], 'hi')} क्षतिग्रस्त बताई गई ({did})",
                    {"discrepancy_id": did, "line_id": lid, "damaged": rec.damaged_qty}, ts,
                )
        _touch(conn, row["id"], "needs_review" if created else "delivered")
        if not created:
            record_event(conn, row["id"], None, "quantities_matched",
                         "All received quantities match the recorded dispatch. Order marked delivered.",
                         "सभी प्राप्त मात्राएँ डिस्पैच से मेल खाती हैं। ऑर्डर डिलीवर माना गया।", {}, ts)
    order = get_order(conn, actor, row["id"])
    if created:
        msg = f"Receipt recorded for {row['id']}. {len(created)} difference(s) flagged for review: " + "; ".join(
            d.description for d in order.discrepancies if d.id in created)
        msg_hi = f"{row['id']} की प्राप्ति दर्ज हुई। {len(created)} अंतर जाँच के लिए दर्ज: " + "; ".join(
            d.description_hi for d in order.discrepancies if d.id in created)
    else:
        msg = f"Receipt recorded for {row['id']}. All quantities match the dispatch record."
        msg_hi = f"{row['id']} की प्राप्ति दर्ज हुई। सभी मात्राएँ डिस्पैच रिकॉर्ड से मेल खाती हैं।"
    return ActionResult(ok=True, message=msg, message_hi=msg_hi, order=order, discrepancies_created=created)


def report_discrepancy(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    order_id: str,
    line_id: int,
    kind: str,
    quantity: float,
    description: str,
) -> ActionResult:
    actor.require("retailer", "distributor", action="report a discrepancy")
    row = _order_row(conn, actor, order_id)
    _require_status(row, ("delivered", "needs_review", "resolved"), "report a discrepancy on", "अंतर दर्ज")
    if kind not in ("short", "excess", "damaged", "other"):
        raise ValidationFailed("kind must be one of short, excess, damaged or other.",
                               message_hi="kind short, excess, damaged या other होना चाहिए।", details={"kind": kind})
    stored = {ln["id"]: ln for ln in _line_rows(conn, row["id"])}
    if line_id not in stored:
        raise ValidationFailed(f"Line {line_id} does not belong to order {row['id']}.",
                               message_hi="यह लाइन इस ऑर्डर की नहीं है।", details={"line_id": line_id})
    ln = stored[line_id]
    validate_quantity(quantity, ln["unit"], field="quantity")
    text = _clean_text(description, "description", 600)
    if not text:
        raise ValidationFailed("Describe what was observed.", message_hi="जो देखा गया उसका विवरण दें।")
    with transaction(conn):
        ts = now_iso()
        label, label_hi = KIND_LABELS[kind]
        did = _insert_discrepancy(
            conn, order_id=row["id"], line=ln, kind=kind, expected=ln["dispatched_qty"], observed=ln["received_qty"],
            difference=quantity, detected_by=actor.role,
            description=f"{ln['product_name']}: {qty_with_unit(quantity, ln['unit'])} {label} reported by the {actor.role}. {text}",
            description_hi=f"{ln['product_name_hi']}: {actor.role} द्वारा {qty_with_unit(quantity, ln['unit'], 'hi')} की {label_hi} दर्ज। {text}",
            at=ts,
        )
        _touch(conn, row["id"], "needs_review")
        record_event(conn, row["id"], actor, "discrepancy_reported",
                     f"{actor.role.title()} reported {qty_with_unit(quantity, ln['unit'])} {label} on {ln['product_name']} ({did})",
                     f"{actor.role} ने {ln['product_name_hi']} पर {qty_with_unit(quantity, ln['unit'], 'hi')} की {label_hi} दर्ज की ({did})",
                     {"discrepancy_id": did, "line_id": line_id, "kind": kind, "quantity": quantity, "description": text}, ts)
    order = get_order(conn, actor, row["id"])
    return ActionResult(ok=True, message=f"Discrepancy {did} recorded on {row['id']}.",
                        message_hi=f"{row['id']} पर अंतर {did} दर्ज हुआ।", order=order, discrepancies_created=[did])


def _discrepancy_row(conn: sqlite3.Connection, actor: Actor, discrepancy_id: str) -> tuple[sqlite3.Row, sqlite3.Row]:
    did = (discrepancy_id or "").strip().upper()
    if re.fullmatch(r"\d+", did):
        did = f"DSC-{did}"
    d = conn.execute("SELECT * FROM discrepancies WHERE id = ?", (did,)).fetchone()
    if d is None:
        raise NotFoundError(f"Discrepancy {did} was not found.", message_hi=f"अंतर {did} नहीं मिला।",
                            details={"discrepancy_id": did})
    order = _order_row(conn, actor, d["order_id"])
    return d, order


def add_discrepancy_note(
    conn: sqlite3.Connection, actor: Actor, *, discrepancy_id: str, note: str, acknowledge: bool = False
) -> ActionResult:
    actor.require("retailer", "distributor", action="add a discrepancy note")
    d, order_row = _discrepancy_row(conn, actor, discrepancy_id)
    if d["status"] == "resolved":
        raise InvalidTransition(f"Discrepancy {d['id']} is already resolved; its record is closed.",
                                message_hi=f"अंतर {d['id']} का समाधान हो चुका है।", details={"discrepancy_id": d["id"]})
    text = _clean_text(note, "note", 600)
    if not text:
        raise ValidationFailed("The note cannot be empty.", message_hi="नोट खाली नहीं हो सकता।")
    with transaction(conn):
        ts = now_iso()
        kind = "acknowledgement" if acknowledge else "note"
        conn.execute(
            """INSERT INTO discrepancy_notes (discrepancy_id, author_role, author_name, kind, note, source, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (d["id"], actor.role, actor.display_name, kind, text, actor.source, ts),
        )
        if acknowledge and d["status"] == "open":
            conn.execute("UPDATE discrepancies SET status = 'acknowledged' WHERE id = ?", (d["id"],))
        _touch(conn, order_row["id"])
        if acknowledge:
            summary = f"{actor.role.title()} acknowledged discrepancy {d['id']}: “{text}”"
            summary_hi = f"{actor.role} ने अंतर {d['id']} स्वीकार किया: “{text}”"
        else:
            summary = f"{actor.role.title()} added a note on {d['id']}: “{text}”"
            summary_hi = f"{actor.role} ने {d['id']} पर नोट जोड़ा: “{text}”"
        record_event(conn, order_row["id"], actor, "discrepancy_acknowledged" if acknowledge else "discrepancy_note",
                     summary, summary_hi, {"discrepancy_id": d["id"], "note": text}, ts)
    order = get_order(conn, actor, order_row["id"])
    return ActionResult(ok=True, message=f"Note saved on {d['id']}.", message_hi=f"{d['id']} पर नोट सहेजा गया।",
                        order=order)


def resolve_discrepancy(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    discrepancy_id: str,
    resolution_type: str,
    notes: str,
    follow_up_qty: float | None = None,
) -> ActionResult:
    actor.require("retailer", "distributor", action="record a resolution")
    d, order_row = _discrepancy_row(conn, actor, discrepancy_id)
    if d["status"] == "resolved":
        raise InvalidTransition(f"Discrepancy {d['id']} is already resolved.",
                                message_hi=f"अंतर {d['id']} का पहले ही समाधान हो चुका है।", details={"discrepancy_id": d["id"]})
    if resolution_type not in RESOLUTION_LABELS:
        raise ValidationFailed(f"resolution_type must be one of {list(RESOLUTION_LABELS)}.",
                               message_hi="समाधान का प्रकार सही नहीं है।", details={"resolution_type": resolution_type})
    text = _clean_text(notes, "notes", 800)
    if not text:
        raise ValidationFailed("Explain the decision in the notes.", message_hi="नोट में निर्णय का कारण लिखें।")
    if follow_up_qty is not None:
        validate_quantity(follow_up_qty, d["unit"], field="follow_up_qty")
    if resolution_type == "supply_remaining" and follow_up_qty is None:
        follow_up_qty = d["difference_qty"]
    label, label_hi = RESOLUTION_LABELS[resolution_type]
    with transaction(conn):
        ts = now_iso()
        conn.execute(
            """INSERT INTO resolutions (discrepancy_id, resolution_type, follow_up_qty, notes, decided_by_role,
                                        decided_by_name, source, decided_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (d["id"], resolution_type, follow_up_qty, text, actor.role, actor.display_name, actor.source, ts),
        )
        new_status = "under_review" if resolution_type == "under_review" else "resolved"
        conn.execute("UPDATE discrepancies SET status = ? WHERE id = ?", (new_status, d["id"]))
        remaining = conn.execute(
            "SELECT COUNT(*) FROM discrepancies WHERE order_id = ? AND status != 'resolved'", (order_row["id"],)
        ).fetchone()[0]
        qty_txt = f" ({qty_with_unit(follow_up_qty, d['unit'])})" if follow_up_qty else ""
        qty_txt_hi = f" ({qty_with_unit(follow_up_qty, d['unit'], 'hi')})" if follow_up_qty else ""
        record_event(conn, order_row["id"], actor,
                     "resolution_recorded" if new_status == "resolved" else "review_started",
                     f"{actor.role.title()} recorded resolution for {d['id']}: {label}{qty_txt}. “{text}”",
                     f"{actor.role} ने {d['id']} का समाधान दर्ज किया: {label_hi}{qty_txt_hi}। “{text}”",
                     {"discrepancy_id": d["id"], "resolution_type": resolution_type, "follow_up_qty": follow_up_qty}, ts)
        if remaining == 0:
            _touch(conn, order_row["id"], "resolved")
            record_event(conn, order_row["id"], None, "order_resolved",
                         "All differences on this order now have a recorded resolution. Original quantities are preserved.",
                         "इस ऑर्डर के सभी अंतरों का समाधान दर्ज है। मूल मात्राएँ सुरक्षित हैं।", {}, ts)
        else:
            _touch(conn, order_row["id"], "needs_review")
    order = get_order(conn, actor, order_row["id"])
    return ActionResult(
        ok=True,
        message=f"Resolution recorded for {d['id']}: {label}." + (" The order is now resolved." if order.status == "resolved" else ""),
        message_hi=f"{d['id']} का समाधान दर्ज: {label_hi}।" + (" ऑर्डर का अब समाधान हो गया।" if order.status == "resolved" else ""),
        order=order,
    )


# ---------------------------------------------------------------- reads


def get_order(conn: sqlite3.Connection, actor: Actor, order_id: str) -> OrderOut:
    return build_order(conn, _order_row(conn, actor, order_id))


def _scope_clause(actor: Actor) -> tuple[str, list[Any]]:
    if actor.role == "retailer":
        return "o.retailer_id = ?", [actor.party_id]
    return "o.distributor_id = ? AND o.status != 'draft'", [actor.party_id]


def list_orders(
    conn: sqlite3.Connection,
    actor: Actor,
    *,
    status: str | None = None,
    has_discrepancy: bool | None = None,
    search: str | None = None,
    category: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = 50,
) -> OrderListResult:
    where, params = _scope_clause(actor)
    clauses = [where]
    statuses = [s.strip() for s in (status or "").split(",") if s.strip()]
    if statuses:
        valid = set(STATUS_LABELS)
        bad = [s for s in statuses if s not in valid]
        if bad:
            raise ValidationFailed(f"Unknown status {bad}. Valid: {sorted(valid)}.", message_hi="अज्ञात स्थिति।",
                                   details={"status": bad})
        clauses.append(f"o.status IN ({','.join('?' * len(statuses))})")
        params += statuses
    if has_discrepancy is True:
        clauses.append("EXISTS (SELECT 1 FROM discrepancies d WHERE d.order_id = o.id AND d.status != 'resolved')")
    elif has_discrepancy is False:
        clauses.append("NOT EXISTS (SELECT 1 FROM discrepancies d WHERE d.order_id = o.id AND d.status != 'resolved')")
    if category:
        clauses.append("EXISTS (SELECT 1 FROM order_lines l JOIN products p ON p.id = l.product_id "
                       "WHERE l.order_id = o.id AND lower(p.category) = lower(?))")
        params.append(category)
    if search:
        s = search.strip()
        clauses.append("(o.id LIKE ? OR EXISTS (SELECT 1 FROM order_lines l JOIN products p ON p.id = l.product_id "
                       "WHERE l.order_id = o.id AND (p.name LIKE ? OR p.name_hi LIKE ? OR p.id LIKE ? OR p.keywords LIKE ?)))")
        like = f"%{s}%"
        digits = re.sub(r"\D", "", s)
        params += [f"%{digits}%" if digits else like, like, like, like, like]
    if date_from:
        clauses.append("o.created_at >= ?")
        params.append(_parse_date(date_from, "date_from"))
    if date_to:
        clauses.append("o.created_at < date(?, '+1 day')")
        params.append(_parse_date(date_to, "date_to"))
    rows = conn.execute(
        f"SELECT o.* FROM orders o WHERE {' AND '.join(clauses)} ORDER BY o.created_at DESC LIMIT ?",
        (*params, max(1, min(limit, 200))),
    ).fetchall()
    return OrderListResult(
        count=len(rows),
        orders=[summarise_order(conn, r) for r in rows],
        filters_applied={k: v for k, v in {"status": status, "has_discrepancy": has_discrepancy, "search": search,
                                           "category": category, "date_from": date_from, "date_to": date_to}.items()
                         if v not in (None, "")},
    )


def get_timeline(conn: sqlite3.Connection, actor: Actor, order_id: str) -> TimelineResult:
    row = _order_row(conn, actor, order_id)
    events = conn.execute("SELECT * FROM audit_events WHERE order_id = ? ORDER BY at, id", (row["id"],)).fetchall()
    return TimelineResult(order_id=row["id"], status=row["status"], events=[_event_out(e) for e in events])


def _event_out(e: sqlite3.Row) -> TimelineEventOut:
    return TimelineEventOut(
        id=e["id"], at=e["at"], actor_role=e["actor_role"], actor_name=e["actor_name"], event_type=e["event_type"],
        summary=e["summary"], summary_hi=e["summary_hi"], source=e["source"], data=json.loads(e["data"] or "{}"),
    )


def recent_events(conn: sqlite3.Connection, actor: Actor, limit: int = 8) -> list[TimelineEventOut]:
    where, params = _scope_clause(actor)
    rows = conn.execute(
        f"""SELECT e.* FROM audit_events e JOIN orders o ON o.id = e.order_id
            WHERE {where} ORDER BY e.at DESC, e.id DESC LIMIT ?""",
        (*params, limit),
    ).fetchall()
    return [_event_out(e) for e in rows]


def list_discrepancies(
    conn: sqlite3.Connection, actor: Actor, *, status: str | None = None, order_id: str | None = None
) -> DiscrepancyListResult:
    scope = "o.retailer_id = ?" if actor.role == "retailer" else "o.distributor_id = ?"
    where = [f"d.order_id IN (SELECT o.id FROM orders o WHERE {scope})"]
    params: list[Any] = [actor.party_id]
    if status == "unresolved":
        where.append("d.status != 'resolved'")
    elif status:
        if status not in ("open", "acknowledged", "under_review", "resolved"):
            raise ValidationFailed("status must be open, acknowledged, under_review, resolved or unresolved.",
                                   message_hi="स्थिति सही नहीं है।", details={"status": status})
        where.append("d.status = ?")
        params.append(status)
    if order_id:
        where.append("d.order_id = ?")
        params.append(normalise_order_id(order_id))
    items = _discrepancies(conn, " AND ".join(where), tuple(params))
    items.sort(key=lambda x: x.detected_at, reverse=True)
    items.sort(key=lambda x: x.status == "resolved")  # stable: unresolved first, newest first within each group
    return DiscrepancyListResult(count=len(items), discrepancies=items)
