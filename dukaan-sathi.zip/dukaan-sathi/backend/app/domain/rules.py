"""Deterministic business rules: units, quantities, conversions and quantity comparison.

Nothing in here uses a language model. These functions decide whether a quantity is valid
and how large a delivery difference is.
"""

from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Literal

from app.domain.errors import ValidationFailed

# Canonical unit codes with English / Hindi labels.
UNITS: dict[str, dict[str, str]] = {
    "bag": {"en": "bag", "en_pl": "bags", "hi": "बोरी"},
    "piece": {"en": "piece", "en_pl": "pieces", "hi": "पीस"},
    "length": {"en": "length", "en_pl": "lengths", "hi": "लंबाई"},
    "kg": {"en": "kg", "en_pl": "kg", "hi": "किलो"},
    "pack": {"en": "pack", "en_pl": "packs", "hi": "पैकेट"},
    "metre": {"en": "metre", "en_pl": "metres", "hi": "मीटर"},
}

# Words people actually say, mapped to canonical unit codes. Units not listed here
# (tonnes, grams, feet, trucks...) are rejected rather than guessed.
UNIT_ALIASES: dict[str, str] = {
    "bag": "bag", "bags": "bag", "bori": "bag", "boriya": "bag", "boriyan": "bag", "katta": "bag",
    "kattas": "bag", "बोरी": "bag", "बोरियां": "bag", "बोरियाँ": "bag", "बोरे": "bag", "बैग": "bag",
    "कट्टा": "bag", "कट्टे": "bag",
    "piece": "piece", "pieces": "piece", "pc": "piece", "pcs": "piece", "nos": "piece", "no": "piece",
    "peace": "piece", "पीस": "piece", "नग": "piece",
    "length": "length", "lengths": "length", "लंबाई": "length", "लम्बाई": "length", "लेंथ": "length",
    "kg": "kg", "kgs": "kg", "kilo": "kg", "kilos": "kg", "kilogram": "kg", "kilograms": "kg",
    "किलो": "kg", "केजी": "kg",
    "pack": "pack", "packs": "pack", "packet": "pack", "packets": "pack", "पैकेट": "pack", "पैक": "pack",
    "metre": "metre", "metres": "metre", "meter": "metre", "meters": "metre", "mtr": "metre",
    "मीटर": "metre",
}

INTEGER_UNITS = {"bag", "piece", "length", "pack", "metre"}
MAX_QTY = 100_000


def normalise_unit(raw: str | None) -> str | None:
    if raw is None:
        return None
    key = raw.strip().lower().rstrip(".")
    return UNIT_ALIASES.get(key)


def unit_label(unit: str, qty: float | None = None, lang: str = "en") -> str:
    info = UNITS.get(unit)
    if info is None:
        return unit
    if lang == "hi":
        return info["hi"]
    if qty is not None and abs(qty - 1) < 1e-9:
        return info["en"]
    return info["en_pl"]


def fmt_qty(qty: float | None) -> str:
    if qty is None:
        return "—"
    if abs(qty - round(qty)) < 1e-9:
        return str(int(round(qty)))
    return f"{qty:.1f}".rstrip("0").rstrip(".")


def qty_with_unit(qty: float | None, unit: str, lang: str = "en") -> str:
    return f"{fmt_qty(qty)} {unit_label(unit, qty, lang)}"


def validate_quantity(qty: float, unit: str, *, field: str = "quantity", allow_zero: bool = False) -> float:
    """Reject malformed quantities: NaN, negatives, fractions of discrete units, absurd sizes."""
    if qty is None or isinstance(qty, bool) or not isinstance(qty, (int, float)) or not math.isfinite(qty):
        raise ValidationFailed(
            f"{field} must be a number.",
            message_hi=f"{field} एक संख्या होनी चाहिए।",
            details={"field": field, "value": qty},
        )
    if qty < 0 or (qty == 0 and not allow_zero):
        raise ValidationFailed(
            f"{field} must be greater than zero." if not allow_zero else f"{field} cannot be negative.",
            message_hi="मात्रा शून्य से अधिक होनी चाहिए।" if not allow_zero else "मात्रा ऋणात्मक नहीं हो सकती।",
            details={"field": field, "value": qty},
        )
    if qty > MAX_QTY:
        raise ValidationFailed(
            f"{field} of {fmt_qty(qty)} is above the {MAX_QTY:,} limit for a single order line.",
            message_hi=f"एक लाइन में अधिकतम {MAX_QTY} की सीमा है।",
            details={"field": field, "value": qty},
        )
    if unit in INTEGER_UNITS and abs(qty - round(qty)) > 1e-9:
        raise ValidationFailed(
            f"{field} must be a whole number of {unit_label(unit)}.",
            message_hi=f"{unit_label(unit, lang='hi')} की संख्या पूरी होनी चाहिए।",
            details={"field": field, "value": qty, "unit": unit},
        )
    if unit == "kg" and abs(qty * 2 - round(qty * 2)) > 1e-9:
        raise ValidationFailed(
            f"{field} in kg must be in steps of 0.5 kg.",
            message_hi="किलो में मात्रा 0.5 के गुणक में होनी चाहिए।",
            details={"field": field, "value": qty},
        )
    return float(qty)


@dataclass(frozen=True)
class UnitConversion:
    requested_qty: float
    requested_unit: str
    canonical_qty: float
    canonical_unit: str
    converted: bool
    explanation: str


def convert_to_canonical(
    qty: float,
    requested_unit: str,
    *,
    product_unit: str,
    alt_unit: str | None,
    alt_per_unit: int | None,
    product_name: str,
) -> UnitConversion:
    """Convert only through an explicitly defined factor; otherwise reject the unit."""
    unit = normalise_unit(requested_unit) or requested_unit
    if unit == product_unit:
        validate_quantity(qty, unit)
        return UnitConversion(qty, unit, float(qty), product_unit, False, "")
    if alt_unit and alt_per_unit and unit == alt_unit:
        validate_quantity(qty, unit)
        canonical = qty / alt_per_unit
        if abs(canonical - round(canonical)) > 1e-9:
            raise ValidationFailed(
                f"{qty_with_unit(qty, unit)} is not a whole number of {unit_label(product_unit)} "
                f"for {product_name} ({alt_per_unit} {unit_label(alt_unit)} per {unit_label(product_unit, 1)}).",
                message_hi=f"{product_name}: {alt_per_unit} {unit_label(alt_unit, lang='hi')} = 1 "
                f"{unit_label(product_unit, lang='hi')}; यह मात्रा पूरे {unit_label(product_unit, lang='hi')} में नहीं बदलती।",
                details={"unit": unit, "product_unit": product_unit, "factor": alt_per_unit},
            )
        canonical = float(round(canonical))
        return UnitConversion(
            qty,
            unit,
            canonical,
            product_unit,
            True,
            f"{qty_with_unit(qty, unit)} = {qty_with_unit(canonical, product_unit)} "
            f"({alt_per_unit} {unit_label(alt_unit)} per {unit_label(product_unit, 1)})",
        )
    allowed = [product_unit] + ([alt_unit] if alt_unit else [])
    raise ValidationFailed(
        f"{product_name} is sold in {' or '.join(unit_label(u) for u in allowed)}, "
        f"not {unit_label(unit) if unit in UNITS else repr(requested_unit)}. "
        "Quantities in different units are never treated as interchangeable.",
        message_hi=f"{product_name} {' या '.join(unit_label(u, lang='hi') for u in allowed)} में बिकता है, "
        f"'{requested_unit}' में नहीं। अलग-अलग इकाइयों को बराबर नहीं माना जाता।",
        details={"requested_unit": requested_unit, "allowed_units": allowed},
    )


Outcome = Literal["match", "short", "excess", "awaiting_dispatch", "awaiting_receipt"]


@dataclass(frozen=True)
class LineComparison:
    confirmed_qty: float | None
    dispatched_qty: float | None
    received_qty: float | None
    damaged_qty: float
    dispatch_variance: float | None  # dispatched - confirmed
    receipt_variance: float | None  # received - dispatched
    outcome: Outcome
    comparable: bool
    summary: str
    summary_hi: str

    def as_dict(self) -> dict:
        return asdict(self)


def compare_line(
    *,
    confirmed: float | None,
    dispatched: float | None,
    received: float | None,
    damaged: float | None,
    unit: str,
) -> LineComparison:
    """Compare confirmed → dispatched → received for one line, in a single canonical unit.

    The wording deliberately describes *where the numbers differ*, never *who is at fault*.
    """
    damaged_qty = float(damaged or 0)
    dispatch_var = None if confirmed is None or dispatched is None else dispatched - confirmed
    if dispatched is None:
        return LineComparison(
            confirmed, dispatched, received, damaged_qty, dispatch_var, None, "awaiting_dispatch", False,
            "No dispatch quantity recorded yet, so a final comparison is not possible.",
            "अभी तक डिस्पैच मात्रा दर्ज नहीं है, इसलिए अंतिम तुलना संभव नहीं।",
        )
    if received is None:
        return LineComparison(
            confirmed, dispatched, received, damaged_qty, dispatch_var, None, "awaiting_receipt", False,
            "No receipt quantity recorded yet, so a final comparison is not possible.",
            "अभी तक प्राप्त मात्रा दर्ज नहीं है, इसलिए अंतिम तुलना संभव नहीं।",
        )
    variance = received - dispatched
    if abs(variance) < 1e-9:
        outcome: Outcome = "match"
        summary = f"Received quantity matches the recorded dispatch ({qty_with_unit(received, unit)})."
        summary_hi = f"प्राप्त मात्रा डिस्पैच से मेल खाती है ({qty_with_unit(received, unit, 'hi')})।"
    elif variance < 0:
        outcome = "short"
        summary = (
            f"Received quantity is {qty_with_unit(-variance, unit)} below the recorded dispatched quantity "
            f"({qty_with_unit(received, unit)} received vs {qty_with_unit(dispatched, unit)} dispatched). "
            "Cause not yet determined."
        )
        summary_hi = (
            f"प्राप्त मात्रा दर्ज डिस्पैच से {qty_with_unit(-variance, unit, 'hi')} कम है "
            f"({qty_with_unit(dispatched, unit, 'hi')} भेजी गई, {qty_with_unit(received, unit, 'hi')} मिली)। "
            "कारण अभी तय नहीं हुआ है।"
        )
    else:
        outcome = "excess"
        summary = (
            f"Received quantity is {qty_with_unit(variance, unit)} above the recorded dispatched quantity "
            f"({qty_with_unit(received, unit)} received vs {qty_with_unit(dispatched, unit)} dispatched)."
        )
        summary_hi = (
            f"प्राप्त मात्रा दर्ज डिस्पैच से {qty_with_unit(variance, unit, 'hi')} अधिक है "
            f"({qty_with_unit(dispatched, unit, 'hi')} भेजी गई, {qty_with_unit(received, unit, 'hi')} मिली)।"
        )
    return LineComparison(
        confirmed, dispatched, received, damaged_qty, dispatch_var, variance, outcome, True, summary, summary_hi
    )
