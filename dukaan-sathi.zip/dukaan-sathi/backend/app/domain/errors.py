"""Domain errors with stable codes, shared by the MCP server and the gateway."""

from __future__ import annotations

import json
from typing import Any


class DomainError(Exception):
    code = "domain_error"

    def __init__(self, message: str, *, message_hi: str | None = None, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.message_hi = message_hi or message
        self.details = details or {}

    def to_payload(self) -> dict[str, Any]:
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "message_hi": self.message_hi,
                "details": self.details,
            }
        }

    def to_json(self) -> str:
        return json.dumps(self.to_payload(), ensure_ascii=False)


class NotFoundError(DomainError):
    code = "not_found"


class ValidationFailed(DomainError):
    code = "validation_failed"


class PermissionDenied(DomainError):
    code = "permission_denied"


class InvalidTransition(DomainError):
    code = "invalid_state_transition"


class AmbiguousRequest(DomainError):
    code = "ambiguous"
