"""Typed tool inputs and outputs. MCP tool schemas are generated from these models."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

OrderStatus = Literal[
    "draft", "pending_confirmation", "confirmed", "in_transit", "delivered", "needs_review", "resolved"
]
DiscrepancyStatus = Literal["open", "acknowledged", "under_review", "resolved"]
ResolutionType = Literal["supply_remaining", "credit_note", "under_review", "no_adjustment", "other"]


# ---------- inputs ----------


class LineInput(BaseModel):
    sku: str = Field(description="Catalogue SKU, e.g. CEM-OPC53-50. Use search_products to find it.")
    quantity: float = Field(description="Quantity in the given unit, e.g. 50")
    unit: str = Field(description="Unit such as bag, piece, length, kg, pack or metre")


class ConfirmLineInput(BaseModel):
    line_id: int = Field(description="Order line id from get_order_status")
    confirmed_qty: float = Field(description="Quantity the distributor commits to supply (0 if unavailable)")


class DispatchLineInput(BaseModel):
    line_id: int
    dispatched_qty: float = Field(description="Quantity loaded for delivery, in the line's unit")


class ReceiptLineInput(BaseModel):
    line_id: int
    received_qty: float = Field(description="Quantity physically counted at the shop, in the line's unit")
    damaged_qty: float = Field(default=0, description="Of the received quantity, how much arrived damaged")


# ---------- outputs ----------


class ProductOut(BaseModel):
    sku: str
    name: str
    name_hi: str
    category: str
    grade: str | None
    size: str | None
    spec: str
    spec_hi: str
    unit: str
    unit_label: str
    unit_label_hi: str
    alt_unit: str | None
    alt_per_unit: int | None
    standard: str | None
    hsn: str | None
    gst_rate: float | None
    price_inr: float
    price_is_illustrative: bool = True
    available_qty: float
    availability: Literal["in_stock", "low_stock", "out_of_stock"]


class ProductSearchResult(BaseModel):
    query: str
    count: int
    products: list[ProductOut]
    needs_clarification: bool
    clarification: str | None = None
    clarification_hi: str | None = None


class LineValidation(BaseModel):
    line_no: int
    sku: str
    product_name: str | None
    product_name_hi: str | None
    spec: str | None
    requested_qty: float
    requested_unit: str
    canonical_qty: float | None
    unit: str | None
    conversion_note: str | None
    valid: bool
    availability: Literal["available", "partial", "out_of_stock", "unknown"]
    available_qty: float | None
    unit_price_inr: float | None
    line_value_inr: float | None
    messages: list[str]
    messages_hi: list[str]


class ValidationResult(BaseModel):
    valid: bool
    fully_available: bool
    order_id: str | None
    distributor_id: str
    lines: list[LineValidation]
    total_value_inr: float
    summary: str
    summary_hi: str


class LineComparisonOut(BaseModel):
    outcome: str
    comparable: bool
    dispatch_variance: float | None
    receipt_variance: float | None
    summary: str
    summary_hi: str


class OrderLineOut(BaseModel):
    line_id: int
    line_no: int
    sku: str
    product_name: str
    product_name_hi: str
    category: str
    spec: str
    spec_hi: str
    grade: str | None
    size: str | None
    unit: str
    unit_label: str
    unit_label_hi: str
    requested_qty: float
    confirmed_qty: float | None
    dispatched_qty: float | None
    received_qty: float | None
    damaged_qty: float | None
    unit_price_inr: float
    line_value_inr: float
    comparison: LineComparisonOut


class DispatchOut(BaseModel):
    challan_ref: str
    eway_bill_ref: str | None
    vehicle_ref: str | None
    driver_note: str | None
    notes: str | None
    dispatched_at: str
    expected_delivery_date: str | None
    recorded_by: str


class ReceiptOut(BaseModel):
    received_at: str
    condition_notes: str | None
    evidence_file: str | None
    recorded_by: str


class DiscrepancyNoteOut(BaseModel):
    author_role: str
    author_name: str
    kind: str
    note: str
    source: str
    created_at: str


class ResolutionOut(BaseModel):
    resolution_type: str
    follow_up_qty: float | None
    notes: str
    decided_by_role: str
    decided_by_name: str
    source: str
    decided_at: str


class DiscrepancyOut(BaseModel):
    id: str
    order_id: str
    line_id: int
    sku: str
    product_name: str
    product_name_hi: str
    kind: Literal["short", "excess", "damaged", "other"]
    expected_qty: float | None
    observed_qty: float | None
    difference_qty: float
    unit: str
    unit_label: str
    unit_label_hi: str
    status: DiscrepancyStatus
    detected_by: str
    detected_at: str
    description: str
    description_hi: str
    attributed_to: str | None = Field(
        default=None, description="Always null: the system records differences, it does not assign blame."
    )
    notes: list[DiscrepancyNoteOut]
    resolutions: list[ResolutionOut]


class PartyOut(BaseModel):
    id: str
    name: str
    name_hi: str
    city: str
    contact_name: str


class OrderOut(BaseModel):
    id: str
    status: OrderStatus
    is_sample: bool
    retailer: PartyOut
    distributor: PartyOut
    created_at: str
    submitted_at: str | None
    confirmed_at: str | None
    requested_delivery_date: str | None
    revised_delivery_date: str | None
    notes: str | None
    distributor_notes: str | None
    lines: list[OrderLineOut]
    dispatch: DispatchOut | None
    receipt: ReceiptOut | None
    discrepancies: list[DiscrepancyOut]
    open_discrepancy_count: int
    partially_confirmed: bool
    total_value_inr: float
    headline: str
    headline_hi: str
    next_action: str | None
    next_action_hi: str | None
    allowed_actions: dict[str, list[str]]


class OrderSummaryOut(BaseModel):
    id: str
    status: OrderStatus
    is_sample: bool
    retailer_name: str
    distributor_name: str
    created_at: str
    expected_delivery_date: str | None
    headline: str
    headline_hi: str
    line_count: int
    total_value_inr: float
    open_discrepancy_count: int
    categories: list[str]


class OrderListResult(BaseModel):
    count: int
    orders: list[OrderSummaryOut]
    filters_applied: dict[str, Any]


class TimelineEventOut(BaseModel):
    id: int
    at: str
    actor_role: str
    actor_name: str
    event_type: str
    summary: str
    summary_hi: str
    source: str
    data: dict[str, Any]


class TimelineResult(BaseModel):
    order_id: str
    status: OrderStatus
    events: list[TimelineEventOut]


class DiscrepancyListResult(BaseModel):
    count: int
    discrepancies: list[DiscrepancyOut]


class StatusCount(BaseModel):
    status: str
    count: int


class DashboardSummary(BaseModel):
    role: str
    party_name: str
    party_name_hi: str
    is_sample_data: bool
    total_orders: int
    in_transit: int
    needs_review: int
    delivered: int
    resolved: int
    pending_confirmation: int
    confirmed_awaiting_dispatch: int
    drafts: int
    open_discrepancies: int
    status_breakdown: list[StatusCount]
    attention: list[OrderSummaryOut]
    pending_confirmations: list[OrderSummaryOut]
    shipments: list[OrderSummaryOut]
    recent_orders: list[OrderSummaryOut]
    recent_activity: list[TimelineEventOut]
    computed_at: str


class ActionResult(BaseModel):
    ok: bool
    message: str
    message_hi: str
    order: OrderOut
    discrepancies_created: list[str] = Field(default_factory=list)
