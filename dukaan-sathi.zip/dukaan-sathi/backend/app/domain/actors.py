"""Demo identities and role-based permissions, enforced in the service layer.

This is demonstration-grade access control (a bearer token maps to one of two fictional
businesses). Production use needs real identity, authentication and per-user authorization.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from app.domain.errors import PermissionDenied

Role = Literal["retailer", "distributor"]
Source = Literal["web", "assistant", "voice", "alexa", "mcp"]

RETAILER_ID = "RET-RAJ"
DISTRIBUTOR_ID = "DIS-SHARMA"


@dataclass(frozen=True)
class Actor:
    role: Role
    party_id: str
    display_name: str
    source: Source = "mcp"

    def require(self, *roles: Role, action: str) -> None:
        if self.role not in roles:
            allowed = " or ".join(roles)
            raise PermissionDenied(
                f"The {self.role} role cannot {action}. Only the {allowed} can do this.",
                message_hi=f"यह काम ({action}) केवल {allowed} कर सकता है।",
                details={"role": self.role, "allowed_roles": list(roles), "action": action},
            )


def actor_for_role(role: str, source: str = "mcp") -> Actor:
    src = source if source in ("web", "assistant", "voice", "alexa", "mcp") else "mcp"
    if role == "distributor":
        return Actor("distributor", DISTRIBUTOR_ID, "Anil Sharma (Sharma Building Supplies)", src)  # type: ignore[arg-type]
    return Actor("retailer", RETAILER_ID, "Raj (Raj Hardware Store)", src)  # type: ignore[arg-type]
