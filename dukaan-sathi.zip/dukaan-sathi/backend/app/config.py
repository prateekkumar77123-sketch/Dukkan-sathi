"""Runtime configuration, read from environment variables (and an optional .env file).

Every value has a safe local-development default so the demo runs without a .env file.
Public exposure (MCP_PUBLIC_URL / tunnelled Alexa endpoint) refuses to use the default tokens.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

try:  # python-dotenv is optional at runtime
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    load_dotenv = None

REPO_ROOT = Path(__file__).resolve().parents[2]

if load_dotenv is not None:
    load_dotenv(REPO_ROOT / ".env", override=False)

DEFAULT_RETAILER_TOKEN = "local-dev-retailer-token"
DEFAULT_DISTRIBUTOR_TOKEN = "local-dev-distributor-token"


def _bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    raw = os.getenv(name)
    try:
        return int(raw) if raw else default
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    database_path: Path
    mcp_host: str
    mcp_port: int
    mcp_url: str
    mcp_public_url: str | None
    mcp_client_mode: str
    mcp_timeout_seconds: float
    gateway_host: str
    gateway_port: int
    frontend_origins: list[str]
    retailer_token: str
    distributor_token: str
    alexa_skill_id: str | None
    alexa_verify_signatures: bool
    alexa_role: str
    anthropic_api_key: str | None
    anthropic_model: str
    write_rate_limit_per_minute: int
    upload_dir: Path
    extra_allowed_hosts: list[str] = field(default_factory=list)

    @property
    def uses_default_tokens(self) -> bool:
        return self.retailer_token == DEFAULT_RETAILER_TOKEN or self.distributor_token == DEFAULT_DISTRIBUTOR_TOKEN

    def token_for_role(self, role: str) -> str:
        if role == "distributor":
            return self.distributor_token
        return self.retailer_token

    def mcp_allowed_hosts(self) -> list[str]:
        hosts = [
            "127.0.0.1",
            "localhost",
            f"127.0.0.1:{self.mcp_port}",
            f"localhost:{self.mcp_port}",
        ]
        if self.mcp_public_url:
            parsed = urlparse(self.mcp_public_url)
            if parsed.hostname:
                hosts.append(parsed.hostname)
                if parsed.port:
                    hosts.append(f"{parsed.hostname}:{parsed.port}")
        hosts.extend(self.extra_allowed_hosts)
        return hosts


def load_settings() -> Settings:
    db_path = Path(os.getenv("DUKAAN_DB_PATH", str(REPO_ROOT / "data" / "dukaan_sathi.db")))
    mcp_host = os.getenv("MCP_HOST", "127.0.0.1")
    mcp_port = _int("MCP_PORT", 8001)
    origins = os.getenv("FRONTEND_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    return Settings(
        database_path=db_path,
        mcp_host=mcp_host,
        mcp_port=mcp_port,
        mcp_url=os.getenv("MCP_URL", f"http://127.0.0.1:{mcp_port}/mcp"),
        mcp_public_url=os.getenv("MCP_PUBLIC_URL") or None,
        mcp_client_mode=os.getenv("MCP_CLIENT_MODE", "legacy"),
        mcp_timeout_seconds=float(os.getenv("MCP_TIMEOUT_SECONDS", "10")),
        gateway_host=os.getenv("GATEWAY_HOST", "127.0.0.1"),
        gateway_port=_int("GATEWAY_PORT", 8000),
        frontend_origins=[o.strip() for o in origins.split(",") if o.strip()],
        retailer_token=os.getenv("MCP_RETAILER_TOKEN", DEFAULT_RETAILER_TOKEN),
        distributor_token=os.getenv("MCP_DISTRIBUTOR_TOKEN", DEFAULT_DISTRIBUTOR_TOKEN),
        alexa_skill_id=os.getenv("ALEXA_SKILL_ID") or None,
        alexa_verify_signatures=_bool("ALEXA_VERIFY_SIGNATURES", True),
        alexa_role=os.getenv("ALEXA_ROLE", "retailer"),
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY") or None,
        anthropic_model=os.getenv("ANTHROPIC_MODEL", "claude-haiku-5-5"),
        write_rate_limit_per_minute=_int("WRITE_RATE_LIMIT_PER_MINUTE", 60),
        upload_dir=Path(os.getenv("UPLOAD_DIR", str(REPO_ROOT / "data" / "uploads"))),
        extra_allowed_hosts=[h.strip() for h in os.getenv("MCP_EXTRA_ALLOWED_HOSTS", "").split(",") if h.strip()],
    )


settings = load_settings()
