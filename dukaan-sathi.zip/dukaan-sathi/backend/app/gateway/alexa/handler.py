"""Alexa custom-skill request handler (en-IN and hi-IN).

Echo device -> Alexa cloud -> HTTPS (tunnel) -> POST /alexa on the gateway -> assistant engine
-> MCP client over Streamable HTTP -> Dukaan Sathi MCP server -> SQLite.

The skill uses the same assistant engine and MCP tools as the website, so a question asked on the Echo and the
same question typed on the website produce answers from the same records.
"""

from __future__ import annotations

import html
import re
from typing import Any

from app.gateway.assistant.engine import AssistantEngine, Reply
from app.gateway.assistant.nlu import Intent, product_category

PRODUCT_SLOT_TO_QUERY = {
    # slot values from the interaction model, mapped to catalogue search words
    "opc 53 cement": "opc 53 cement", "opc 43 cement": "opc 43 cement", "ppc cement": "ppc cement",
    "cement": "cement", "सीमेंट": "सीमेंट", "opc fifty three cement": "opc 53 cement", "opc fifty three": "opc 53 cement",
    "opc forty three cement": "opc 43 cement", "opc forty three": "opc 43 cement", "opc तिरपन": "opc 53 cement",
    "opc तैंतालीस": "opc 43 cement", "सरिया": "tmt bar", "पेंच": "screws", "तार": "binding wire",
}

TEXT = {
    "welcome": ("Namaste! Dukaan Sathi here, with Raj Hardware Store's sample order records. You can say: check my "
                "cement delivery, where is order 1042, or which deliveries need attention.",
                "नमस्ते! मैं दुकान साथी हूँ, राज हार्डवेयर स्टोर के डेमो ऑर्डर रिकॉर्ड के साथ। आप कह सकते हैं: मेरी सीमेंट "
                "डिलीवरी चेक करो, ऑर्डर 1042 कहाँ है, या किन ऑर्डर में कमी है।"),
    "reprompt": ("You can ask another question, or say stop.", "आप और कुछ पूछ सकते हैं, या बंद करो कहें।"),
    "help": ("Try: check my cement delivery. Where is order 1042. Which deliveries need attention. Order 30 bags of "
             "PPC cement. Or, give me my shop summary.",
             "ऐसे पूछिए: मेरी सीमेंट डिलीवरी चेक करो। ऑर्डर 1042 कहाँ है। किन ऑर्डर में कमी है। PPC सीमेंट की 30 बोरी "
             "ऑर्डर करो। या, मेरी दुकान का हिसाब बताओ।"),
    "bye": ("Okay. Dhanyavaad!", "ठीक है। धन्यवाद!"),
    "cancelled": ("Okay, cancelled. Nothing was sent.", "ठीक है, रद्द कर दिया। कुछ नहीं भेजा गया।"),
    "nothing_pending": ("There's nothing waiting for confirmation.", "पुष्टि के लिए कुछ भी बाकी नहीं है।"),
    "confirm_tail": (" Say yes to confirm, or no to cancel.", " पुष्टि के लिए हाँ कहें, या रद्द करने के लिए नहीं।"),
    "need_order": ("Which order number? For example, order 1042.", "कौन सा ऑर्डर नंबर? जैसे, ऑर्डर 1042।"),
    "repeat_with_grade": (" Please say the order again with the exact item, for example: order 50 bags of OPC 53 cement.",
                          " कृपया सही आइटम के साथ फिर से बोलें, जैसे: OPC 53 सीमेंट की 50 बोरी ऑर्डर करो।"),
    "fallback": ("Sorry, I didn't get that. ", "माफ़ कीजिए, मैं समझ नहीं पाया। "),
}


def t(key: str, lang: str) -> str:
    en, hi = TEXT[key]
    return hi if lang == "hi" else en


def to_ssml(text: str, lang: str) -> str:
    """Escape for SSML and make order / discrepancy ids speakable (D S 1 0 4 2)."""
    s = html.escape(text, quote=False)
    s = s.replace("₹", "rupees " if lang == "en" else "रुपये ")
    s = re.sub(r"\s*\|\s*", ". ", s)
    prefix = {"DS": "डी एस" if lang == "hi" else "D S", "DSC": "डी एस सी" if lang == "hi" else "D S C"}
    s = re.sub(r"\b(DSC|DS)-(\d+)\b", lambda m: f"{prefix[m.group(1)]} <say-as interpret-as=\"digits\">{m.group(2)}</say-as>", s)
    s = s.replace("“", "").replace("”", "")
    if len(s) > 6000:
        s = s[:6000].rsplit(" ", 1)[0] + "…"
    return f"<speak>{s}</speak>"


def build_response(speech: str, lang: str, *, end: bool = False, attrs: dict | None = None,
                   card_text: str | None = None, reprompt: bool = True) -> dict[str, Any]:
    response: dict[str, Any] = {
        "outputSpeech": {"type": "SSML", "ssml": to_ssml(speech, lang)},
        "shouldEndSession": end,
    }
    if card_text:
        response["card"] = {"type": "Simple", "title": "Dukaan Sathi", "content": card_text[:7900]}
    if not end and reprompt:
        response["reprompt"] = {"outputSpeech": {"type": "SSML", "ssml": to_ssml(t("reprompt", lang), lang)}}
    return {"version": "1.0", "sessionAttributes": attrs or {}, "response": response}


def _slot(intent: dict, name: str) -> str | None:
    slot = (intent.get("slots") or {}).get(name) or {}
    resolutions = (slot.get("resolutions") or {}).get("resolutionsPerAuthority") or []
    for res in resolutions:
        if res.get("status", {}).get("code") == "ER_SUCCESS_MATCH":
            values = res.get("values") or []
            if values:  # prefer the slot value id (a catalogue search phrase) over the spoken name
                return values[0]["value"].get("id") or values[0]["value"]["name"]
    value = slot.get("value")
    return value.strip() if isinstance(value, str) and value.strip() else None


def _order_id(intent: dict, attrs: dict) -> str | None:
    number = _slot(intent, "orderNumber")
    if number and re.fullmatch(r"\d+", number):
        return f"DS-{int(number)}"
    return attrs.get("context_order_id")


class AlexaHandler:
    def __init__(self, engine: AssistantEngine, role: str = "retailer"):
        self.engine = engine
        self.role = role

    async def handle(self, payload: dict[str, Any]) -> dict[str, Any]:
        request = payload.get("request", {})
        lang = "hi" if str(request.get("locale", "")).lower().startswith("hi") else "en"
        attrs: dict[str, Any] = dict((payload.get("session") or {}).get("attributes") or {})
        rtype = request.get("type")
        if rtype == "LaunchRequest":
            return build_response(t("welcome", lang), lang, attrs=attrs)
        if rtype == "SessionEndedRequest":
            return {"version": "1.0", "response": {}}
        if rtype != "IntentRequest":
            return build_response(t("help", lang), lang, attrs=attrs)

        intent = request.get("intent", {})
        name = intent.get("name", "")

        if name in ("AMAZON.StopIntent", "AMAZON.CancelIntent"):
            if attrs.pop("pending_action", None):
                return build_response(t("cancelled", lang), lang, end=True)
            return build_response(t("bye", lang), lang, end=True)
        if name == "AMAZON.HelpIntent":
            return build_response(t("help", lang), lang, attrs=attrs)
        if name == "AMAZON.NoIntent":
            if attrs.pop("pending_action", None):
                return build_response(t("cancelled", lang) + " " + t("reprompt", lang), lang, attrs=attrs)
            return build_response(t("bye", lang), lang, end=True)
        if name == "AMAZON.YesIntent":
            pending = attrs.pop("pending_action", None)
            if not pending:
                if attrs.get("context_order_id"):  # "yes" after "would you like to open the timeline?"
                    reply = await self.engine.timeline(attrs["context_order_id"], role=self.role, lang=lang, source="alexa")
                    return self._reply(reply, lang, attrs)
                return build_response(t("nothing_pending", lang), lang, attrs=attrs)
            reply = await self.engine.confirm(pending, role=self.role, lang=lang, source="alexa")
            return self._reply(reply, lang, attrs)

        it = self._to_intent(name, intent, attrs, lang)
        if it is None:
            return build_response(t("fallback", lang) + t("help", lang), lang, attrs=attrs)
        if it.name in ("order_status", "order_history") and not it.order_id:
            return build_response(t("need_order", lang), lang, attrs=attrs)
        reply = await self.engine.handle_message(it.raw, role=self.role, ui_lang=lang, source="alexa",
                                                 context_order_id=attrs.get("context_order_id"), intent=it)
        return self._reply(reply, lang, attrs)

    def _to_intent(self, name: str, intent: dict, attrs: dict, lang: str) -> Intent | None:
        order_id = _order_id(intent, attrs)
        product = _slot(intent, "product")
        query = PRODUCT_SLOT_TO_QUERY.get((product or "").lower(), product)
        category, _ = product_category(query or "") if query else (None, None)
        if name == "OrderStatusIntent":
            return Intent("order_status", lang, f"order status {order_id}", order_id=order_id)
        if name == "OrderHistoryIntent":
            return Intent("order_history", lang, f"timeline {order_id}", order_id=order_id)
        if name == "CheckDeliveryIntent":
            explicit = _slot(intent, "orderNumber")
            return Intent("check_delivery", lang, f"check delivery {product or ''}",
                          order_id=f"DS-{int(explicit)}" if explicit and explicit.isdigit() else None,
                          category=category or ("Cement" if not explicit else None), product_query=query)
        if name == "AttentionIntent":
            return Intent("attention", lang, "which deliveries need attention")
        if name == "InTransitIntent":
            return Intent("in_transit", lang, "orders in transit")
        if name == "ShopSummaryIntent":
            return Intent("dashboard", lang, "shop summary")
        if name == "StockIntent":
            return Intent("stock", lang, f"stock {query}", product_query=query, category=category)
        if name == "CreateOrderIntent":
            qty = _slot(intent, "quantity")
            unit = _slot(intent, "unit")
            if not qty or not qty.isdigit() or not query:
                return Intent("help", lang, "create order incomplete")
            return Intent("create_order", lang, f"order {qty} {unit or ''} {query}", product_query=query,
                          category=category, quantity=float(qty), unit=unit)
        if name == "AddNoteIntent":
            return Intent("add_note", lang, "note", order_id=order_id, note=_slot(intent, "note"))
        return None

    def _reply(self, reply: Reply, lang: str, attrs: dict) -> dict[str, Any]:
        if reply.context_order_id:
            attrs["context_order_id"] = reply.context_order_id
        speech = reply.speech
        if reply.pending_action:
            attrs["pending_action"] = reply.pending_action
            speech += t("confirm_tail", lang)
        elif any(c.get("type") == "choices" for c in reply.cards):
            speech += t("repeat_with_grade", lang)
        return build_response(speech, lang, attrs=attrs, card_text=reply.text)
