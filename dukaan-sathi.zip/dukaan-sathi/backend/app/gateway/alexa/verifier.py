"""Verify that an HTTPS request really comes from the Alexa service (custom skill hosted as a web service).

Checks, per Amazon's "Host a Custom Skill as a Web Service" guidance:
  1. SignatureCertChainUrl: https, host s3.amazonaws.com, path under /echo.api/, port 443 if given.
  2. The certificate chain is valid now, chains to a trusted root, and names echo-api.amazon.com.
  3. Signature-256 header = RSA/SHA-256 signature of the raw request body.
  4. request.timestamp is within 150 seconds.
  5. (optional) applicationId matches ALEXA_SKILL_ID.
"""

from __future__ import annotations

import base64
import posixpath
import time
from datetime import UTC, datetime
from urllib.parse import urlparse

import certifi
import httpx
from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.x509.verification import DNSName, PolicyBuilder, Store, VerificationError

TIMESTAMP_TOLERANCE_SECONDS = 150
_cert_cache: dict[str, tuple[float, list[x509.Certificate]]] = {}
_store: Store | None = None


class AlexaVerificationError(Exception):
    pass


def validate_cert_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme.lower() != "https":
        raise AlexaVerificationError("certificate URL must use https")
    if (parsed.hostname or "").lower() != "s3.amazonaws.com":
        raise AlexaVerificationError("certificate URL host must be s3.amazonaws.com")
    if parsed.port not in (None, 443):
        raise AlexaVerificationError("certificate URL port must be 443")
    path = posixpath.normpath(parsed.path) if parsed.path else ""
    if not path.startswith("/echo.api/"):
        raise AlexaVerificationError("certificate URL path must start with /echo.api/")


def validate_timestamp(timestamp: str, now: datetime | None = None) -> None:
    try:
        ts = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    except (ValueError, AttributeError) as exc:
        raise AlexaVerificationError("invalid request timestamp") from exc
    current = now or datetime.now(UTC)
    if abs((current - ts).total_seconds()) > TIMESTAMP_TOLERANCE_SECONDS:
        raise AlexaVerificationError("request timestamp outside the 150 second tolerance")


def _trust_store() -> Store:
    global _store
    if _store is None:
        with open(certifi.where(), "rb") as fh:
            _store = Store(x509.load_pem_x509_certificates(fh.read()))
    return _store


async def _fetch_chain(url: str) -> list[x509.Certificate]:
    cached = _cert_cache.get(url)
    if cached and cached[0] > time.time():
        return cached[1]
    async with httpx.AsyncClient(timeout=5) as client:
        response = await client.get(url)
        response.raise_for_status()
    chain = x509.load_pem_x509_certificates(response.content)
    if not chain:
        raise AlexaVerificationError("empty certificate chain")
    _cert_cache[url] = (time.time() + 3600, chain)
    return chain


def verify_chain(chain: list[x509.Certificate]) -> x509.Certificate:
    leaf, intermediates = chain[0], chain[1:]
    verifier = PolicyBuilder().store(_trust_store()).time(datetime.now(UTC)).build_server_verifier(
        DNSName("echo-api.amazon.com")
    )
    try:
        verifier.verify(leaf, intermediates)
    except VerificationError as exc:
        raise AlexaVerificationError(f"certificate chain rejected: {exc}") from exc
    return leaf


def verify_signature(leaf: x509.Certificate, signature_b64: str, body: bytes) -> None:
    key = leaf.public_key()
    if not isinstance(key, rsa.RSAPublicKey):
        raise AlexaVerificationError("unexpected certificate key type")
    try:
        key.verify(base64.b64decode(signature_b64), body, padding.PKCS1v15(), hashes.SHA256())
    except (InvalidSignature, ValueError) as exc:
        raise AlexaVerificationError("request signature does not match the body") from exc


async def verify_request(headers: dict[str, str], body: bytes, payload: dict, skill_id: str | None) -> None:
    h = {k.lower(): v for k, v in headers.items()}
    cert_url = h.get("signaturecertchainurl")
    signature = h.get("signature-256")
    if not cert_url or not signature:
        raise AlexaVerificationError("missing SignatureCertChainUrl or Signature-256 header")
    validate_cert_url(cert_url)
    chain = await _fetch_chain(cert_url)
    leaf = verify_chain(chain)
    verify_signature(leaf, signature, body)
    validate_timestamp(payload.get("request", {}).get("timestamp", ""))
    check_application_id(payload, skill_id)


def check_application_id(payload: dict, skill_id: str | None) -> None:
    if not skill_id:
        return
    app_id = (
        payload.get("context", {}).get("System", {}).get("application", {}).get("applicationId")
        or payload.get("session", {}).get("application", {}).get("applicationId")
    )
    if app_id != skill_id:
        raise AlexaVerificationError("applicationId does not match ALEXA_SKILL_ID")
