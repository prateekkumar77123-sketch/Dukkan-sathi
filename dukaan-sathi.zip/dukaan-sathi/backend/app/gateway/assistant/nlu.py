"""Rule-based, bilingual (English / Hindi / Hinglish) intent parser.

It only extracts *what the user is asking for* (intent, order id, product words, quantity, unit). It never
decides whether a product, unit or quantity is valid - the MCP tools and the business rules do that.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

DEVANAGARI = re.compile(r"[ऀ-ॿ]")

HINGLISH_MARKERS = {
    "kya", "kahan", "kaha", "kahaan", "hai", "mera", "meri", "mere", "karo", "kardo", "chahiye", "kitna", "kitne",
    "kitni", "dikhao", "batao", "aaya", "aya", "mila", "maal", "kab", "wala", "wali", "bhejo", "mangwao", "mangao",
    "kami", "dukaan", "dukan", "hisaab", "hisab", "abhi", "kitna", "humara", "hamara", "pura", "poora", "nahi",
    "kaun", "konsa", "kis", "kin", "bori", "sariya", "saria",
}

NUMBER_WORDS = {
    # English
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20, "twenty five": 25, "thirty": 30, "forty": 40,
    "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90, "hundred": 100, "a hundred": 100,
    "one hundred": 100, "two hundred": 200, "three hundred": 300, "four hundred": 400, "five hundred": 500,
    # Hindi (Devanagari)
    "एक": 1, "दो": 2, "तीन": 3, "चार": 4, "पांच": 5, "पाँच": 5, "छह": 6, "छः": 6, "सात": 7, "आठ": 8, "नौ": 9,
    "दस": 10, "बारह": 12, "पंद्रह": 15, "बीस": 20, "पच्चीस": 25, "तीस": 30, "चालीस": 40, "पचास": 50, "साठ": 60,
    "सत्तर": 70, "अस्सी": 80, "नब्बे": 90, "सौ": 100, "एक सौ": 100, "दो सौ": 200, "तीन सौ": 300, "चार सौ": 400,
    "पांच सौ": 500, "पाँच सौ": 500,
    # Hinglish
    "das": 10, "bees": 20, "pachees": 25, "tees": 30, "chalees": 40, "chalis": 40, "pachas": 50, "pachaas": 50,
    "saath": 60, "assi": 80, "sau": 100, "do sau": 200, "teen sau": 300, "paanch sau": 500,
}

UNIT_WORDS = (
    r"bags?|bori(?:ya|yan)?|kattas?|pieces?|pcs?|nos|lengths?|kgs?|kilos?|kilograms?|packs?|packets?|metres?|meters?|mtr|"
    r"tonnes?|tons?|grams?|g|feet|ft|"
    r"बोरी|बोरियां|बोरियाँ|बोरे|बैग|कट्टा|कट्टे|पीस|नग|लंबाई|लम्बाई|लेंथ|किलो|केजी|पैकेट|पैक|मीटर|टन|ग्राम"
)

PRODUCT_TERMS = {
    "cement": "Cement", "सीमेंट": "Cement", "सिमेंट": "Cement", "opc": "Cement", "ppc": "Cement",
    "tmt": "Steel", "sariya": "Steel", "saria": "Steel", "सरिया": "Steel", "सरिये": "Steel", "rebar": "Steel",
    "steel": "Steel", "bar": "Steel", "bars": "Steel",
    "wire": "Steel", "तार": "Steel",
    "pipe": "Pipes", "pipes": "Pipes", "पाइप": "Pipes",
    "screw": "Fasteners", "screws": "Fasteners", "पेंच": "Fasteners", "स्क्रू": "Fasteners",
    "putty": "Finishes", "पुट्टी": "Finishes",
    "conduit": "Electrical", "कंड्यूट": "Electrical",
}

KW = {
    "note": ["note", "नोट", "likh do", "लिख दो", "record a note", "add a note"],
    "history": ["history", "timeline", "events", "itihaas", "itihas", "इतिहास", "टाइमलाइन", "हिस्ट्री", "kya kya hua",
                "क्या क्या हुआ", "what happened"],
    "attention": ["attention", "mismatch", "discrepan", "shortage", "short", "missing", "problem", "issue", "kami",
                  "कमी", "गड़बड़", "गड़बड़ी", "समस्या", "मिसमैच", "अंतर", "kam aaya", "कम आया", "kam mila", "कम मिला",
                  "need review", "difference", "gadbad"],
    "delivery": ["delivery", "deliver", "received", "receive", "arrive", "full quantity", "pura", "poora", "पूरा",
                 "डिलीवरी", "आया", "मिला", "maal", "माल", "check my", "aaya", "pahuncha", "पहुंचा", "पहुँचा"],
    "transit": ["transit", "on the way", "not received", "raste", "रास्ते", "नहीं आया", "nahi aaya", "dispatched but",
                "in the way", "abhi tak nahi"],
    "confirmed": ["confirmed", "confirm kiya", "पुष्टि", "confirm hua", "kitna confirm", "confirmation quantity"],
    "create": ["order", "draft", "need", "want", "chahiye", "चाहिए", "mangwao", "mangao", "मंगवाओ", "मंगाओ",
               "मँगवाओ", "ऑर्डर", "आर्डर", "bhejo", "भेजो", "book", "place"],
    "create_verb": ["order karo", "order kar do", "ऑर्डर करो", "ऑर्डर कर दो", "आर्डर करो", "mangwao", "mangao",
                    "मंगवाओ", "मंगाओ", "मँगवाओ", "chahiye", "चाहिए", "i need", "i want", "create", "place an order",
                    "order ", "draft", "bhejo", "भेजो", "book", "दे दो", "de do"],
    "dashboard": ["summary", "overview", "how many", "kitne", "कितने", "dashboard", "dukaan", "dukan", "दुकान",
                  "hisaab", "hisab", "हिसाब", "my shop", "business", "aaj ka", "आज का", "status of my", "details"],
    "pending": ["pending", "need confirmation", "new orders", "naye order", "नए ऑर्डर", "awaiting", "incoming"],
    "stock": ["stock", "available", "availability", "स्टॉक", "उपलब्ध", "milega", "मिलेगा", "do you have", "hai kya",
              "है क्या", "price", "rate", "दाम", "कीमत"],
    "help": ["help", "madad", "मदद", "what can you do", "क्या कर सकते", "kya kar sakte"],
    "question": ["where", "what", "which", "did", "show", "status", "kahan", "kaha", "कहाँ", "कहां", "क्या", "kya",
                 "kaun", "कौन", "kis", "किस", "किन", "dikhao", "दिखाओ", "batao", "बताओ", "how", "?"],
}


@dataclass
class Intent:
    name: str
    lang: str
    raw: str
    order_id: str | None = None
    product_query: str | None = None
    category: str | None = None
    quantity: float | None = None
    unit: str | None = None
    note: str | None = None
    draft_only: bool = False
    debug: dict = field(default_factory=dict)


def detect_language(text: str, ui_lang: str = "en") -> str:
    if DEVANAGARI.search(text):
        return "hi"
    words = set(re.findall(r"[a-z]+", text.lower()))
    if len(words & HINGLISH_MARKERS) >= 1 and not ({"the", "is", "my", "of", "which", "what", "where"} & words and
                                                   len(words & HINGLISH_MARKERS) < 2):
        return "hi"
    return "hi" if ui_lang == "hi" else "en"


def _has(text: str, key: str) -> bool:
    return any(k in text for k in KW[key])


def words_to_digits(text: str) -> str:
    # "कर दो" / "दे दो" mean "do it / give", not the number two.
    text = re.sub(r"(कर|दे|भेज|मंगा|मंगवा)\s+दो(?![\w\u0900-\u097F])", r"\1ो", text)
    text = re.sub(r"(कर|दे)\s+दीजिए", r"\1ो", text)
    out = f" {text} "
    for word in sorted(NUMBER_WORDS, key=len, reverse=True):
        out = re.sub(rf"(?<![\wऀ-ॿ]){re.escape(word)}(?![\wऀ-ॿ])", str(NUMBER_WORDS[word]), out)
    return out.strip()


ORDER_ID_RE = re.compile(
    r"(?:\bd\.?\s?s\.?|डीएस|डी\s?एस|order|ऑर्डर|आर्डर|number|नंबर|no\.?)\s*[-#:]?\s*(\d{3,5})\b|\b(10\d{2})\b",
    re.IGNORECASE,
)


def extract_order_id(text: str) -> str | None:
    for m in ORDER_ID_RE.finditer(text):
        digits = m.group(1) or m.group(2)
        if digits and len(digits) >= 4:
            return f"DS-{int(digits)}"
    return None


QTY_UNIT_RE = re.compile(rf"(\d+(?:\.\d+)?)\s*-?\s*({UNIT_WORDS})(?![\wऀ-ॿ])", re.IGNORECASE)
NOT_QTY_AFTER = re.compile(r"^\s*-?\s*(?:mm|मिमी|inch|इंच|\"|grade|ग्रेड|d\b|गेज|gauge|x|×)", re.IGNORECASE)
NOT_QTY_BEFORE = re.compile(r"(?:opc|ppc|fe|grade|ग्रेड|ds|डीएस|order|ऑर्डर|no\.?|नंबर|x|×)\s*-?\s*$", re.IGNORECASE)


def extract_quantity(text: str) -> tuple[float | None, str | None, tuple[int, int] | None]:
    m = QTY_UNIT_RE.search(text)
    if m:
        return float(m.group(1)), m.group(2), m.span()
    for m in re.finditer(r"\d+(?:\.\d+)?", text):
        before, after = text[: m.start()], text[m.end():]
        if NOT_QTY_AFTER.match(after) or NOT_QTY_BEFORE.search(before):
            continue
        if re.fullmatch(r"10\d{2}", m.group(0)) and re.search(r"(order|ds|ऑर्डर)\s*$", before, re.IGNORECASE):
            continue
        return float(m.group(0)), None, m.span()
    return None, None, None


FILLER = re.compile(
    r"\b(?:please|pls|kindly|order|create|a|an|the|draft|for|of|i|need|want|me|from|sharma building supplies|"
    r"sharma|place|book|karo|kar|do|dena|chahiye|mangwao|mangao|bhejo|ka|ki|ke|wala|wali|naya|new|send|to|"
    r"dukaan sathi|dukan sathi|hey|ok|okay)\b|ऑर्डर|आर्डर|करो|कर|दो|चाहिए|मंगवाओ|मंगाओ|मँगवाओ|भेजो|का|की|के|"
    r"से|को|शर्मा बिल्डिंग सप्लाइज़|शर्मा|दुकान साथी|नया|ड्राफ्ट|बनाओ|दे",
    re.IGNORECASE,
)


def extract_product_phrase(text: str, qty_span: tuple[int, int] | None) -> str | None:
    rest = text
    if qty_span:
        rest = text[: qty_span[0]] + " " + text[qty_span[1]:]
    rest = FILLER.sub(" ", rest)
    rest = re.sub(r"[,.;:!?]", " ", rest)
    rest = re.sub(r"\s+", " ", rest).strip()
    return rest or None


def product_category(text: str) -> tuple[str | None, str | None]:
    lowered = text.lower()
    for term, cat in PRODUCT_TERMS.items():
        if re.search(rf"(?<![\wऀ-ॿ]){re.escape(term)}(?![\wऀ-ॿ])", lowered):
            return cat, term
    return None, None


def parse(message: str, ui_lang: str = "en", context_order_id: str | None = None) -> Intent:
    raw = message.strip()
    lang = detect_language(raw, ui_lang)
    text = words_to_digits(raw.lower())
    text = re.sub(r"^(?:alexa|hey alexa|dukaan sathi|dukan sathi|दुकान साथी)[,\s]+", "", text)
    order_id = extract_order_id(text)
    category, term = product_category(text)
    refers_to_context = bool(re.search(r"\b(this|that|is|us)\b.*\border\b|इस ऑर्डर|is order|isi order", text))
    if not order_id and refers_to_context:
        order_id = context_order_id

    # 1. note
    if _has(text, "note"):
        note_text = re.split(r"note[:\-]?|नोट[:\-]?|likh do|लिख दो", raw, maxsplit=1, flags=re.IGNORECASE)
        body = note_text[1].strip(" :-\"'") if len(note_text) > 1 else ""
        return Intent("add_note", lang, raw, order_id=order_id or context_order_id, note=body or None)

    # 2. create an order: a quantity plus product words plus an ordering verb (and not a question)
    text_wo_id = ORDER_ID_RE.sub(" ", text) if order_id else text
    qty, unit, span = extract_quantity(text_wo_id)
    is_question = _has(text, "question") and not _has(text, "create_verb")
    if qty is not None and category and (_has(text, "create_verb") or (unit and not is_question)):
        phrase = extract_product_phrase(text_wo_id, span)
        return Intent("create_order", lang, raw, product_query=phrase, category=category, quantity=qty, unit=unit,
                      draft_only="draft" in text or "ड्राफ्ट" in text)

    # 3. history
    if _has(text, "history") and (order_id or context_order_id) and not ("what happened" in text and not order_id and category):
        return Intent("order_history" if "what happened" not in text else "order_status", lang, raw,
                      order_id=order_id or context_order_id)

    # 4. order-specific questions
    if order_id:
        if _has(text, "confirmed"):
            return Intent("confirmed_qty", lang, raw, order_id=order_id)
        if _has(text, "delivery") or _has(text, "attention"):
            return Intent("check_delivery", lang, raw, order_id=order_id)
        return Intent("order_status", lang, raw, order_id=order_id)

    if _has(text, "pending"):
        return Intent("pending_confirmations", lang, raw)
    if _has(text, "transit"):
        return Intent("in_transit", lang, raw, category=category)
    if _has(text, "confirmed") and category:
        return Intent("confirmed_qty", lang, raw, category=category, product_query=term)
    if category and _has(text, "delivery"):
        return Intent("check_delivery", lang, raw, category=category, product_query=term)
    if _has(text, "attention"):
        return Intent("attention", lang, raw, category=category)
    if category and _has(text, "stock"):
        phrase = extract_product_phrase(text, None)
        return Intent("stock", lang, raw, category=category, product_query=phrase)
    if _has(text, "help"):
        return Intent("help", lang, raw)
    if _has(text, "dashboard"):
        return Intent("dashboard", lang, raw)
    if category:
        phrase = extract_product_phrase(text, None)
        if qty is not None:
            return Intent("create_order", lang, raw, product_query=phrase, category=category, quantity=qty, unit=unit)
        return Intent("stock", lang, raw, category=category, product_query=phrase)
    if _has(text, "delivery"):
        return Intent("attention", lang, raw)
    return Intent("help", lang, raw, debug={"unrecognised": True})
