"""Assistant orchestration: intent -> MCP tool calls -> grounded bilingual answer.

All facts in a reply come from MCP tool results. Write operations are returned as a pending action that the
person must confirm; only then does /api/assistant/confirm call the write tools.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from app.domain.rules import fmt_qty, normalise_unit, unit_label
from app.gateway.assistant.nlu import Intent, parse
from app.gateway.mcp_client import MCPCallError, MCPGateway, MCPSession

log = logging.getLogger("dukaan.assistant")

IST = timezone(timedelta(hours=5, minutes=30))
HI_MONTHS = ["जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"]

STATUS_TEXT = {
    "draft": ("a draft that has not been sent yet", "ड्राफ्ट है, अभी भेजा नहीं गया"),
    "pending_confirmation": ("waiting for the distributor to confirm", "डिस्ट्रीब्यूटर की पुष्टि का इंतज़ार है"),
    "confirmed": ("confirmed and waiting to be dispatched", "पुष्टि हो गई है, डिस्पैच बाकी है"),
    "in_transit": ("in transit", "रास्ते में है"),
    "delivered": ("delivered", "डिलीवर हो गया है"),
    "needs_review": ("delivered but needs review", "डिलीवर हुआ पर जाँच ज़रूरी है"),
    "resolved": ("delivered, and its difference has been resolved", "डिलीवर हुआ और अंतर का समाधान हो गया है"),
}


def q(qty: float | None, unit: str, lang: str) -> str:
    return f"{fmt_qty(qty)} {unit_label(unit, qty, lang)}"


def when(ts: str | None, lang: str) -> str:
    if not ts:
        return ""
    if len(ts) == 10:  # a date
        d = datetime.fromisoformat(ts).date()
        today = datetime.now(IST).date()
    else:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(IST)
        d = dt.date()
        today = datetime.now(IST).date()
    if d == today:
        day = "today" if lang == "en" else "आज"
    elif d == today - timedelta(days=1):
        day = "yesterday" if lang == "en" else "कल"
    elif d == today + timedelta(days=1):
        day = "tomorrow" if lang == "en" else "कल (आने वाला)"
    else:
        day = d.strftime("%d %b").lstrip("0") if lang == "en" else f"{d.day} {HI_MONTHS[d.month - 1]}"
    if len(ts) == 10:
        return day
    t = dt.strftime("%I:%M %p").lstrip("0").lower() if lang == "en" else dt.strftime("%H:%M")
    return f"{day} at {t}" if lang == "en" else f"{day} {t} बजे"


@dataclass
class Reply:
    lang: str
    text: str
    speech: str
    intent: str
    cards: list[dict[str, Any]] = field(default_factory=list)
    suggestions: list[dict[str, Any]] = field(default_factory=list)
    context_order_id: str | None = None
    pending_action: dict[str, Any] | None = None
    traces: list[dict[str, Any]] = field(default_factory=list)
    error: dict[str, Any] | None = None

    def as_dict(self, mode: str) -> dict[str, Any]:
        return {
            "lang": self.lang, "reply": self.text, "speech": self.speech, "intent": self.intent, "cards": self.cards,
            "suggestions": self.suggestions, "context_order_id": self.context_order_id,
            "pending_action": self.pending_action, "mcp": self.traces, "error": self.error, "mode": mode,
        }


def T(lang: str, en: str, hi: str) -> str:
    return hi if lang == "hi" else en


def order_card(order: dict[str, Any]) -> dict[str, Any]:
    return {"type": "order", "order": order}


def suggestion(label: str, action: dict[str, Any]) -> dict[str, Any]:
    return {"label": label, "action": action}


class AssistantEngine:
    def __init__(self, gateway: MCPGateway):
        self.gateway = gateway

    async def handle_message(self, message: str, *, role: str, ui_lang: str, source: str,
                             context_order_id: str | None = None, selection: dict | None = None,
                             intent: Intent | None = None) -> Reply:
        if selection:
            lang = ui_lang if ui_lang in ("en", "hi") else "en"
            intent = Intent("create_order", lang, message or "", product_query=selection.get("sku"),
                            quantity=selection.get("quantity"), unit=selection.get("unit"),
                            draft_only=bool(selection.get("draft_only")), debug={"sku": selection.get("sku")})
        elif intent is None:
            if not message.strip():
                return self._help(ui_lang, role)
            intent = parse(message, ui_lang, context_order_id)
        lang = intent.lang
        try:
            async with self.gateway.session(role, source) as s:
                reply = await self._dispatch(s, intent, role)
                reply.traces = [t.as_dict() for t in s.traces]
                return reply
        except MCPCallError as exc:
            traces = [exc.trace.as_dict()] if exc.trace else []
            if exc.code == "not_found":
                text = exc.message_hi if lang == "hi" else exc.message
                return Reply(lang, text, text, intent.name, traces=traces, error=exc.payload())
            if exc.code in ("mcp_unavailable", "mcp_timeout"):
                text = T(lang, "I can't reach the Dukaan Sathi MCP server right now, so I can't look up live records. "
                               "Please check that it is running and try again.",
                         "अभी Dukaan Sathi MCP सर्वर से संपर्क नहीं हो पा रहा, इसलिए लाइव रिकॉर्ड नहीं देख सकता। "
                         "कृपया जाँचें कि वह चल रहा है और फिर कोशिश करें।")
                return Reply(lang, text, text, intent.name, traces=traces, error=exc.payload(),
                             suggestions=[suggestion(T(lang, "Retry", "फिर कोशिश करें"), {"type": "retry"})])
            text = exc.message_hi if lang == "hi" else exc.message
            return Reply(lang, text, text, intent.name, traces=traces, error=exc.payload())

    # ------------------------------------------------------------------ routing

    async def _dispatch(self, s: MCPSession, it: Intent, role: str) -> Reply:
        handler = {
            "order_status": self._order_status,
            "check_delivery": self._check_delivery,
            "order_history": self._history,
            "attention": self._attention,
            "in_transit": self._in_transit,
            "confirmed_qty": self._confirmed,
            "create_order": self._create_order,
            "dashboard": self._dashboard,
            "pending_confirmations": self._pending,
            "stock": self._stock,
            "add_note": self._add_note,
        }.get(it.name)
        if handler is None:
            return self._help(it.lang, role, unrecognised=bool(it.debug.get("unrecognised")))
        return await handler(s, it, role)

    def _help(self, lang: str, role: str, unrecognised: bool = False) -> Reply:
        lead = T(lang, "I didn't catch an order question there. ", "मैं सवाल पूरी तरह समझ नहीं पाया। ") if unrecognised else ""
        text = lead + T(
            lang,
            "You can ask things like: “Where is order DS-1042?”, “Check my cement delivery”, “Which deliveries need "
            "attention?”, “Order 30 bags of PPC cement”, or “Show my shop summary”.",
            "आप पूछ सकते हैं: “ऑर्डर DS-1042 कहाँ है?”, “मेरी सीमेंट डिलीवरी चेक करो”, “किन ऑर्डर में कमी है?”, "
            "“PPC सीमेंट की 30 बोरी ऑर्डर करो”, या “मेरी दुकान का हिसाब बताओ”।",
        )
        samples = (["Where is order DS-1042?", "Check my cement delivery", "Which deliveries need attention?"]
                   if lang == "en" else ["ऑर्डर DS-1042 कहाँ है?", "मेरी सीमेंट डिलीवरी चेक करो", "किन ऑर्डर में कमी है?"])
        return Reply(lang, text, text, "help", suggestions=[suggestion(x, {"type": "message", "text": x}) for x in samples])

    # ------------------------------------------------------------------ order questions

    def _discrepancy_sentence(self, order: dict[str, Any], lang: str) -> str:
        parts = []
        for d in order["discrepancies"]:
            if d["status"] == "resolved":
                continue
            ack_by = next((n["author_role"] for n in reversed(d["notes"]) if n["kind"] == "acknowledgement"), None)
            ack_en = f"acknowledged by the {ack_by}" if ack_by else "acknowledged"
            ack_hi = {"distributor": "डिस्ट्रीब्यूटर ने स्वीकार किया", "retailer": "रिटेलर ने स्वीकार किया"}.get(ack_by or "", "स्वीकार किया गया")
            status = {"open": T(lang, "open", "खुला"), "acknowledged": T(lang, ack_en, ack_hi),
                      "under_review": T(lang, "under review", "जाँच जारी")}[d["status"]]
            parts.append(T(lang, f"{d['id']} is {status}", f"{d['id']} — {status}"))
        return "; ".join(parts)

    def _status_text(self, order: dict[str, Any], lang: str) -> str:
        oid = order["id"]
        ln = order["lines"][0]
        name = ln["product_name_hi"] if lang == "hi" else ln["product_name"]
        what = T(lang, f"{q(ln['requested_qty'], ln['unit'], 'en')} of {name}", f"{name} — {q(ln['requested_qty'], ln['unit'], 'hi')}")
        if len(order["lines"]) > 1:
            what += T(lang, f" and {len(order['lines']) - 1} more item(s)", f" और {len(order['lines']) - 1} अन्य आइटम")
        st_en, st_hi = STATUS_TEXT[order["status"]]
        dist = order["distributor"]["name_hi" if lang == "hi" else "name"]
        text = T(lang, f"Order {oid} ({what}) is {st_en}.", f"ऑर्डर {oid} ({what}) {st_hi}।")
        d = order.get("dispatch")
        if order["status"] in ("confirmed",):
            text += T(lang, f" {dist} confirmed {q(ln['confirmed_qty'], ln['unit'], 'en')}.",
                      f" {dist} ने {q(ln['confirmed_qty'], ln['unit'], 'hi')} की पुष्टि की है।")
        if d and order["status"] == "in_transit":
            exp = d.get("expected_delivery_date")
            text += T(lang,
                      f" {dist} recorded {q(ln['dispatched_qty'], ln['unit'], 'en')} dispatched {when(d['dispatched_at'], 'en')} "
                      f"under challan {d['challan_ref']}" + (f"; expected delivery {when(exp, 'en')}." if exp else "."),
                      f" {dist} ने {when(d['dispatched_at'], 'hi')} चालान {d['challan_ref']} से {q(ln['dispatched_qty'], ln['unit'], 'hi')} "
                      "भेजी दर्ज की" + (f"; डिलीवरी {when(exp, 'hi')} तक अपेक्षित है।" if exp else "।"))
        if order["status"] in ("needs_review", "delivered", "resolved"):
            text += " " + self._comparison_text(order, lang)
        return text

    def _comparison_text(self, order: dict[str, Any], lang: str) -> str:
        sentences = []
        for ln in order["lines"]:
            if ln["received_qty"] is None:
                continue
            cmp = ln["comparison"]
            if cmp["outcome"] == "short":
                sentences.append(T(
                    lang,
                    f"The distributor recorded {q(ln['dispatched_qty'], ln['unit'], 'en')} dispatched, but your receipt record shows "
                    f"{q(ln['received_qty'], ln['unit'], 'en')} received — {q(-cmp['receipt_variance'], ln['unit'], 'en')} short.",
                    f"डिस्ट्रीब्यूटर ने {q(ln['dispatched_qty'], ln['unit'], 'hi')} भेजी दर्ज की, लेकिन आपकी प्राप्ति में "
                    f"{q(ln['received_qty'], ln['unit'], 'hi')} दर्ज है — यानी {q(-cmp['receipt_variance'], ln['unit'], 'hi')} कम।"))
            elif cmp["outcome"] == "excess":
                sentences.append(T(
                    lang,
                    f"{q(ln['received_qty'], ln['unit'], 'en')} were received against {q(ln['dispatched_qty'], ln['unit'], 'en')} dispatched — "
                    f"{q(cmp['receipt_variance'], ln['unit'], 'en')} extra.",
                    f"{q(ln['dispatched_qty'], ln['unit'], 'hi')} भेजी गई और {q(ln['received_qty'], ln['unit'], 'hi')} मिली — "
                    f"{q(cmp['receipt_variance'], ln['unit'], 'hi')} अधिक।"))
            elif cmp["outcome"] == "match":
                sentences.append(T(
                    lang,
                    f"All {q(ln['received_qty'], ln['unit'], 'en')} of {ln['product_name']} were received, matching the dispatch.",
                    f"{ln['product_name_hi']} की पूरी {q(ln['received_qty'], ln['unit'], 'hi')} मिली, डिस्पैच से मेल खाती है।"))
            if ln["damaged_qty"]:
                sentences.append(T(lang, f"{q(ln['damaged_qty'], ln['unit'], 'en')} were reported damaged.",
                                   f"{q(ln['damaged_qty'], ln['unit'], 'hi')} क्षतिग्रस्त बताई गई।"))
        disc = self._discrepancy_sentence(order, lang)
        if disc:
            sentences.append(T(lang, f"Discrepancy {disc}; no final resolution recorded yet.",
                               f"अंतर {disc}; अभी अंतिम समाधान दर्ज नहीं है।"))
        elif order["status"] == "resolved":
            res = [r for d in order["discrepancies"] for r in d["resolutions"]]
            if res:
                sentences.append(T(lang, f"Resolution recorded: “{res[-1]['notes']}”", f"दर्ज समाधान: “{res[-1]['notes']}”"))
        return " ".join(sentences)

    def _order_followups(self, order: dict[str, Any], lang: str, role: str) -> list[dict[str, Any]]:
        out = [suggestion(T(lang, "Open timeline", "टाइमलाइन खोलें"), {"type": "timeline", "order_id": order["id"]}),
               suggestion(T(lang, "Open order page", "ऑर्डर पेज खोलें"), {"type": "navigate", "to": f"/app/orders/{order['id']}"})]
        open_disc = [d for d in order["discrepancies"] if d["status"] != "resolved"]
        if open_disc:
            out.insert(1, suggestion(T(lang, "Record a note", "नोट दर्ज करें"),
                                     {"type": "record_note", "order_id": order["id"], "discrepancy_id": open_disc[0]["id"]}))
        return out

    async def _order_status(self, s: MCPSession, it: Intent, role: str) -> Reply:
        order, _ = await s.call("get_order_status", {"order_id": it.order_id})
        text = self._status_text(order, it.lang)
        return Reply(it.lang, text, text, it.name, cards=[order_card(order)],
                     suggestions=self._order_followups(order, it.lang, role), context_order_id=order["id"])

    async def _find_order_for_category(self, s: MCPSession, category: str | None) -> dict[str, Any] | None:
        listing, _ = await s.call("list_orders", {"category": category, "limit": 20})
        rows = listing["orders"]
        if not rows:
            return None
        rank = {"needs_review": 0, "in_transit": 1, "delivered": 2, "resolved": 3, "confirmed": 4, "pending_confirmation": 5, "draft": 6}
        best = sorted(rows, key=lambda o: (rank.get(o["status"], 9), o["created_at"]))[0]
        if best["status"] in ("needs_review", "in_transit"):
            return best
        return sorted(rows, key=lambda o: o["created_at"], reverse=True)[0]

    async def _check_delivery(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        if it.order_id:
            order, _ = await s.call("get_order_status", {"order_id": it.order_id})
        else:
            found = await self._find_order_for_category(s, it.category)
            if not found:
                text = T(lang, f"I couldn't find any {it.category or ''} orders in your records.",
                         f"आपके रिकॉर्ड में {it.product_query or ''} का कोई ऑर्डर नहीं मिला।")
                return Reply(lang, text, text, it.name)
            order, _ = await s.call("get_order_status", {"order_id": found["id"]})
        ln = order["lines"][0]
        name = ln["product_name_hi"] if lang == "hi" else ln["product_name"]
        intro = T(lang, f"I found order {order['id']} for {q(ln['requested_qty'], ln['unit'], 'en')} of {name}.",
                  f"मुझे ऑर्डर {order['id']} मिला — {name}, {q(ln['requested_qty'], ln['unit'], 'hi')}।")
        if order["status"] in ("needs_review", "delivered", "resolved"):
            body = self._comparison_text(order, lang)
            status_line = T(lang, f" Status: {STATUS_TEXT[order['status']][0]}.", f" स्थिति: {STATUS_TEXT[order['status']][1]}।")
        else:
            body = T(lang, f"It is {STATUS_TEXT[order['status']][0]}; no receipt has been recorded yet.",
                     f"यह {STATUS_TEXT[order['status']][1]}; अभी प्राप्ति दर्ज नहीं हुई है।")
            status_line = ""
        ask = ""
        if order["open_discrepancy_count"]:
            ask = T(lang, " Would you like to open the order timeline or record a discrepancy note?",
                    " क्या आप ऑर्डर की टाइमलाइन खोलना चाहेंगे या अंतर पर नोट दर्ज करना चाहेंगे?")
        text = f"{intro} {body}{status_line}{ask}"
        return Reply(lang, text, text, it.name, cards=[order_card(order)],
                     suggestions=self._order_followups(order, lang, role), context_order_id=order["id"])

    async def _history(self, s: MCPSession, it: Intent, role: str) -> Reply:
        tl, _ = await s.call("get_order_timeline", {"order_id": it.order_id})
        lang = it.lang
        events = tl["events"]
        last = events[-4:]
        lines = [f"{when(e['at'], lang)} — {e['summary_hi'] if lang == 'hi' else e['summary']}" for e in last]
        text = T(lang, f"Order {tl['order_id']} has {len(events)} recorded events. Most recent: ",
                 f"ऑर्डर {tl['order_id']} में {len(events)} घटनाएँ दर्ज हैं। हाल की: ") + " · ".join(lines)
        speech_events = "; ".join(f"{when(e['at'], lang)}, {e['summary_hi'] if lang == 'hi' else e['summary']}" for e in events[-2:])
        speech = T(lang, f"Order {tl['order_id']} has {len(events)} recorded events. The latest: {speech_events}.",
                   f"ऑर्डर {tl['order_id']} में {len(events)} घटनाएँ दर्ज हैं। सबसे हाल की: {speech_events}।")
        return Reply(lang, text, speech, it.name, cards=[{"type": "timeline", "timeline": tl}],
                     suggestions=[suggestion(T(lang, "Open order page", "ऑर्डर पेज खोलें"),
                                             {"type": "navigate", "to": f"/app/orders/{tl['order_id']}"})],
                     context_order_id=tl["order_id"])

    async def _attention(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        disc, _ = await s.call("list_discrepancies", {"status": "unresolved"})
        items = disc["discrepancies"]
        if not items:
            text = T(lang, "No deliveries need attention — every recorded difference has a resolution.",
                     "किसी डिलीवरी पर ध्यान देने की ज़रूरत नहीं — हर दर्ज अंतर का समाधान हो चुका है।")
            return Reply(lang, text, text, it.name)
        orders_seen: dict[str, list[dict]] = {}
        for d in items:
            orders_seen.setdefault(d["order_id"], []).append(d)
        parts = []
        for oid, ds in orders_seen.items():
            descs = "; ".join(
                T(lang, f"{fmt_qty(d['difference_qty'])} {d['unit_label']} {d['kind']} on {d['product_name']} ({d['id']}, {d['status'].replace('_', ' ')})",
                  f"{d['product_name_hi']} पर {fmt_qty(d['difference_qty'])} {d['unit_label_hi']} {({'short': 'कम', 'excess': 'अधिक', 'damaged': 'क्षतिग्रस्त', 'other': 'अंतर'})[d['kind']]} ({d['id']})")
                for d in ds)
            parts.append(f"{oid} — {descs}")
        n = len(orders_seen)
        text = T(lang, f"{n} order{'s' if n != 1 else ''} need{'s' if n == 1 else ''} attention: ", f"{n} ऑर्डर पर ध्यान देना ज़रूरी है: ") + " | ".join(parts)
        listing, _ = await s.call("list_orders", {"has_discrepancy": True})
        first = next(iter(orders_seen))
        return Reply(lang, text, text, it.name, cards=[{"type": "order_list", "orders": listing["orders"]},
                                                        {"type": "discrepancies", "discrepancies": items}],
                     suggestions=[suggestion(T(lang, f"Check {first}", f"{first} देखें"), {"type": "message", "text": f"Check delivery for {first}" if lang == "en" else f"{first} की डिलीवरी चेक करो"}),
                                  suggestion(T(lang, "Open discrepancies page", "अंतर पेज खोलें"), {"type": "navigate", "to": "/app/discrepancies"})],
                     context_order_id=first)

    async def _in_transit(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        listing, _ = await s.call("list_orders", {"status": "in_transit", "category": it.category})
        rows = listing["orders"]
        if not rows:
            text = T(lang, "No orders are dispatched-and-awaiting-receipt right now.", "अभी कोई ऑर्डर रास्ते में नहीं है।")
            return Reply(lang, text, text, it.name)
        parts = [f"{o['id']} ({o['headline_hi'] if lang == 'hi' else o['headline']}" +
                 (T(lang, f", expected {when(o['expected_delivery_date'], 'en')}", f", अपेक्षित {when(o['expected_delivery_date'], 'hi')}")
                  if o["expected_delivery_date"] else "") + ")" for o in rows]
        text = T(lang, f"{len(rows)} order(s) are dispatched but not yet received: ", f"{len(rows)} ऑर्डर भेजे जा चुके हैं पर अभी मिले नहीं: ") + "; ".join(parts) + "."
        return Reply(lang, text, text, it.name, cards=[{"type": "order_list", "orders": rows}],
                     context_order_id=rows[0]["id"])

    async def _confirmed(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        oid = it.order_id
        if not oid:
            found = await self._find_order_for_category(s, it.category)
            if not found:
                text = T(lang, "I couldn't find a matching order.", "मिलता-जुलता ऑर्डर नहीं मिला।")
                return Reply(lang, text, text, it.name)
            oid = found["id"]
        order, _ = await s.call("get_order_status", {"order_id": oid})
        parts = []
        for ln in order["lines"]:
            name = ln["product_name_hi"] if lang == "hi" else ln["product_name"]
            if ln["confirmed_qty"] is None:
                parts.append(T(lang, f"{name}: not confirmed yet (requested {q(ln['requested_qty'], ln['unit'], 'en')})",
                               f"{name}: अभी पुष्टि नहीं (माँगी {q(ln['requested_qty'], ln['unit'], 'hi')})"))
            else:
                parts.append(T(lang, f"{name}: {q(ln['confirmed_qty'], ln['unit'], 'en')} confirmed of {q(ln['requested_qty'], ln['unit'], 'en')} requested",
                               f"{name}: माँगी गई {q(ln['requested_qty'], ln['unit'], 'hi')} में से {q(ln['confirmed_qty'], ln['unit'], 'hi')} की पुष्टि"))
        text = T(lang, f"For order {order['id']}, ", f"ऑर्डर {order['id']} में, ") + "; ".join(parts) + T(lang, ".", "।")
        return Reply(lang, text, text, it.name, cards=[order_card(order)],
                     suggestions=self._order_followups(order, lang, role), context_order_id=order["id"])

    # ------------------------------------------------------------------ ordering

    async def _create_order(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        if role != "retailer":
            text = T(lang, "Orders are placed by the retailer. Switch to the Retailer demo role to create one.",
                     "ऑर्डर रिटेलर बनाते हैं। ऑर्डर बनाने के लिए रिटेलर डेमो भूमिका चुनें।")
            return Reply(lang, text, text, it.name)
        sku = it.debug.get("sku")
        if sku:
            found, _ = await s.call("search_products", {"sku": sku})
        else:
            found, _ = await s.call("search_products", {"query": it.product_query or it.category or ""})
        products = found["products"]
        if not products:
            text = T(lang, f"I couldn't find “{it.product_query}” in the catalogue. Try the product name, size or grade.",
                     f"कैटलॉग में “{it.product_query}” नहीं मिला। उत्पाद का नाम, साइज़ या ग्रेड बताएँ।")
            return Reply(lang, text, text, it.name)
        if len(products) > 1:
            text = T(lang, f"“{it.product_query}” matches {len(products)} catalogue items. Which one do you mean?",
                     f"“{it.product_query}” से {len(products)} उत्पाद मिलते हैं। आप कौन-सा चाहते हैं?")
            options = [{"label": (p["name_hi"] if lang == "hi" else p["name"]) + f" — {p['spec_hi'] if lang == 'hi' else p['spec']}",
                        "sku": p["sku"], "quantity": it.quantity, "unit": it.unit or p["unit"], "draft_only": it.draft_only,
                        "available_qty": p["available_qty"], "unit_label": p["unit_label_hi"] if lang == "hi" else p["unit_label"]}
                       for p in products[:6]]
            speech = text + " " + ", ".join(o["label"].split(" — ")[0] for o in options) + "."
            return Reply(lang, text, speech, it.name, cards=[{"type": "choices", "options": options}])
        product = products[0]
        unit_given = it.unit
        unit = normalise_unit(unit_given) if unit_given else product["unit"]
        if unit_given and unit is None:
            unit = unit_given  # unsupported word (e.g. tonnes) - let validation reject it explicitly
        lines = [{"sku": product["sku"], "quantity": it.quantity, "unit": unit}]
        validation, _ = await s.call("validate_order", {"lines": lines})
        line = validation["lines"][0]
        name = product["name_hi"] if lang == "hi" else product["name"]
        if not line["valid"]:
            msg = " ".join(line["messages_hi"] if lang == "hi" else line["messages"])
            sugg = []
            if line.get("unit") and line["unit"] != unit:
                alt = {"sku": product["sku"], "quantity": it.quantity, "unit": product["unit"], "draft_only": it.draft_only}
                label = T(lang, f"Order {fmt_qty(it.quantity)} {unit_label(product['unit'], it.quantity)} instead",
                          f"{fmt_qty(it.quantity)} {unit_label(product['unit'], lang='hi')} ऑर्डर करें")
                sugg.append(suggestion(label, {"type": "select", "selection": alt}))
            text = T(lang, f"I can't prepare that order yet. {msg}", f"यह ऑर्डर अभी तैयार नहीं हो सकता। {msg}")
            return Reply(lang, text, text, it.name, cards=[{"type": "validation", "validation": validation}], suggestions=sugg)
        qty_txt = q(line["canonical_qty"], line["unit"], lang)
        unit_note = ""
        if not unit_given:
            unit_note = T(lang, f" (You didn't say a unit, so I used the catalogue unit: {unit_label(product['unit'])}.)",
                          f" (आपने इकाई नहीं बताई, इसलिए कैटलॉग की इकाई ली गई: {unit_label(product['unit'], lang='hi')}।)")
        avail = " ".join(line["messages_hi"] if lang == "hi" else line["messages"])
        action_type = "create_draft" if it.draft_only else "create_and_submit"
        verb = T(lang, "create a draft for", "ड्राफ्ट बनाऊँ") if it.draft_only else T(lang, "send an order for", "ऑर्डर भेजूँ")
        text = T(lang,
                 f"Please confirm: {verb} {qty_txt} of {name} ({product['spec']}) from Sharma Building Supplies?{unit_note} {avail}",
                 f"कृपया पुष्टि करें: क्या मैं शर्मा बिल्डिंग सप्लाइज़ से {name} ({product['spec_hi']}) की {qty_txt} का {verb}?{unit_note} {avail}")
        speech = T(lang, f"Please confirm: {verb} {qty_txt} of {name} from Sharma Building Supplies?{unit_note}",
                   f"कृपया पुष्टि करें: क्या मैं शर्मा बिल्डिंग सप्लाइज़ से {name} की {qty_txt} का {verb}?{unit_note}")
        if line["availability"] != "available":
            speech += " " + avail
        pending = {"type": action_type, "lines": [{"sku": line["sku"], "quantity": line["canonical_qty"], "unit": line["unit"]}],
                   "distributor_id": "DIS-SHARMA"}
        return Reply(lang, text, speech, it.name, cards=[{"type": "confirm_order", "validation": validation, "product": product,
                                                         "action": pending}],
                     pending_action=pending)

    # ------------------------------------------------------------------ summaries

    async def _dashboard(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        d, _ = await s.call("get_dashboard_summary", {})
        name = d["party_name_hi"] if lang == "hi" else d["party_name"]
        text = T(lang,
                 f"{name} (sample data): {d['total_orders']} orders — {d['in_transit']} in transit, {d['needs_review']} need review, "
                 f"{d['delivered']} delivered ({d['resolved']} after a resolved difference).",
                 f"{name} (डेमो डेटा): कुल {d['total_orders']} ऑर्डर — {d['in_transit']} रास्ते में, {d['needs_review']} में जाँच ज़रूरी, "
                 f"{d['delivered']} डिलीवर ({d['resolved']} में अंतर का समाधान हुआ)।")
        if d["pending_confirmation"]:
            text += T(lang, f" {d['pending_confirmation']} awaiting confirmation.", f" {d['pending_confirmation']} पुष्टि के इंतज़ार में।")
        if d["attention"]:
            first = d["attention"][0]
            text += T(lang, f" Needs attention first: {first['id']} ({first['headline']}).",
                      f" सबसे पहले देखें: {first['id']} ({first['headline_hi']})।")
        return Reply(lang, text, text, it.name, cards=[{"type": "dashboard", "summary": d}],
                     suggestions=[suggestion(T(lang, "Which deliveries need attention?", "किन ऑर्डर में कमी है?"),
                                             {"type": "message", "text": T(lang, "Which deliveries need attention?", "किन ऑर्डर में कमी है?")})],
                     context_order_id=d["attention"][0]["id"] if d["attention"] else None)

    async def _pending(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        listing, _ = await s.call("list_orders", {"status": "pending_confirmation"})
        rows = listing["orders"]
        if not rows:
            text = T(lang, "No orders are waiting for confirmation.", "कोई ऑर्डर पुष्टि के इंतज़ार में नहीं है।")
            return Reply(lang, text, text, it.name)
        text = T(lang, f"{len(rows)} order(s) await distributor confirmation: ", f"{len(rows)} ऑर्डर डिस्ट्रीब्यूटर की पुष्टि के इंतज़ार में: ") + \
            "; ".join(f"{o['id']} ({o['headline_hi'] if lang == 'hi' else o['headline']})" for o in rows)
        return Reply(lang, text, text, it.name, cards=[{"type": "order_list", "orders": rows}], context_order_id=rows[0]["id"])

    async def _stock(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        found, _ = await s.call("search_products", {"query": it.product_query or it.category or ""})
        products = found["products"]
        if not products:
            text = T(lang, "I couldn't find that product in the catalogue.", "यह उत्पाद कैटलॉग में नहीं मिला।")
            return Reply(lang, text, text, it.name)
        parts = []
        for p in products[:5]:
            name = p["name_hi"] if lang == "hi" else p["name"]
            if p["available_qty"] <= 0:
                parts.append(T(lang, f"{name}: out of stock", f"{name}: स्टॉक में नहीं"))
            else:
                parts.append(T(lang, f"{name}: {q(p['available_qty'], p['unit'], 'en')} available at ₹{p['price_inr']:,.0f}/{unit_label(p['unit'], 1)}",
                               f"{name}: {q(p['available_qty'], p['unit'], 'hi')} उपलब्ध, ₹{p['price_inr']:,.0f} प्रति {unit_label(p['unit'], lang='hi')}"))
        text = T(lang, "Sharma Building Supplies (illustrative demo stock and prices): ",
                 "शर्मा बिल्डिंग सप्लाइज़ (डेमो स्टॉक और दाम, वास्तविक नहीं): ") + "; ".join(parts) + T(lang, ".", "।")
        return Reply(lang, text, text, it.name, cards=[{"type": "products", "products": products[:5]}])

    async def _add_note(self, s: MCPSession, it: Intent, role: str) -> Reply:
        lang = it.lang
        if not it.order_id:
            text = T(lang, "Which order is the note for? Say the order number, for example DS-1042.",
                     "नोट किस ऑर्डर के लिए है? ऑर्डर नंबर बताएँ, जैसे DS-1042।")
            return Reply(lang, text, text, it.name)
        order, _ = await s.call("get_order_status", {"order_id": it.order_id})
        open_disc = [d for d in order["discrepancies"] if d["status"] != "resolved"]
        if not open_disc:
            text = T(lang, f"Order {order['id']} has no open discrepancy to add a note to.",
                     f"ऑर्डर {order['id']} पर कोई खुला अंतर नहीं है जिस पर नोट जोड़ा जा सके।")
            return Reply(lang, text, text, it.name, context_order_id=order["id"])
        d = open_disc[0]
        if not it.note:
            text = T(lang, f"What should the note on {d['id']} say?", f"{d['id']} पर नोट में क्या लिखना है?")
            return Reply(lang, text, text, it.name, suggestions=[suggestion(T(lang, "Record a note", "नोट दर्ज करें"),
                         {"type": "record_note", "order_id": order["id"], "discrepancy_id": d["id"]})], context_order_id=order["id"])
        pending = {"type": "add_note", "discrepancy_id": d["id"], "note": it.note, "order_id": order["id"]}
        text = T(lang, f"Add this note to {d['id']} on order {order['id']}: “{it.note}”?",
                 f"क्या यह नोट ऑर्डर {order['id']} के {d['id']} पर जोड़ दूँ: “{it.note}”?")
        return Reply(lang, text, text, it.name, pending_action=pending, context_order_id=order["id"],
                     cards=[{"type": "confirm_note", "action": pending}])

    # ------------------------------------------------------------------ confirmed writes

    async def confirm(self, action: dict[str, Any], *, role: str, lang: str, source: str) -> Reply:
        kind = action.get("type")
        try:
            async with self.gateway.session(role, source) as s:
                if kind in ("create_and_submit", "create_draft"):
                    created, _ = await s.call("create_draft_order", {"lines": action.get("lines", []),
                                                                     "distributor_id": action.get("distributor_id", "DIS-SHARMA")})
                    order = created["order"]
                    if kind == "create_and_submit":
                        submitted, _ = await s.call("submit_order", {"order_id": order["id"]})
                        order = submitted["order"]
                        text = T(lang, f"Done. Order {order['id']} ({order['headline']}) has been sent to {order['distributor']['name']} for confirmation.",
                                 f"हो गया। ऑर्डर {order['id']} ({order['headline_hi']}) पुष्टि के लिए {order['distributor']['name_hi']} को भेज दिया गया है।")
                        sugg = [suggestion(T(lang, "Open order page", "ऑर्डर पेज खोलें"), {"type": "navigate", "to": f"/app/orders/{order['id']}"})]
                    else:
                        text = T(lang, f"Draft {order['id']} ({order['headline']}) saved. It has not been sent yet.",
                                 f"ड्राफ्ट {order['id']} ({order['headline_hi']}) सहेजा गया। अभी भेजा नहीं गया है।")
                        sugg = [suggestion(T(lang, f"Submit {order['id']} now", f"{order['id']} अभी भेजें"),
                                           {"type": "confirm", "action": {"type": "submit", "order_id": order["id"]}}),
                                suggestion(T(lang, "Open order page", "ऑर्डर पेज खोलें"), {"type": "navigate", "to": f"/app/orders/{order['id']}"})]
                    reply = Reply(lang, text, text, "order_created", cards=[order_card(order)], suggestions=sugg, context_order_id=order["id"])
                elif kind == "submit":
                    res, _ = await s.call("submit_order", {"order_id": action.get("order_id")})
                    order = res["order"]
                    text = res["message_hi"] if lang == "hi" else res["message"]
                    reply = Reply(lang, text, text, "order_submitted", cards=[order_card(order)], context_order_id=order["id"])
                elif kind == "add_note":
                    res, _ = await s.call("add_discrepancy_note", {"discrepancy_id": action.get("discrepancy_id"),
                                                                   "note": action.get("note", ""),
                                                                   "acknowledge": bool(action.get("acknowledge"))})
                    order = res["order"]
                    tl, _ = await s.call("get_order_timeline", {"order_id": order["id"]})
                    text = T(lang, f"Note saved on {action.get('discrepancy_id')} and added to the {order['id']} timeline.",
                             f"{action.get('discrepancy_id')} पर नोट सहेजा गया और {order['id']} की टाइमलाइन में जुड़ गया।")
                    reply = Reply(lang, text, text, "note_added", cards=[order_card(order), {"type": "timeline", "timeline": tl}],
                                  context_order_id=order["id"])
                else:
                    text = T(lang, "That action isn't supported.", "यह क्रिया समर्थित नहीं है।")
                    reply = Reply(lang, text, text, "unknown_action")
                reply.traces = [t.as_dict() for t in s.traces]
                return reply
        except MCPCallError as exc:
            text = exc.message_hi if lang == "hi" else exc.message
            return Reply(lang, text, text, "error", traces=[exc.trace.as_dict()] if exc.trace else [], error=exc.payload())

    async def timeline(self, order_id: str, *, role: str, lang: str, source: str) -> Reply:
        it = Intent("order_history", lang, f"timeline {order_id}", order_id=order_id)
        return await self.handle_message("", role=role, ui_lang=lang, source=source, intent=it)
