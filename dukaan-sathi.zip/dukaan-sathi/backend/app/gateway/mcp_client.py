"""The gateway's MCP client: every business read/write goes through the MCP server over Streamable HTTP.

Each call is traced (tool, input summary, outcome, result summary, elapsed time, negotiated protocol) so the
website can show exactly which MCP tools ran. Traces never contain tokens.
"""

from __future__ import annotations

import itertools
import json
import logging
import time
from collections import deque
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field
from typing import Any

import anyio
import httpx2
from mcp import Client
from mcp.client.streamable_http import streamable_http_client
from mcp.shared._httpx_utils import create_mcp_http_client

from app.config import settings
from app.db import now_iso

log = logging.getLogger("dukaan.gateway.mcp")

WRITE_TOOLS = {
    "create_draft_order", "submit_order", "confirm_order", "record_dispatch", "record_delivery",
    "report_discrepancy", "add_discrepancy_note", "resolve_discrepancy",
}


@dataclass
class ToolTrace:
    id: int
    at: str
    tool: str
    role: str
    source: str
    input_summary: str
    ok: bool
    result_summary: str
    error_code: str | None
    elapsed_ms: int
    protocol_version: str | None
    transport: str = "streamable-http"
    endpoint: str = ""
    is_write: bool = False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class MCPCallError(Exception):
    """A tool returned isError=True (business error) or the server could not be reached."""

    def __init__(self, code: str, message: str, message_hi: str | None = None, details: dict | None = None,
                 trace: ToolTrace | None = None, status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.message_hi = message_hi or message
        self.details = details or {}
        self.trace = trace
        self.status = status

    def payload(self) -> dict[str, Any]:
        return {"code": self.code, "message": self.message, "message_hi": self.message_hi, "details": self.details}


STATUS_FOR_CODE = {
    "not_found": 404, "validation_failed": 422, "permission_denied": 403, "invalid_state_transition": 409,
    "ambiguous": 422, "unauthorized": 401, "mcp_unavailable": 503, "mcp_timeout": 504, "tool_error": 400,
}


def _summarise_input(args: dict[str, Any]) -> str:
    if not args:
        return "{}"
    parts = []
    for k, v in args.items():
        if v in (None, "", [], {}):
            continue
        if isinstance(v, list):
            text = json.dumps(v, ensure_ascii=False)
            parts.append(f"{k}={text if len(text) < 90 else text[:87] + '…'}")
        else:
            text = str(v)
            parts.append(f"{k}={text if len(text) < 60 else text[:57] + '…'}")
    return ", ".join(parts) or "{}"


def _summarise_result(tool: str, data: dict[str, Any]) -> str:
    try:
        if tool == "search_products":
            s = f"{data['count']} product(s)"
            if data.get("products"):
                s += ": " + ", ".join(p["sku"] for p in data["products"][:4])
            return s + (" — needs clarification" if data.get("needs_clarification") else "")
        if tool == "get_order_status":
            return f"{data['id']} · {data['status']} · {len(data['lines'])} line(s) · {data['open_discrepancy_count']} open discrepancy"
        if tool == "get_order_timeline":
            return f"{data['order_id']} · {len(data['events'])} events"
        if tool == "list_orders":
            ids = ", ".join(o["id"] for o in data["orders"][:5])
            return f"{data['count']} order(s){': ' + ids if ids else ''}"
        if tool == "list_discrepancies":
            return f"{data['count']} discrepancy record(s)"
        if tool == "get_dashboard_summary":
            return (f"{data['total_orders']} orders · {data['in_transit']} in transit · {data['needs_review']} need review · "
                    f"{data['delivered']} delivered")
        if tool == "validate_order":
            return ("valid" if data["valid"] else "invalid") + (" · fully available" if data.get("fully_available") else "")
        if "order" in data and isinstance(data["order"], dict):
            o = data["order"]
            created = data.get("discrepancies_created") or []
            return f"{o['id']} → {o['status']}" + (f" · flagged {', '.join(created)}" if created else "")
    except (KeyError, TypeError):
        pass
    return "ok"


def _parse_tool_error(text: str) -> dict[str, Any]:
    start = text.find("{")
    if start >= 0:
        try:
            parsed = json.loads(text[start:])
            if isinstance(parsed, dict) and "error" in parsed:
                return parsed["error"]
        except json.JSONDecodeError:
            pass
    return {"code": "tool_error", "message": text}


def _unwrap(exc: BaseException) -> BaseException:
    """Find the meaningful exception inside (possibly nested) exception groups from anyio task groups."""
    while isinstance(exc, BaseExceptionGroup):
        candidates = [e for e in exc.exceptions if not isinstance(e, anyio.get_cancelled_exc_class())]
        exc = (candidates or list(exc.exceptions))[0]
    return exc


class MCPGateway:
    def __init__(self, url: str | None = None, mode: str | None = None, timeout: float | None = None):
        self.url = url or settings.mcp_url
        self.mode = mode or settings.mcp_client_mode
        self.timeout = timeout or settings.mcp_timeout_seconds
        self.traces: deque[ToolTrace] = deque(maxlen=300)
        self._ids = itertools.count(1)
        self.data_version = 0
        self.last_protocol_version: str | None = None

    def _headers(self, role: str, source: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {settings.token_for_role(role)}",
            "X-Dukaan-Source": source,
            "User-Agent": "dukaan-sathi-gateway/1.0",
        }

    @asynccontextmanager
    async def session(self, role: str, source: str = "web") -> AsyncIterator[MCPSession]:
        http = create_mcp_http_client(headers=self._headers(role, source), timeout=httpx2.Timeout(self.timeout))
        entered = False
        try:
            async with http, Client(streamable_http_client(self.url, http_client=http), mode=self.mode) as client:
                entered = True
                self.last_protocol_version = client.protocol_version
                yield MCPSession(self, client, role, source)
        except BaseException as exc:
            inner = _unwrap(exc)
            if entered or isinstance(inner, MCPCallError):
                raise inner from None
            if isinstance(inner, TimeoutError | httpx2.TimeoutException):
                raise self._unavailable("mcp_timeout", f"The MCP server did not respond within {self.timeout:.0f}s.",
                                        role, source) from exc
            if isinstance(inner, Exception):
                log.warning("MCP connection failed: %r", inner)
                raise self._unavailable("mcp_unavailable", f"Cannot reach the MCP server at {self.url}. Is it running?",
                                        role, source) from exc
            raise

    def _unavailable(self, code: str, message: str, role: str, source: str) -> MCPCallError:
        trace = ToolTrace(next(self._ids), now_iso(), "(connect)", role, source, self.url, False, message, code, 0,
                          None, endpoint=self.url)
        self.traces.append(trace)
        return MCPCallError(code, message, "MCP सर्वर से संपर्क नहीं हो पाया। क्या वह चल रहा है?", trace=trace,
                            status=STATUS_FOR_CODE[code])

    async def call(self, tool: str, args: dict[str, Any], role: str, source: str = "web") -> tuple[dict[str, Any], ToolTrace]:
        async with self.session(role, source) as s:
            return await s.call(tool, args)

    async def list_tools(self, role: str = "retailer") -> tuple[list[dict[str, Any]], str | None]:
        async with self.session(role, "web") as s:
            started = time.perf_counter()
            result = await s.client.list_tools()
            trace = ToolTrace(next(self._ids), now_iso(), "tools/list", role, "web", "{}", True,
                              f"{len(result.tools)} tools discovered", None,
                              int((time.perf_counter() - started) * 1000), s.client.protocol_version, endpoint=self.url)
            self.traces.append(trace)
            tools = [
                {"name": t.name, "title": t.title, "description": t.description, "input_schema": t.input_schema,
                 "has_output_schema": t.output_schema is not None,
                 "read_only": bool(t.annotations and t.annotations.read_only_hint)}
                for t in result.tools
            ]
            return tools, s.client.protocol_version

    def activity(self, after: int = 0) -> list[dict[str, Any]]:
        return [t.as_dict() for t in self.traces if t.id > after]


@dataclass
class MCPSession:
    gateway: MCPGateway
    client: Client
    role: str
    source: str
    traces: list[ToolTrace] = field(default_factory=list)

    async def call(self, tool: str, args: dict[str, Any]) -> tuple[dict[str, Any], ToolTrace]:
        clean = {k: v for k, v in args.items() if v is not None}
        started = time.perf_counter()
        gw = self.gateway
        try:
            with anyio.fail_after(gw.timeout):
                result = await self.client.call_tool(tool, clean)
        except TimeoutError as exc:
            trace = ToolTrace(next(gw._ids), now_iso(), tool, self.role, self.source, _summarise_input(clean), False,
                              "timed out", "mcp_timeout", int((time.perf_counter() - started) * 1000),
                              self.client.protocol_version, endpoint=gw.url, is_write=tool in WRITE_TOOLS)
            gw.traces.append(trace)
            raise MCPCallError("mcp_timeout", f"{tool} timed out.", trace=trace, status=504) from exc
        elapsed = int((time.perf_counter() - started) * 1000)
        if result.is_error:
            text = " ".join(getattr(c, "text", "") for c in result.content)
            err = _parse_tool_error(text)
            trace = ToolTrace(next(gw._ids), now_iso(), tool, self.role, self.source, _summarise_input(clean), False,
                              err.get("message", "error")[:160], err.get("code", "tool_error"), elapsed,
                              self.client.protocol_version, endpoint=gw.url, is_write=tool in WRITE_TOOLS)
            gw.traces.append(trace)
            self.traces.append(trace)
            raise MCPCallError(err.get("code", "tool_error"), err.get("message", text), err.get("message_hi"),
                               err.get("details"), trace=trace, status=STATUS_FOR_CODE.get(err.get("code", ""), 400))
        data = result.structured_content
        if data is None:
            text = " ".join(getattr(c, "text", "") for c in result.content)
            data = json.loads(text) if text.strip().startswith("{") else {"text": text}
        trace = ToolTrace(next(gw._ids), now_iso(), tool, self.role, self.source, _summarise_input(clean), True,
                          _summarise_result(tool, data), None, elapsed, self.client.protocol_version,
                          endpoint=gw.url, is_write=tool in WRITE_TOOLS)
        gw.traces.append(trace)
        self.traces.append(trace)
        if tool in WRITE_TOOLS:
            gw.data_version += 1
        return data, trace


gateway = MCPGateway()
