"""Dukaan Sathi API gateway (FastAPI).

The React website calls these endpoints. Business data is never read from the database here: every order,
catalogue and dashboard endpoint is served by calling the MCP server's tools through a real MCP client over
Streamable HTTP. The only direct database operation is the admin-only demo reset.

Run:  python -m app.gateway.main      (listens on http://127.0.0.1:8000)
"""

from __future__ import annotations

import json
import logging
import secrets
import time
from collections import defaultdict, deque
from typing import Any, Literal

import httpx
import uvicorn
from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from app.config import settings
from app.db import connect, ensure_database
from app.gateway.alexa.handler import AlexaHandler, build_response
from app.gateway.alexa.verifier import AlexaVerificationError, verify_request
from app.gateway.assistant.engine import AssistantEngine
from app.gateway.mcp_client import MCPCallError, ToolTrace, gateway
from app.seed import seed_database

log = logging.getLogger("dukaan.gateway")

app = FastAPI(title="Dukaan Sathi API gateway", version="1.0.0",
              description="Website API. Business operations are executed by the Dukaan Sathi MCP server.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.frontend_origins,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-Demo-Role", "X-Dukaan-Source"],
)

engine = AssistantEngine(gateway)
alexa = AlexaHandler(engine, role=settings.alexa_role)
LOCAL_HOSTS = {"localhost", "127.0.0.1", "[::1]"}
PUBLIC_PATHS = {"/alexa", "/alexa/health"}
IMAGE_SIGNATURES = {b"\xff\xd8\xff": "jpg", b"\x89PNG\r\n\x1a\n": "png", b"RIFF": "webp"}


# ------------------------------------------------------------------ middleware


@app.middleware("http")
async def guard(request: Request, call_next):
    """Only the signature-verified Alexa endpoint may be reached through a public tunnel hostname,
    and write endpoints are rate limited."""
    host = (request.headers.get("host") or "").split(":")[0].lower()
    if host not in LOCAL_HOSTS and request.url.path not in PUBLIC_PATHS:
        return JSONResponse({"error": {"code": "forbidden", "message": "Only /alexa is served on public hostnames."}},
                            status_code=403)
    if request.method == "POST" and request.url.path.startswith("/api/") and not _rate_ok(request):
        return JSONResponse({"error": {"code": "rate_limited", "message": "Too many write requests. Please wait a moment."}},
                            status_code=429)
    return await call_next(request)


_hits: dict[str, deque[float]] = defaultdict(deque)


def _rate_ok(request: Request) -> bool:
    key = request.client.host if request.client else "unknown"
    window = _hits[key]
    now = time.monotonic()
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= settings.write_rate_limit_per_minute:
        return False
    window.append(now)
    return True


@app.exception_handler(MCPCallError)
async def mcp_error_handler(_: Request, exc: MCPCallError) -> JSONResponse:
    return JSONResponse({"error": exc.payload(), "mcp": [exc.trace.as_dict()] if exc.trace else []}, status_code=exc.status)


def demo_role(x_demo_role: str = Header(default="retailer")) -> str:
    role = x_demo_role.strip().lower()
    if role not in ("retailer", "distributor"):
        raise HTTPException(400, "X-Demo-Role must be retailer or distributor")
    return role


def ok(data: Any, *traces: ToolTrace) -> dict[str, Any]:
    return {"data": data, "mcp": [t.as_dict() for t in traces]}


async def tool(name: str, args: dict[str, Any], role: str, source: str = "web") -> dict[str, Any]:
    data, trace = await gateway.call(name, args, role, source)
    return ok(data, trace)


# ------------------------------------------------------------------ status


@app.get("/api/health")
async def health() -> dict[str, Any]:
    mcp_status: dict[str, Any] = {"reachable": False, "url": settings.mcp_url}
    try:
        async with httpx.AsyncClient(timeout=3) as client:
            r = await client.get(settings.mcp_url.rsplit("/mcp", 1)[0] + "/health")
            mcp_status.update(r.json())
        tools, protocol = await gateway.list_tools()
        mcp_status.update({"reachable": True, "negotiated_protocol_version": protocol, "tool_count": len(tools),
                           "client_mode": settings.mcp_client_mode})
    except (httpx.HTTPError, MCPCallError, json.JSONDecodeError) as exc:
        mcp_status["error"] = str(exc)
    return {
        "gateway": "ok",
        "mcp": mcp_status,
        "assistant_mode": "rule-based (no external LLM)",
        "alexa": {"endpoint": "/alexa", "verify_signatures": settings.alexa_verify_signatures,
                  "skill_id_configured": bool(settings.alexa_skill_id), "role": settings.alexa_role},
        "data_version": gateway.data_version,
    }


@app.get("/api/mcp/tools")
async def mcp_tools(role: str = Depends(demo_role)) -> dict[str, Any]:
    tools, protocol = await gateway.list_tools(role)
    return {"data": {"tools": tools, "protocol_version": protocol, "endpoint": settings.mcp_url,
                     "transport": "streamable-http"}, "mcp": gateway.activity()[-1:]}


@app.get("/api/mcp/activity")
async def mcp_activity(after: int = 0) -> dict[str, Any]:
    return {"data": {"events": gateway.activity(after), "data_version": gateway.data_version}}


# ------------------------------------------------------------------ reads


@app.get("/api/dashboard")
async def dashboard(role: str = Depends(demo_role)):
    return await tool("get_dashboard_summary", {}, role)


@app.get("/api/orders")
async def list_orders(role: str = Depends(demo_role), status: str | None = None, has_discrepancy: bool | None = None,
                      search: str | None = None, category: str | None = None, limit: int = Query(100, le=200)):
    return await tool("list_orders", {"status": status, "has_discrepancy": has_discrepancy, "search": search,
                                      "category": category, "limit": limit}, role)


@app.get("/api/orders/{order_id}")
async def get_order(order_id: str, role: str = Depends(demo_role)):
    return await tool("get_order_status", {"order_id": order_id}, role)


@app.get("/api/orders/{order_id}/timeline")
async def get_timeline(order_id: str, role: str = Depends(demo_role)):
    return await tool("get_order_timeline", {"order_id": order_id}, role)


@app.get("/api/discrepancies")
async def discrepancies(role: str = Depends(demo_role), status: str | None = None):
    return await tool("list_discrepancies", {"status": status}, role)


@app.get("/api/products")
async def products(role: str = Depends(demo_role), q: str = "", category: str | None = None):
    return await tool("search_products", {"query": q, "category": category, "limit": 50}, role)


# ------------------------------------------------------------------ writes


class LineIn(BaseModel):
    sku: str
    quantity: float
    unit: str


class CreateOrderIn(BaseModel):
    lines: list[LineIn] = Field(min_length=1, max_length=25)
    requested_delivery_date: str | None = None
    notes: str | None = Field(default=None, max_length=1000)
    submit: bool = False


@app.post("/api/orders/validate")
async def validate(body: CreateOrderIn, role: str = Depends(demo_role)):
    return await tool("validate_order", {"lines": [ln.model_dump() for ln in body.lines]}, role)


@app.post("/api/orders")
async def create_order(body: CreateOrderIn, role: str = Depends(demo_role)):
    async with gateway.session(role, "web") as s:
        created, t1 = await s.call("create_draft_order", {
            "lines": [ln.model_dump() for ln in body.lines],
            "requested_delivery_date": body.requested_delivery_date, "notes": body.notes})
        if not body.submit:
            return ok(created, t1)
        submitted, t2 = await s.call("submit_order", {"order_id": created["order"]["id"]})
        return ok(submitted, t1, t2)


@app.post("/api/orders/{order_id}/submit")
async def submit(order_id: str, role: str = Depends(demo_role)):
    return await tool("submit_order", {"order_id": order_id}, role)


class ConfirmIn(BaseModel):
    lines: list[dict[str, Any]] | None = None
    revised_delivery_date: str | None = None
    notes: str | None = Field(default=None, max_length=1000)


@app.post("/api/orders/{order_id}/confirm")
async def confirm(order_id: str, body: ConfirmIn, role: str = Depends(demo_role)):
    return await tool("confirm_order", {"order_id": order_id, **body.model_dump()}, role)


class DispatchIn(BaseModel):
    challan_ref: str = Field(max_length=60)
    lines: list[dict[str, Any]] | None = None
    dispatched_at: str | None = None
    expected_delivery_date: str | None = None
    eway_bill_ref: str | None = None
    vehicle_ref: str | None = None
    driver_note: str | None = None
    notes: str | None = None


@app.post("/api/orders/{order_id}/dispatch")
async def dispatch(order_id: str, body: DispatchIn, role: str = Depends(demo_role)):
    return await tool("record_dispatch", {"order_id": order_id, **body.model_dump()}, role)


class ReceiptIn(BaseModel):
    lines: list[dict[str, Any]] = Field(min_length=1)
    received_at: str | None = None
    condition_notes: str | None = Field(default=None, max_length=1000)
    evidence_file: str | None = Field(default=None, pattern=r"^[a-f0-9]{32}\.(jpg|png|webp)$")


@app.post("/api/orders/{order_id}/receipt")
async def receipt(order_id: str, body: ReceiptIn, role: str = Depends(demo_role)):
    return await tool("record_delivery", {"order_id": order_id, **body.model_dump()}, role)


class ReportIn(BaseModel):
    line_id: int
    kind: Literal["short", "excess", "damaged", "other"]
    quantity: float
    description: str = Field(max_length=600)


@app.post("/api/orders/{order_id}/discrepancies")
async def report(order_id: str, body: ReportIn, role: str = Depends(demo_role)):
    return await tool("report_discrepancy", {"order_id": order_id, **body.model_dump()}, role)


class NoteIn(BaseModel):
    note: str = Field(max_length=600)
    acknowledge: bool = False


@app.post("/api/discrepancies/{discrepancy_id}/notes")
async def note(discrepancy_id: str, body: NoteIn, role: str = Depends(demo_role)):
    return await tool("add_discrepancy_note", {"discrepancy_id": discrepancy_id, **body.model_dump()}, role)


class ResolveIn(BaseModel):
    resolution_type: Literal["supply_remaining", "credit_note", "under_review", "no_adjustment", "other"]
    notes: str = Field(max_length=800)
    follow_up_qty: float | None = None


@app.post("/api/discrepancies/{discrepancy_id}/resolve")
async def resolve(discrepancy_id: str, body: ResolveIn, role: str = Depends(demo_role)):
    return await tool("resolve_discrepancy", {"discrepancy_id": discrepancy_id, **body.model_dump()}, role)


# ------------------------------------------------------------------ evidence uploads


@app.post("/api/uploads")
async def upload(file: UploadFile = File(...)) -> dict[str, Any]:
    data = await file.read(5 * 1024 * 1024 + 1)
    if len(data) > 5 * 1024 * 1024:
        raise HTTPException(413, "Evidence photos must be 5 MB or smaller.")
    ext = next((e for sig, e in IMAGE_SIGNATURES.items() if data.startswith(sig)), None)
    if ext == "webp" and data[8:12] != b"WEBP":
        ext = None
    if ext is None:
        raise HTTPException(415, "Only JPEG, PNG or WebP images are accepted.")
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    name = f"{secrets.token_hex(16)}.{ext}"
    (settings.upload_dir / name).write_bytes(data)
    return {"data": {"file": name, "url": f"/api/uploads/{name}"}}


@app.get("/api/uploads/{name}")
async def get_upload(name: str):
    if not name or "/" in name or "\\" in name or not (settings.upload_dir / name).is_file():
        raise HTTPException(404, "Not found")
    return FileResponse(settings.upload_dir / name)


# ------------------------------------------------------------------ assistant


class AssistantIn(BaseModel):
    message: str = Field(default="", max_length=500)
    lang: Literal["en", "hi"] = "en"
    source: Literal["assistant", "voice"] = "assistant"
    context_order_id: str | None = None
    selection: dict[str, Any] | None = None


@app.post("/api/assistant")
async def assistant(body: AssistantIn, role: str = Depends(demo_role)) -> dict[str, Any]:
    reply = await engine.handle_message(body.message, role=role, ui_lang=body.lang, source=body.source,
                                        context_order_id=body.context_order_id, selection=body.selection)
    return {"data": reply.as_dict("rule-based")}


class ConfirmActionIn(BaseModel):
    action: dict[str, Any]
    lang: Literal["en", "hi"] = "en"
    source: Literal["assistant", "voice"] = "assistant"


@app.post("/api/assistant/confirm")
async def assistant_confirm(body: ConfirmActionIn, role: str = Depends(demo_role)) -> dict[str, Any]:
    reply = await engine.confirm(body.action, role=role, lang=body.lang, source=body.source)
    return {"data": reply.as_dict("rule-based")}


class TimelineIn(BaseModel):
    order_id: str
    lang: Literal["en", "hi"] = "en"
    source: Literal["assistant", "voice"] = "assistant"


@app.post("/api/assistant/timeline")
async def assistant_timeline(body: TimelineIn, role: str = Depends(demo_role)) -> dict[str, Any]:
    reply = await engine.timeline(body.order_id, role=role, lang=body.lang, source=body.source)
    return {"data": reply.as_dict("rule-based")}


# ------------------------------------------------------------------ Alexa custom skill endpoint


@app.get("/alexa/health")
async def alexa_health() -> dict[str, str]:
    return {"status": "ok", "endpoint": "POST /alexa"}


@app.post("/alexa")
async def alexa_endpoint(request: Request) -> JSONResponse:
    body = await request.body()
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        return JSONResponse({"error": "invalid JSON"}, status_code=400)
    if settings.alexa_verify_signatures:
        try:
            await verify_request(dict(request.headers), body, payload, settings.alexa_skill_id)
        except (AlexaVerificationError, httpx.HTTPError) as exc:
            log.warning("Rejected Alexa request: %s", exc)
            return JSONResponse({"error": "request verification failed"}, status_code=400)
    try:
        return JSONResponse(await alexa.handle(payload))
    except Exception:  # never return a 500 to Alexa: speak a graceful message instead
        log.exception("Alexa handler failed")
        lang = "hi" if str(payload.get("request", {}).get("locale", "")).startswith("hi") else "en"
        msg = ("Sorry, something went wrong while reading the order records." if lang == "en"
               else "माफ़ कीजिए, ऑर्डर रिकॉर्ड पढ़ते समय कुछ गड़बड़ हो गई।")
        return JSONResponse(build_response(msg, lang, end=True))


# ------------------------------------------------------------------ demo administration


class ResetIn(BaseModel):
    mode: Literal["full", "live"] = "full"


@app.post("/api/demo/reset")
async def demo_reset(body: ResetIn) -> dict[str, Any]:
    """Admin-only demo operation (not an MCP tool): restore the synthetic dataset."""
    conn = connect()
    try:
        seed_database(conn, body.mode)
    finally:
        conn.close()
    gateway.data_version += 1
    message = ("Demo data restored: DS-1042 has the 48-bag receipt and an open 2-bag discrepancy."
               if body.mode == "full" else "Demo data restored for live recording: DS-1042 is in transit, ready to record receipt.")
    return {"data": {"mode": body.mode, "message": message, "data_version": gateway.data_version}}


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    ensure_database()
    uvicorn.run(app, host=settings.gateway_host, port=settings.gateway_port, log_level="info")


if __name__ == "__main__":
    main()
