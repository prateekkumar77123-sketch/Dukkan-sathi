"""Test fixtures. A temporary database and a real MCP server (Streamable HTTP on a free port) per session."""

from __future__ import annotations

import os
import socket
import tempfile
import threading
import time
from pathlib import Path

_tmp = Path(tempfile.mkdtemp(prefix="dukaan-tests-"))
os.environ["DUKAAN_DB_PATH"] = str(_tmp / "test.db")
os.environ["UPLOAD_DIR"] = str(_tmp / "uploads")


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


MCP_PORT = _free_port()
os.environ["MCP_PORT"] = str(MCP_PORT)
os.environ["MCP_URL"] = f"http://127.0.0.1:{MCP_PORT}/mcp"
os.environ["ALEXA_VERIFY_SIGNATURES"] = "false"

import pytest  # noqa: E402
import uvicorn  # noqa: E402

from app.db import connect  # noqa: E402
from app.domain.actors import actor_for_role  # noqa: E402
from app.seed import seed_database  # noqa: E402


@pytest.fixture()
def conn():
    c = connect()
    seed_database(c, "full")
    yield c
    c.close()


@pytest.fixture()
def live_conn():
    c = connect()
    seed_database(c, "live")
    yield c
    c.close()


@pytest.fixture()
def retailer():
    return actor_for_role("retailer", "web")


@pytest.fixture()
def distributor():
    return actor_for_role("distributor", "web")


@pytest.fixture(scope="session")
def mcp_server():
    """Run the real MCP server app (Streamable HTTP + bearer auth) in a background thread."""
    from app.mcp_server.server import build_app

    c = connect()
    seed_database(c, "full")
    c.close()
    config = uvicorn.Config(build_app(), host="127.0.0.1", port=MCP_PORT, log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    assert server.started, "MCP server failed to start"
    yield f"http://127.0.0.1:{MCP_PORT}/mcp"
    server.should_exit = True
    thread.join(timeout=5)


@pytest.fixture()
def fresh_data(mcp_server):
    c = connect()
    seed_database(c, "full")
    c.close()
    return mcp_server
