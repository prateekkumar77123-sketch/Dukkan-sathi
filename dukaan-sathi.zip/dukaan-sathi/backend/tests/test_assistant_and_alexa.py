"""Bilingual intent parsing, Alexa request verification helpers, and the Alexa handler end to end."""

from __future__ import annotations

import asyncio
import base64
from datetime import UTC, datetime, timedelta

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.x509.oid import NameOID

from app.gateway.alexa.handler import AlexaHandler, to_ssml
from app.gateway.alexa.verifier import (
    AlexaVerificationError,
    check_application_id,
    validate_cert_url,
    validate_timestamp,
    verify_signature,
)
from app.gateway.assistant.engine import AssistantEngine
from app.gateway.assistant.nlu import parse
from app.gateway.mcp_client import MCPGateway


@pytest.mark.parametrize("text,intent,extra", [
    ("Where is order DS-1042?", "order_status", {"order_id": "DS-1042"}),
    ("Dukaan Sathi, check my cement delivery.", "check_delivery", {"category": "Cement"}),
    ("Which of my orders have a quantity mismatch?", "attention", {}),
    ("Show my orders that have been dispatched but not received.", "in_transit", {}),
    ("Create a draft order for 30 bags of PPC cement.", "create_order", {"quantity": 30, "draft_only": True}),
    ("I need 200 pieces of 8 mm TMT bar, grade 500D", "create_order", {"quantity": 200, "unit": "pieces"}),
    ("ऑर्डर DS-1042 कहाँ है?", "order_status", {"order_id": "DS-1042", "lang": "hi"}),
    ("मेरी सीमेंट डिलीवरी चेक करो", "check_delivery", {"lang": "hi", "category": "Cement"}),
    ("OPC 53 सीमेंट की पचास बोरी ऑर्डर कर दो", "create_order", {"quantity": 50, "lang": "hi"}),
    ("किन ऑर्डर में कमी है?", "attention", {"lang": "hi"}),
    ("मेरी दुकान का हिसाब बताओ", "dashboard", {"lang": "hi"}),
    ("mera order 1042 kahan hai", "order_status", {"order_id": "DS-1042", "lang": "hi"}),
    ("डीएस 1042 की टाइमलाइन दिखाओ", "order_history", {"order_id": "DS-1042"}),
])
def test_bilingual_intent_parsing(text, intent, extra):
    parsed = parse(text)
    assert parsed.name == intent
    for key, value in extra.items():
        assert getattr(parsed, key) == value, key


def test_alexa_cert_url_rules():
    validate_cert_url("https://s3.amazonaws.com/echo.api/echo-api-cert.pem")
    validate_cert_url("https://s3.amazonaws.com:443/echo.api/../echo.api/echo-api-cert.pem")
    for bad in ("http://s3.amazonaws.com/echo.api/echo-api-cert.pem",
                "https://notamazon.com/echo.api/echo-api-cert.pem",
                "https://s3.amazonaws.com/EcHo.aPi/echo-api-cert.pem",
                "https://s3.amazonaws.com/invalid.path/echo-api-cert.pem",
                "https://s3.amazonaws.com:563/echo.api/echo-api-cert.pem",
                "https://s3.amazonaws.com/echo.api/../invalid/echo-api-cert.pem"):
        with pytest.raises(AlexaVerificationError):
            validate_cert_url(bad)


def test_alexa_timestamp_and_application_id():
    now = datetime(2026, 10, 23, 12, 0, tzinfo=UTC)
    validate_timestamp("2026-10-23T11:58:00Z", now)
    with pytest.raises(AlexaVerificationError):
        validate_timestamp("2026-10-23T11:57:00Z", now)
    check_application_id({"session": {"application": {"applicationId": "amzn1.ask.skill.x"}}}, "amzn1.ask.skill.x")
    with pytest.raises(AlexaVerificationError):
        check_application_id({"session": {"application": {"applicationId": "other"}}}, "amzn1.ask.skill.x")


def test_alexa_signature_check_uses_sha256_over_raw_body():
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "echo-api.amazon.com")])
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(1).not_valid_before(datetime.now(UTC) - timedelta(days=1))
            .not_valid_after(datetime.now(UTC) + timedelta(days=1)).sign(key, hashes.SHA256()))
    body = b'{"request":{"type":"LaunchRequest"}}'
    sig = base64.b64encode(key.sign(body, padding.PKCS1v15(), hashes.SHA256())).decode()
    verify_signature(cert, sig, body)
    with pytest.raises(AlexaVerificationError):
        verify_signature(cert, sig, body + b" ")


def test_ssml_makes_ids_speakable_and_escapes():
    ssml = to_ssml("Order DS-1042 & DSC-2004 < 50 bags ₹390", "en")
    assert 'D S <say-as interpret-as="digits">1042</say-as>' in ssml
    assert "&amp;" in ssml and "&lt;" in ssml and "rupees" in ssml
    assert ssml.startswith("<speak>") and ssml.endswith("</speak>")


def _alexa_request(intent=None, slots=None, locale="en-IN", attrs=None, rtype="IntentRequest"):
    req = {"type": rtype, "locale": locale, "timestamp": datetime.now(UTC).isoformat(), "requestId": "test"}
    if intent:
        req["intent"] = {"name": intent, "slots": {k: {"name": k, "value": v} for k, v in (slots or {}).items()}}
    return {"version": "1.0", "session": {"new": False, "attributes": attrs or {}}, "request": req}


def test_alexa_handler_answers_from_mcp_in_english_and_hindi(fresh_data):
    handler = AlexaHandler(AssistantEngine(MCPGateway(url=fresh_data)))

    async def run():
        out = await handler.handle(_alexa_request("CheckDeliveryIntent", {"product": "cement"}))
        speech = out["response"]["outputSpeech"]["ssml"]
        assert "48 bags received" in speech and "2 bags short" in speech
        assert out["sessionAttributes"]["context_order_id"] == "DS-1042"
        out = await handler.handle(_alexa_request("OrderStatusIntent", {"orderNumber": "1042"}, locale="hi-IN"))
        assert "2 बोरी कम" in out["response"]["outputSpeech"]["ssml"]
        out = await handler.handle(_alexa_request("CreateOrderIntent", {"quantity": "30", "unit": "bags", "product": "ppc cement"}))
        assert out["sessionAttributes"]["pending_action"]["lines"][0]["sku"] == "CEM-PPC-50"
        confirmed = await handler.handle(_alexa_request("AMAZON.YesIntent", attrs=out["sessionAttributes"]))
        assert "sent to Sharma Building Supplies" in confirmed["response"]["outputSpeech"]["ssml"]
        bye = await handler.handle(_alexa_request("AMAZON.StopIntent"))
        assert bye["response"]["shouldEndSession"] is True
    asyncio.run(run())
