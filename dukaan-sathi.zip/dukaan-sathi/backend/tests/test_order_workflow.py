"""Business-rule and lifecycle tests (service layer, real SQLite)."""

from __future__ import annotations

import pytest

from app.domain.errors import InvalidTransition, NotFoundError, PermissionDenied, ValidationFailed
from app.domain.models import ConfirmLineInput, DispatchLineInput, LineInput, ReceiptLineInput
from app.domain.rules import compare_line
from app.services import catalog, dashboard, orders


def _new_in_transit_order(conn, retailer, distributor, qty=50, sku="CEM-OPC53-50", unit="bag"):
    draft = orders.create_draft_order(conn, retailer, lines=[LineInput(sku=sku, quantity=qty, unit=unit)])
    oid = draft.order.id
    orders.submit_order(conn, retailer, order_id=oid)
    orders.confirm_order(conn, distributor, order_id=oid)
    orders.record_dispatch(conn, distributor, order_id=oid, challan_ref="TEST/DC/0001")
    return orders.get_order(conn, retailer, oid)


# 1
def test_product_lookup_returns_catalogue_records(conn):
    result = catalog.search_products(conn, "OPC 53 cement")
    assert result.count == 1
    product = result.products[0]
    assert product.sku == "CEM-OPC53-50"
    assert product.unit == "bag" and product.grade == "OPC 53" and product.standard == "IS 269:2015"
    hindi = catalog.search_products(conn, "8 मिमी सरिया")
    assert [p.sku for p in hindi.products] == ["TMT-500D-08"]
    ambiguous = catalog.search_products(conn, "cement")
    assert ambiguous.needs_clarification and ambiguous.count == 3


# 2
def test_valid_draft_is_created_and_persists(conn, retailer):
    result = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="CEM-PPC-50", quantity=30, unit="bags")])
    assert result.order.status == "draft"
    row = conn.execute("SELECT * FROM order_lines WHERE order_id = ?", (result.order.id,)).fetchone()
    assert row["product_id"] == "CEM-PPC-50" and row["requested_qty"] == 30 and row["unit"] == "bag"
    events = orders.get_timeline(conn, retailer, result.order.id).events
    assert [e.event_type for e in events] == ["draft_created"]


# 3
def test_invalid_product_specification_is_rejected(conn, retailer):
    with pytest.raises(ValidationFailed) as exc:
        orders.create_draft_order(conn, retailer, lines=[LineInput(sku="TMT-500D-09", quantity=10, unit="piece")])
    assert "TMT-500D-09" in exc.value.message
    assert conn.execute("SELECT COUNT(*) FROM orders WHERE status = 'draft'").fetchone()[0] == 0


# 4
def test_incompatible_units_are_not_silently_accepted(conn, retailer):
    with pytest.raises(ValidationFailed) as exc:
        orders.create_draft_order(conn, retailer, lines=[LineInput(sku="CEM-OPC53-50", quantity=50, unit="kg")])
    assert "not kg" in exc.value.message
    with pytest.raises(ValidationFailed):  # tonnes is not a supported unit at all
        orders.create_draft_order(conn, retailer, lines=[LineInput(sku="CEM-OPC53-50", quantity=2, unit="tonnes")])
    with pytest.raises(ValidationFailed):  # half a bag is malformed
        orders.create_draft_order(conn, retailer, lines=[LineInput(sku="CEM-OPC53-50", quantity=2.5, unit="bag")])
    # explicit conversion factor: 300 pieces of screws = 3 packs of 100
    ok = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="SCR-WOOD-8x1-PK100", quantity=300, unit="pieces")])
    assert ok.order.lines[0].requested_qty == 3 and ok.order.lines[0].unit == "pack"
    with pytest.raises(ValidationFailed):  # 250 pieces is not a whole number of packs
        orders.create_draft_order(conn, retailer, lines=[LineInput(sku="SCR-WOOD-8x1-PK100", quantity=250, unit="pieces")])


# 5
def test_distributor_confirmation_updates_record_and_timeline(conn, retailer, distributor):
    draft = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="SCR-WOOD-8x1-PK100", quantity=12, unit="pack")])
    oid = draft.order.id
    orders.submit_order(conn, retailer, order_id=oid)
    line_id = draft.order.lines[0].line_id
    with pytest.raises(ValidationFailed):  # only 10 packs in stock
        orders.confirm_order(conn, distributor, order_id=oid)
    result = orders.confirm_order(conn, distributor, order_id=oid, lines=[ConfirmLineInput(line_id=line_id, confirmed_qty=10)],
                                  notes="Balance 2 packs next week")
    assert result.order.status == "confirmed" and result.order.partially_confirmed
    assert result.order.lines[0].confirmed_qty == 10 and result.order.lines[0].requested_qty == 12
    seen_by_retailer = orders.get_order(conn, retailer, oid)
    assert seen_by_retailer.status == "confirmed"
    assert orders.get_timeline(conn, retailer, oid).events[-1].event_type == "order_confirmed"


# 6
def test_dispatch_quantities_are_persisted(conn, retailer, distributor):
    draft = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="TMT-500D-12", quantity=40, unit="piece")])
    oid = draft.order.id
    orders.submit_order(conn, retailer, order_id=oid)
    orders.confirm_order(conn, distributor, order_id=oid)
    line_id = draft.order.lines[0].line_id
    stock_before = conn.execute("SELECT available_qty FROM distributor_stock WHERE product_id = 'TMT-500D-12'").fetchone()[0]
    result = orders.record_dispatch(conn, distributor, order_id=oid, challan_ref="SBS/DC/TEST/1",
                                    lines=[DispatchLineInput(line_id=line_id, dispatched_qty=38)], expected_delivery_date="2026-12-01")
    assert result.order.status == "in_transit"
    row = conn.execute("SELECT dispatched_qty FROM order_lines WHERE id = ?", (line_id,)).fetchone()
    assert row["dispatched_qty"] == 38
    assert result.order.dispatch.challan_ref == "SBS/DC/TEST/1"
    stock_after = conn.execute("SELECT available_qty FROM distributor_stock WHERE product_id = 'TMT-500D-12'").fetchone()[0]
    assert stock_before - stock_after == 38
    with pytest.raises(ValidationFailed):  # cannot dispatch more than confirmed
        draft2 = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="TMT-500D-12", quantity=5, unit="piece")])
        orders.submit_order(conn, retailer, order_id=draft2.order.id)
        orders.confirm_order(conn, distributor, order_id=draft2.order.id)
        orders.record_dispatch(conn, distributor, order_id=draft2.order.id, challan_ref="X",
                               lines=[DispatchLineInput(line_id=draft2.order.lines[0].line_id, dispatched_qty=6)])


# 7
def test_receipt_quantities_are_persisted(conn, retailer, distributor):
    order = _new_in_transit_order(conn, retailer, distributor, qty=20, sku="PUTTY-40")
    lid = order.lines[0].line_id
    orders.record_delivery(conn, retailer, order_id=order.id, lines=[ReceiptLineInput(line_id=lid, received_qty=20, damaged_qty=1)],
                           condition_notes="One bag torn")
    row = conn.execute("SELECT received_qty, damaged_qty FROM order_lines WHERE id = ?", (lid,)).fetchone()
    assert (row["received_qty"], row["damaged_qty"]) == (20, 1)
    receipt = conn.execute("SELECT * FROM receipts WHERE order_id = ?", (order.id,)).fetchone()
    assert receipt["condition_notes"] == "One bag torn"


# 8
def test_50_dispatched_48_received_produces_two_bag_discrepancy(live_conn, retailer):
    order = orders.get_order(live_conn, retailer, "DS-1042")
    assert order.status == "in_transit"
    assert (order.lines[0].confirmed_qty, order.lines[0].dispatched_qty) == (50, 50)
    result = orders.record_delivery(live_conn, retailer, order_id="DS-1042",
                                    lines=[ReceiptLineInput(line_id=order.lines[0].line_id, received_qty=48)])
    assert result.order.status == "needs_review"
    assert len(result.discrepancies_created) == 1
    disc = result.order.discrepancies[0]
    assert disc.kind == "short" and disc.difference_qty == 2 and disc.unit == "bag"
    assert disc.expected_qty == 50 and disc.observed_qty == 48
    assert disc.order_id == "DS-1042" and disc.line_id == order.lines[0].line_id
    assert "2 bags below the recorded dispatched quantity" in disc.description
    assert result.order.lines[0].comparison.receipt_variance == -2


# 9
def test_equal_quantities_do_not_produce_a_shortage(conn, retailer, distributor):
    order = _new_in_transit_order(conn, retailer, distributor, qty=50)
    result = orders.record_delivery(conn, retailer, order_id=order.id,
                                    lines=[ReceiptLineInput(line_id=order.lines[0].line_id, received_qty=50)])
    assert result.order.status == "delivered"
    assert result.discrepancies_created == [] and result.order.discrepancies == []
    assert result.order.lines[0].comparison.outcome == "match"


def test_excess_delivery_is_detected(conn, retailer, distributor):
    order = _new_in_transit_order(conn, retailer, distributor, qty=10, sku="PVC-PIPE-2IN", unit="length")
    result = orders.record_delivery(conn, retailer, order_id=order.id,
                                    lines=[ReceiptLineInput(line_id=order.lines[0].line_id, received_qty=12)])
    assert result.order.discrepancies[0].kind == "excess" and result.order.discrepancies[0].difference_qty == 2


def test_comparison_without_receipt_is_not_final():
    cmp = compare_line(confirmed=50, dispatched=50, received=None, damaged=None, unit="bag")
    assert cmp.outcome == "awaiting_receipt" and not cmp.comparable


# 10
def test_shortage_is_not_attributed_to_anyone(live_conn, retailer):
    order = orders.get_order(live_conn, retailer, "DS-1042")
    result = orders.record_delivery(live_conn, retailer, order_id="DS-1042",
                                    lines=[ReceiptLineInput(line_id=order.lines[0].line_id, received_qty=48)])
    disc = result.order.discrepancies[0]
    assert disc.attributed_to is None
    text = (disc.description + " " + result.message).lower()
    for blame in ("driver", "distributor's fault", "stole", "theft", "lost by", "fault", "blame"):
        assert blame not in text
    assert "cause not yet determined" in text
    flagged = [e for e in orders.get_timeline(live_conn, retailer, "DS-1042").events if e.event_type == "discrepancy_flagged"][0]
    assert flagged.actor_role == "system"


# 11
def test_resolution_preserves_original_history(conn, retailer, distributor):
    before = orders.get_order(conn, retailer, "DS-1042")
    events_before = orders.get_timeline(conn, retailer, "DS-1042").events
    result = orders.resolve_discrepancy(conn, distributor, discrepancy_id="DSC-2004", resolution_type="supply_remaining",
                                        notes="Remaining 2 bags to be supplied with the next dispatch.")
    after = result.order
    assert after.status == "resolved"
    ln_b, ln_a = before.lines[0], after.lines[0]
    assert (ln_a.requested_qty, ln_a.confirmed_qty, ln_a.dispatched_qty, ln_a.received_qty) == \
           (ln_b.requested_qty, ln_b.confirmed_qty, ln_b.dispatched_qty, ln_b.received_qty) == (50, 50, 50, 48)
    disc = after.discrepancies[0]
    assert disc.status == "resolved" and disc.difference_qty == 2 and disc.expected_qty == 50 and disc.observed_qty == 48
    assert disc.resolutions[0].follow_up_qty == 2 and disc.resolutions[0].decided_by_role == "distributor"
    events_after = orders.get_timeline(conn, retailer, "DS-1042").events
    assert [e.id for e in events_after[: len(events_before)]] == [e.id for e in events_before]
    assert events_after[-1].event_type == "order_resolved"
    with pytest.raises(InvalidTransition):
        orders.resolve_discrepancy(conn, retailer, discrepancy_id="DSC-2004", resolution_type="other", notes="again")


def test_under_review_keeps_discrepancy_open(conn, retailer):
    result = orders.resolve_discrepancy(conn, retailer, discrepancy_id="DSC-2004", resolution_type="under_review",
                                        notes="Waiting for the loading register copy.")
    assert result.order.status == "needs_review"
    assert result.order.discrepancies[0].status == "under_review"


# 12
def test_invalid_state_changes_are_rejected(conn, retailer, distributor):
    with pytest.raises(InvalidTransition):  # DS-1042 is already received
        orders.record_dispatch(conn, distributor, order_id="DS-1042", challan_ref="X")
    with pytest.raises(InvalidTransition):  # cannot confirm an order that is in transit
        orders.confirm_order(conn, distributor, order_id="DS-1038")
    with pytest.raises(InvalidTransition):  # cannot receive twice
        orders.record_delivery(conn, retailer, order_id="DS-1042", lines=[ReceiptLineInput(line_id=1, received_qty=1)])
    with pytest.raises(PermissionDenied):  # retailers cannot record dispatch
        orders.record_dispatch(conn, retailer, order_id="DS-1038", challan_ref="X")
    with pytest.raises(PermissionDenied):  # distributors cannot record receipt
        orders.record_delivery(conn, distributor, order_id="DS-1038", lines=[])
    with pytest.raises(NotFoundError):
        orders.get_order(conn, retailer, "DS-9999")
    draft = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="CEM-PPC-50", quantity=5, unit="bag")])
    with pytest.raises(NotFoundError):  # distributors cannot see unsent drafts
        orders.get_order(conn, distributor, draft.order.id)
    with pytest.raises(ValidationFailed):
        orders.record_delivery(conn, retailer, order_id="DS-1038",
                               lines=[ReceiptLineInput(line_id=orders.get_order(conn, retailer, "DS-1038").lines[0].line_id,
                                                       received_qty=-3)])


# 13
def test_dashboard_statistics_reflect_database(conn, retailer, distributor):
    s = dashboard.get_dashboard_summary(conn, retailer)
    assert (s.total_orders, s.in_transit, s.needs_review, s.delivered) == (12, 4, 2, 6)
    assert s.is_sample_data
    orders.resolve_discrepancy(conn, retailer, discrepancy_id="DSC-2004", resolution_type="credit_note", notes="Credit agreed")
    s2 = dashboard.get_dashboard_summary(conn, retailer)
    assert (s2.needs_review, s2.delivered, s2.resolved) == (1, 7, 3)
    draft = orders.create_draft_order(conn, retailer, lines=[LineInput(sku="CEM-PPC-50", quantity=5, unit="bag")])
    assert dashboard.get_dashboard_summary(conn, retailer).drafts == 1
    orders.submit_order(conn, retailer, order_id=draft.order.id)
    s3 = dashboard.get_dashboard_summary(conn, distributor)
    assert s3.total_orders == 13 and s3.pending_confirmation == 1
