"""MCP server over real Streamable HTTP, the gateway's MCP client, and the website API."""

from __future__ import annotations

import asyncio

import httpx
import pytest
from mcp import Client
from mcp.client.streamable_http import streamable_http_client
from mcp.shared._httpx_utils import create_mcp_http_client

from app.config import DEFAULT_DISTRIBUTOR_TOKEN, DEFAULT_RETAILER_TOKEN
from app.db import connect
from app.gateway.mcp_client import MCPCallError, MCPGateway

EXPECTED_TOOLS = {
    "search_products", "create_draft_order", "validate_order", "submit_order", "confirm_order", "list_orders",
    "get_order_status", "get_order_timeline", "list_discrepancies", "get_dashboard_summary", "record_dispatch",
    "record_delivery", "report_discrepancy", "add_discrepancy_note", "resolve_discrepancy",
}


async def _independent_client(url: str, token: str, mode: str = "legacy"):
    http = create_mcp_http_client(headers={"Authorization": f"Bearer {token}"})
    return http, Client(streamable_http_client(url, http_client=http), mode=mode)


# 14
def test_tool_discovery_with_independent_mcp_client(fresh_data):
    async def run():
        http, client = await _independent_client(fresh_data, DEFAULT_RETAILER_TOKEN)
        async with http, client:
            assert client.protocol_version == "2025-11-25"
            tools = (await client.list_tools()).tools
            names = {t.name for t in tools}
            assert EXPECTED_TOOLS <= names
            status_tool = next(t for t in tools if t.name == "get_order_status")
            assert status_tool.output_schema is not None and status_tool.annotations.read_only_hint
            assert "order_id" in status_tool.input_schema["properties"]
        http2, modern = await _independent_client(fresh_data, DEFAULT_RETAILER_TOKEN, mode="auto")
        async with http2, modern:
            assert modern.protocol_version >= "2025-11-25"
    asyncio.run(run())


def test_mcp_endpoint_requires_bearer_token(fresh_data):
    r = httpx.post(fresh_data, json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
    assert r.status_code == 401
    assert "Bearer" in r.headers.get("www-authenticate", "")


# 15
def test_mcp_tool_invocations_return_real_data(fresh_data):
    async def run():
        http, client = await _independent_client(fresh_data, DEFAULT_RETAILER_TOKEN)
        async with http, client:
            result = await client.call_tool("get_order_status", {"order_id": "DS-1042"})
            assert not result.is_error
            order = result.structured_content
            assert order["id"] == "DS-1042" and order["status"] == "needs_review"
            ln = order["lines"][0]
            assert (ln["confirmed_qty"], ln["dispatched_qty"], ln["received_qty"]) == (50, 50, 48)
            summary = (await client.call_tool("get_dashboard_summary", {})).structured_content
            assert (summary["total_orders"], summary["in_transit"], summary["needs_review"], summary["delivered"]) == (12, 4, 2, 6)
            # a write through MCP lands in the shared database
            note = await client.call_tool("add_discrepancy_note", {"discrepancy_id": "DSC-2004", "note": "Counted again: 48."})
            assert not note.is_error
        c = connect()
        row = c.execute("SELECT * FROM discrepancy_notes WHERE note = 'Counted again: 48.'").fetchone()
        c.close()
        assert row is not None and row["author_role"] == "retailer" and row["source"] == "mcp"
    asyncio.run(run())


def test_mcp_enforces_roles_in_the_service_layer(fresh_data):
    async def run():
        http, client = await _independent_client(fresh_data, DEFAULT_RETAILER_TOKEN)
        async with http, client:
            denied = await client.call_tool("record_dispatch", {"order_id": "DS-1038", "challan_ref": "X"})
            assert denied.is_error and "permission_denied" in denied.content[0].text
        http2, dist = await _independent_client(fresh_data, DEFAULT_DISTRIBUTOR_TOKEN)
        async with http2, dist:
            bad_unit = await dist.call_tool("validate_order", {"lines": [{"sku": "CEM-OPC53-50", "quantity": 50, "unit": "kg"}]})
            assert not bad_unit.is_error and bad_unit.structured_content["valid"] is False
    asyncio.run(run())


# 16
def test_website_api_invokes_tools_through_mcp_over_streamable_http(fresh_data):
    from app.gateway.main import app

    async def run():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as api:
            r = await api.get("/api/orders/DS-1042", headers={"X-Demo-Role": "retailer"})
            assert r.status_code == 200
            body = r.json()
            assert body["data"]["id"] == "DS-1042"
            trace = body["mcp"][0]
            assert trace["tool"] == "get_order_status" and trace["ok"] is True
            assert trace["transport"] == "streamable-http" and trace["protocol_version"] == "2025-11-25"
            assert trace["endpoint"] == fresh_data

            r = await api.post("/api/assistant", headers={"X-Demo-Role": "retailer"},
                               json={"message": "मेरी सीमेंट डिलीवरी चेक करो", "lang": "hi"})
            reply = r.json()["data"]
            assert reply["lang"] == "hi" and "DS-1042" in reply["reply"]
            assert [t["tool"] for t in reply["mcp"]] == ["list_orders", "get_order_status"]

            r = await api.post("/api/discrepancies/DSC-2004/resolve", headers={"X-Demo-Role": "distributor"},
                               json={"resolution_type": "supply_remaining", "notes": "2 bags with next dispatch"})
            assert r.status_code == 200 and r.json()["data"]["order"]["status"] == "resolved"
            assert r.json()["mcp"][0]["tool"] == "resolve_discrepancy" and r.json()["mcp"][0]["is_write"]
        c = connect()
        ev = c.execute("SELECT * FROM audit_events WHERE order_id = 'DS-1042' AND event_type = 'resolution_recorded'").fetchone()
        c.close()
        assert ev["source"] == "web" and ev["actor_role"] == "distributor"  # written by the MCP server, tagged by the gateway
    asyncio.run(run())


# 17
def test_mcp_errors_are_handled_gracefully(fresh_data):
    from app.gateway.main import app
    from app.gateway.mcp_client import gateway

    async def run():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://localhost") as api:
            r = await api.get("/api/orders/DS-9999", headers={"X-Demo-Role": "retailer"})
            assert r.status_code == 404
            assert r.json()["error"]["code"] == "not_found" and r.json()["mcp"][0]["ok"] is False
            r = await api.post("/api/orders/DS-1038/confirm", headers={"X-Demo-Role": "distributor"}, json={})
            assert r.status_code == 409 and r.json()["error"]["code"] == "invalid_state_transition"

            original = gateway.url
            gateway.url = "http://127.0.0.1:9/mcp"  # nothing listens here
            try:
                r = await api.get("/api/dashboard", headers={"X-Demo-Role": "retailer"})
                assert r.status_code == 503 and r.json()["error"]["code"] == "mcp_unavailable"
                r = await api.post("/api/assistant", headers={"X-Demo-Role": "retailer"}, json={"message": "Where is DS-1042?"})
                reply = r.json()["data"]
                assert reply["error"]["code"] == "mcp_unavailable" and reply["suggestions"][0]["action"]["type"] == "retry"
            finally:
                gateway.url = original

            r = await api.get("/api/orders", headers={"X-Demo-Role": "retailer", "host": "abc.trycloudflare.com"})
            assert r.status_code == 403  # only /alexa is reachable through a public tunnel hostname

    asyncio.run(run())

    async def unreachable():
        with pytest.raises(MCPCallError) as exc:
            await MCPGateway(url="http://127.0.0.1:9/mcp", timeout=3).call("list_orders", {}, "retailer")
        assert exc.value.code == "mcp_unavailable" and exc.value.status == 503
    asyncio.run(unreachable())
