<#
  Stops the three Dukaan Sathi windows started by run-demo.ps1 (and their child processes).
    powershell -ExecutionPolicy Bypass -File .\stop-demo.ps1
#>
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$PidFile = Join-Path $Root ".demo-pids"
if (Test-Path $PidFile) {
  foreach ($procId in Get-Content $PidFile) {
    if ($procId) { & taskkill /PID $procId /T /F 2>$null | Out-Null }
  }
  Remove-Item $PidFile -Force
}
# Fallback: free the demo ports if something is still listening.
foreach ($port in 8001, 8000, 5173) {
  Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { & taskkill /PID $_.OwningProcess /T /F 2>$null | Out-Null }
}
Write-Host "Dukaan Sathi stopped." -ForegroundColor Green
