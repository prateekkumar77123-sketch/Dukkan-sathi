# data/

`dukaan_sathi.db` (SQLite) is created here automatically the first time the MCP server or gateway starts, and
seeded with the synthetic demo dataset. It is **not** reset on restart or page reload.

Reset explicitly:

```powershell
cd backend
.\.venv\Scripts\python.exe -m app.seed full   # full sample data (DS-1042 already shows 48 received)
.\.venv\Scripts\python.exe -m app.seed live   # DS-1042 in transit, ready to record the receipt on camera
```

or use **Demo controls** in the website. The seed code lives in `backend/app/seed.py`. Evidence photos uploaded
during the demo are stored in `data/uploads/`.
