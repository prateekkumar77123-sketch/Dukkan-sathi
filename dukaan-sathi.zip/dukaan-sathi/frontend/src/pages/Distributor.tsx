import { ArrowLeftRight, ClipboardCheck, Inbox, PackageCheck, Truck } from "lucide-react";
import { TraceStrip } from "../components/mcp";
import { OrderTable } from "../components/orders";
import { Button, Card, CardHeader, EmptyState, ErrorState, PageHeader, SampleTag, Spinner } from "../components/ui";
import { useApi, useApp } from "../lib/app";
import type { OrderListResult } from "../lib/types";

export default function Distributor() {
  const { t, role, setRole, toast } = useApp();
  const incoming = useApi<OrderListResult>(role === "distributor" ? "/api/orders?status=pending_confirmation" : null);
  const toDispatch = useApi<OrderListResult>(role === "distributor" ? "/api/orders?status=confirmed" : null);
  const transit = useApi<OrderListResult>(role === "distributor" ? "/api/orders?status=in_transit" : null);
  const review = useApi<OrderListResult>(role === "distributor" ? "/api/orders?has_discrepancy=true" : null);

  if (role !== "distributor") {
    return (
      <div>
        <PageHeader eyebrow={<SampleTag />} title={t("Distributor workspace", "डिस्ट्रीब्यूटर वर्कस्पेस")} />
        <Card>
          <EmptyState icon={<Truck className="size-6" />} title={t("This workspace is for Sharma Building Supplies", "यह वर्कस्पेस शर्मा बिल्डिंग सप्लाइज़ के लिए है")}
            body={t("Switch the demo role to see incoming requests, confirm quantities and record dispatches. The retailer will see the same updates.", "आए हुए ऑर्डर देखने, मात्रा की पुष्टि और डिस्पैच दर्ज करने के लिए डेमो भूमिका बदलें। रिटेलर को वही अपडेट दिखेंगे।")}
            action={<Button icon={<ArrowLeftRight className="size-4" />} onClick={() => { setRole("distributor"); toast(t("Switched to distributor", "डिस्ट्रीब्यूटर चुना गया"), "info"); }}>{t("Switch to distributor", "डिस्ट्रीब्यूटर बनें")}</Button>} />
        </Card>
      </div>
    );
  }

  const section = (title: string, subtitle: string, icon: React.ReactNode, q: ReturnType<typeof useApi<OrderListResult>>, empty: string) => (
    <Card>
      <CardHeader title={<span className="flex items-center gap-2">{title}{q.data && <span className="rounded-full bg-ivory-deep px-2 text-xs text-muted tabular">{q.data.count}</span>}</span>} subtitle={subtitle} icon={icon} />
      {q.loading && <Spinner />}
      {q.error && <ErrorState error={q.error} onRetry={q.reload} />}
      {q.data && <OrderTable orders={q.data.orders} empty={<p className="px-5 py-6 text-sm text-muted">{empty}</p>} />}
    </Card>
  );

  return (
    <div>
      <PageHeader eyebrow={<SampleTag />} title={t("Distributor workspace", "डिस्ट्रीब्यूटर वर्कस्पेस")}
        subtitle={t("Sharma Building Supplies — confirm requests, record what leaves the godown, and respond to delivery differences.", "शर्मा बिल्डिंग सप्लाइज़ — ऑर्डर की पुष्टि करें, गोदाम से निकला माल दर्ज करें, और डिलीवरी अंतर का जवाब दें।")} />
      <div className="grid gap-6 xl:grid-cols-2">
        {section(t("Incoming requests", "नए ऑर्डर"), t("Open an order to check specifications and confirm full or partial quantities.", "स्पेसिफिकेशन देखकर पूरी या आंशिक मात्रा की पुष्टि करें।"), <Inbox className="size-5" />, incoming, t("No requests waiting. Orders the retailer submits appear here.", "कोई ऑर्डर बाकी नहीं। रिटेलर के भेजे ऑर्डर यहाँ दिखेंगे।"))}
        {section(t("Ready to dispatch", "डिस्पैच के लिए तैयार"), t("Confirmed orders — record challan, quantities and expected delivery.", "पुष्टि हुए ऑर्डर — चालान, मात्रा और अपेक्षित डिलीवरी दर्ज करें।"), <ClipboardCheck className="size-5" />, toDispatch, t("Nothing waiting for dispatch.", "डिस्पैच के लिए कुछ बाकी नहीं।"))}
        {section(t("In transit", "रास्ते में"), t("Dispatched; waiting for the retailer to record receipt.", "भेजा जा चुका; रिटेलर की प्राप्ति का इंतज़ार।"), <Truck className="size-5" />, transit, t("No consignments on the road.", "कोई माल रास्ते में नहीं।"))}
        {section(t("Differences to respond to", "जवाब देने वाले अंतर"), t("Acknowledge, add notes and record an agreed resolution.", "स्वीकार करें, नोट जोड़ें और सहमत समाधान दर्ज करें।"), <PackageCheck className="size-5" />, review, t("No open delivery differences.", "कोई खुला अंतर नहीं।"))}
      </div>
      <TraceStrip traces={[...incoming.traces, ...toDispatch.traces, ...transit.traces, ...review.traces]} className="mt-6" />
    </div>
  );
}
