import { Bot, Loader2, MessagesSquare, RotateCcw, Send, User } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AssistantCards, ModeNote, useActionRouter, useConversation } from "../components/assistant";
import { TraceRow } from "../components/mcp";
import { Button, Card, CardHeader, cx, inputClass, Modal, PageHeader, SampleTag } from "../components/ui";
import { useApp } from "../lib/app";

export default function Assistant() {
  const { t, lang, role } = useApp();
  const conv = useConversation("assistant");
  const [text, setText] = useState("");
  const [note, setNote] = useState<{ orderId: string; discrepancyId: string } | null>(null);
  const [noteText, setNoteText] = useState("");
  const route = useActionRouter(conv, (orderId, discrepancyId) => { setNote({ orderId, discrepancyId }); setNoteText(""); });
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // block body on purpose: newer browsers return a Promise from scrollIntoView, which an effect must not return
    void endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [conv.messages.length, conv.busy]);

  const samples = lang === "hi"
    ? ["ऑर्डर DS-1042 कहाँ है?", "किन ऑर्डर में कमी है?", "रास्ते में कौन से ऑर्डर हैं?", "PPC सीमेंट की 30 बोरी का ड्राफ्ट बनाओ", "मेरी दुकान का हिसाब बताओ", "16 मिमी सरिया का स्टॉक है क्या?"]
    : ["Where is order DS-1042?", "Which deliveries need attention?", "Show my orders that have been dispatched but not received.",
      "What quantity was confirmed for the cement order?", "Did we receive the full quantity for DS-1042?", "Create a draft order for 30 bags of PPC cement.", "Show the history of this order."];
  const distSamples = lang === "hi" ? ["कौन से ऑर्डर पुष्टि के लिए बाकी हैं?", "किन ऑर्डर में कमी है?"] : ["Which orders need confirmation?", "Which deliveries need attention?"];

  return (
    <div>
      <PageHeader eyebrow={<SampleTag />} title={t("Ask Dukaan Sathi", "दुकान साथी से पूछें")}
        subtitle={t("Ask about orders, deliveries and stock in English or Hindi. Answers are built only from MCP tool results.", "ऑर्डर, डिलीवरी और स्टॉक के बारे में अंग्रेज़ी या हिन्दी में पूछें। जवाब सिर्फ़ MCP टूल के नतीजों से बनते हैं।")}
        actions={<Button variant="secondary" icon={<RotateCcw className="size-4" />} onClick={conv.reset}>{t("New conversation", "नई बातचीत")}</Button>} />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="flex min-h-[560px] flex-col lg:col-span-2">
          <div className="flex-1 space-y-4 overflow-y-auto p-5" aria-live="polite">
            {conv.messages.length === 0 && (
              <div className="py-8 text-center">
                <div className="mx-auto mb-3 flex size-12 items-center justify-center rounded-2xl bg-teal-soft text-teal"><MessagesSquare className="size-6" /></div>
                <p className="font-medium">{t("Try one of these", "इनमें से कुछ पूछें")}</p>
                <div className="mx-auto mt-3 flex max-w-xl flex-wrap justify-center gap-2">
                  {(role === "distributor" ? distSamples : samples).map((s) => (
                    <button key={s} onClick={() => conv.send(s)} className="rounded-full border border-line-strong bg-ivory px-3 py-1.5 text-sm text-ink-soft hover:bg-ivory-deep">{s}</button>
                  ))}
                </div>
              </div>
            )}
            {conv.messages.map((m) => (
              <div key={m.id} className={cx("flex gap-3", m.from === "user" && "flex-row-reverse")}>
                <span className={cx("flex size-8 shrink-0 items-center justify-center rounded-full", m.from === "user" ? "bg-[#fbe7cc] text-[#8a4b06]" : "bg-teal text-white")}>
                  {m.from === "user" ? <User className="size-4" /> : <Bot className="size-4" />}
                </span>
                <div className={cx("max-w-[85%]", m.from === "user" && "text-right")}>
                  <div className={cx("inline-block rounded-2xl px-4 py-2.5 text-sm text-left",
                    m.from === "user" ? "bg-ink text-white" : m.error ? "border border-[#f2c6c1] bg-red-soft text-red" : "border border-line bg-ivory text-ink")}>
                    {m.text}
                  </div>
                  {m.reply && <AssistantCards reply={m.reply} onAction={route} busy={conv.busy} />}
                  {m.reply && m.reply.mcp.length > 0 && (
                    <p className="mt-1 text-[11px] text-faint">MCP: {m.reply.mcp.map((x) => `${x.tool} (${x.elapsed_ms} ms)`).join(" → ")}</p>
                  )}
                </div>
              </div>
            ))}
            {conv.busy && <p className="flex items-center gap-2 text-sm text-muted"><Loader2 className="size-4 animate-spin" />{t("Calling MCP tools…", "MCP टूल चल रहे हैं…")}</p>}
            <div ref={endRef} />
          </div>
          <form className="flex gap-2 border-t border-line p-4" onSubmit={(e) => { e.preventDefault(); conv.send(text); setText(""); }}>
            <label htmlFor="ask" className="sr-only">{t("Message", "संदेश")}</label>
            <input id="ask" value={text} onChange={(e) => setText(e.target.value)} className={inputClass} autoComplete="off"
              placeholder={t("e.g. Did we receive the full quantity for DS-1042?", "जैसे: DS-1042 का पूरा माल आया क्या?")} />
            <Button type="submit" disabled={!text.trim() || conv.busy} icon={<Send className="size-4" />}>{t("Ask", "पूछें")}</Button>
          </form>
          <div className="px-4 pb-3"><ModeNote /></div>
        </Card>
        <Card className="h-fit">
          <CardHeader title={t("MCP tool calls", "MCP टूल कॉल")} subtitle={t("For the latest answer — tool, inputs, result and time", "पिछले जवाब के लिए — टूल, इनपुट, नतीजा और समय")} />
          <div className="px-5">
            {conv.traces.length ? <ul className="divide-y divide-line">{conv.traces.map((x) => <TraceRow key={x.id} trace={x} />)}</ul>
              : <p className="py-6 text-sm text-muted">{t("Ask a question to see which tools run.", "सवाल पूछें, देखें कौन-से टूल चलते हैं।")}</p>}
          </div>
          {conv.traces[0] && <p className="border-t border-line px-5 py-3 text-xs text-muted">{conv.traces[0].transport} · {t("protocol", "प्रोटोकॉल")} {conv.traces[0].protocol_version} · <span className="font-mono">{conv.traces[0].endpoint}</span></p>}
        </Card>
      </div>
      <Modal open={!!note} onClose={() => setNote(null)} title={t(`Note on ${note?.discrepancyId}`, `${note?.discrepancyId} पर नोट`)}
        footer={<>
          <Button variant="secondary" onClick={() => setNote(null)}>{t("Cancel", "रद्द करें")}</Button>
          <Button disabled={!noteText.trim()} onClick={() => { if (note) conv.confirm({ type: "add_note", discrepancy_id: note.discrepancyId, note: noteText, order_id: note.orderId }, t(`Save note: “${noteText}”`, `नोट सहेजें: “${noteText}”`)); setNote(null); }}>{t("Save note", "नोट सहेजें")}</Button>
        </>}>
        <textarea rows={3} className={inputClass} value={noteText} onChange={(e) => setNoteText(e.target.value)} aria-label={t("Note", "नोट")}
          placeholder={t("e.g. Counted again at the shop: 48 bags.", "जैसे: दुकान पर दोबारा गिना: 48 बोरी।")} />
      </Modal>
    </div>
  );
}
