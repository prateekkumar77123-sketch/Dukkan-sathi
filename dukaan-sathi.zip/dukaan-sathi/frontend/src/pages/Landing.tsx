import {
  ArrowRight, BookOpenCheck, CheckCircle2, ClipboardCheck, ExternalLink, FileSearch, History, Languages, MessageSquareWarning,
  Mic, PackageCheck, PhoneCall, PlugZap, Scale, ShieldCheck, Truck, XCircle,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LanguageToggle, Logo } from "../components/Layout";
import { QuantityFlow } from "../components/orders";
import { Photo } from "../components/Photo";
import { Badge, StatusBadge } from "../components/ui";
import { api } from "../lib/api";
import { useApp } from "../lib/app";
import { FACTS } from "../lib/sources";
import type { Order, OrderLine } from "../lib/types";

const SAMPLE_LINE: OrderLine = {
  line_id: 0, line_no: 1, sku: "CEM-OPC53-50", product_name: "OPC 53 Grade Cement", product_name_hi: "OPC 53 ग्रेड सीमेंट", category: "Cement",
  spec: "Ordinary Portland Cement, 53 grade, 50 kg bag", spec_hi: "ऑर्डिनरी पोर्टलैंड सीमेंट, 53 ग्रेड, 50 किलो बोरी", grade: "OPC 53", size: "50 kg bag",
  unit: "bag", unit_label: "bags", unit_label_hi: "बोरी", requested_qty: 50, confirmed_qty: 50, dispatched_qty: 50, received_qty: 48, damaged_qty: 0,
  unit_price_inr: 390, line_value_inr: 19500,
  comparison: {
    outcome: "short", comparable: true, dispatch_variance: 0, receipt_variance: -2,
    summary: "Received quantity is 2 bags below the recorded dispatched quantity (48 bags received vs 50 bags dispatched). Cause not yet determined.",
    summary_hi: "प्राप्त मात्रा दर्ज डिस्पैच से 2 बोरी कम है (50 बोरी भेजी गई, 48 बोरी मिली)। कारण अभी तय नहीं हुआ है।",
  },
};

function LivePreview() {
  const { t } = useApp();
  const [order, setOrder] = useState<Order | null>(null);
  const [live, setLive] = useState(false);
  useEffect(() => {
    api.get<Order>("/api/orders/DS-1042", "retailer").then((r) => { setOrder(r.data); setLive(true); }, () => setLive(false));
  }, []);
  const line = order?.lines[0] ?? SAMPLE_LINE;
  return (
    <div className="rounded-2xl border border-line bg-surface p-4 shadow-xl shadow-ink/10">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-semibold">DS-1042</span>
          {order ? <StatusBadge status={order.status} /> : <StatusBadge status="needs_review" />}
        </div>
        <span className="flex items-center gap-1.5 text-[11px] text-muted">
          <span className={`size-1.5 rounded-full ${live ? "bg-[#0e8a5f]" : "bg-faint"}`} />
          {live ? t("Live from the demo database via MCP", "डेमो डेटाबेस से MCP के ज़रिए लाइव") : t("Sample preview", "नमूना झलक")}
        </span>
      </div>
      <QuantityFlow line={line} />
    </div>
  );
}

export default function Landing() {
  const { t, lang } = useApp();
  const steps = [
    { icon: <Mic className="size-5" />, en: ["Request materials", "Type, tap or say the order — in English or Hindi."], hi: ["माल माँगें", "अंग्रेज़ी या हिन्दी में लिखें, चुनें या बोलें।"] },
    { icon: <FileSearch className="size-5" />, en: ["Validate product & units", "Grade, size and unit are matched to the catalogue. 50 kg is never 50 bags."], hi: ["उत्पाद और इकाई जाँचें", "ग्रेड, साइज़ और इकाई कैटलॉग से मिलाई जाती है। 50 किलो कभी 50 बोरी नहीं।"] },
    { icon: <ClipboardCheck className="size-5" />, en: ["Distributor confirms", "Full or partial quantity, recorded with a timestamp."], hi: ["डिस्ट्रीब्यूटर पुष्टि करता है", "पूरी या आंशिक मात्रा, समय के साथ दर्ज।"] },
    { icon: <Truck className="size-5" />, en: ["Goods are dispatched", "Challan number, quantities and expected delivery date."], hi: ["माल भेजा जाता है", "चालान नंबर, मात्रा और अपेक्षित डिलीवरी तारीख।"] },
    { icon: <PackageCheck className="size-5" />, en: ["Retailer records receipt", "Count what arrived, line by line, with condition notes."], hi: ["रिटेलर प्राप्ति दर्ज करता है", "हर लाइन में जो आया उसकी गिनती और हालत।"] },
    { icon: <Scale className="size-5" />, en: ["Differences are resolved", "Automatic comparison, a neutral record, and the agreed outcome."], hi: ["अंतर का समाधान", "स्वचालित तुलना, निष्पक्ष रिकॉर्ड और सहमत नतीजा।"] },
  ];
  const benefits = [
    { icon: <History className="size-5" />, en: ["Shared order visibility", "Retailer and distributor read the same record — no “which message was final?”"], hi: ["साझा ऑर्डर जानकारी", "रिटेलर और डिस्ट्रीब्यूटर एक ही रिकॉर्ड देखते हैं।"] },
    { icon: <ShieldCheck className="size-5" />, en: ["Product and unit validation", "Deterministic checks for SKU, grade, diameter and unit before anything is sent."], hi: ["उत्पाद और इकाई की जाँच", "भेजने से पहले SKU, ग्रेड, साइज़ और इकाई की पक्की जाँच।"] },
    { icon: <Languages className="size-5" />, en: ["Voice-friendly, bilingual", "Ask “मेरी सीमेंट डिलीवरी चेक करो” or “Where is DS-1042?”."], hi: ["आवाज़ और दो भाषाएँ", "पूछें “मेरी सीमेंट डिलीवरी चेक करो” या “Where is DS-1042?”।"] },
    { icon: <BookOpenCheck className="size-5" />, en: ["Traceable history", "Every confirmation, dispatch, receipt and note is a timestamped event."], hi: ["पूरा इतिहास", "हर पुष्टि, डिस्पैच, प्राप्ति और नोट समय के साथ दर्ज।"] },
    { icon: <MessageSquareWarning className="size-5" />, en: ["Discrepancy detection", "Short, excess and damaged quantities are flagged without assigning blame."], hi: ["अंतर की पहचान", "कम, अधिक या क्षतिग्रस्त माल बिना किसी पर दोष डाले दर्ज।"] },
    { icon: <PhoneCall className="size-5" />, en: ["Fewer follow-up calls", "Status, quantities and history are one question away."], hi: ["कम फ़ॉलो-अप कॉल", "स्थिति, मात्रा और इतिहास बस एक सवाल दूर।"] },
  ];

  return (
    <div className="bg-ivory text-ink">
      <header className="sticky top-0 z-30 border-b border-line/70 bg-ivory/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6">
          <Logo />
          <nav className="ml-6 hidden items-center gap-5 text-sm text-ink-soft md:flex" aria-label="Page sections">
            <a href="#how" className="hover:text-teal">{t("How it works", "कैसे काम करता है")}</a>
            <a href="#example" className="hover:text-teal">{t("Example", "उदाहरण")}</a>
            <a href="#context" className="hover:text-teal">{t("Trade context", "व्यापार संदर्भ")}</a>
            <Link to="/about" className="hover:text-teal">{t("Architecture", "आर्किटेक्चर")}</Link>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <LanguageToggle className="hidden sm:inline-flex" />
            <Link to="/app" className="inline-flex h-10 items-center gap-2 rounded-lg bg-teal px-4 text-sm font-medium text-white hover:bg-teal-deep">
              {t("Open Live Demo", "लाइव डेमो खोलें")} <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </header>

      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 pb-16 pt-10 sm:px-6 lg:grid-cols-2 lg:pt-16">
        <div>
          <div className="mb-5 flex flex-wrap gap-2">
            <Badge tone="teal">{t("For hardware & building-material trade", "हार्डवेयर और बिल्डिंग मटीरियल व्यापार के लिए")}</Badge>
            <Badge tone="neutral">English · हिन्दी</Badge>
          </div>
          <h1 className="text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl lg:text-[56px]">
            {t("Every order accounted for. Every delivery easier to verify.", "हर ऑर्डर का हिसाब। हर डिलीवरी की आसान जाँच।")}
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-soft">
            {t("Dukaan Sathi connects hardware retailers and distributors through one shared order-tracking workflow. Place orders naturally, follow fulfilment, and identify delivery differences without hunting through scattered conversations.",
              "दुकान साथी हार्डवेयर रिटेलर और डिस्ट्रीब्यूटर को एक साझा ऑर्डर-ट्रैकिंग प्रक्रिया से जोड़ता है। आसानी से ऑर्डर दें, डिलीवरी पर नज़र रखें, और बिखरी बातचीत खंगाले बिना डिलीवरी के अंतर पहचानें।")}
          </p>
          <p className="mt-3 text-sm font-medium text-muted">{t("From order to delivery, everyone stays in the loop.", "ऑर्डर से डिलीवरी तक, सब एक ही जानकारी पर।")}</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/app" className="inline-flex h-12 items-center gap-2 rounded-xl bg-teal px-6 font-medium text-white shadow-sm hover:bg-teal-deep">
              {t("Open Live Demo", "लाइव डेमो खोलें")} <ArrowRight className="size-4" />
            </Link>
            <a href="#how" className="inline-flex h-12 items-center rounded-xl border border-line-strong bg-surface px-6 font-medium hover:bg-ivory-deep">
              {t("See How It Works", "देखें कैसे काम करता है")}
            </a>
          </div>
          <div className="mt-7 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted">
            <span className="flex items-center gap-1.5"><PlugZap className="size-4 text-teal" />{t("Real MCP server (Streamable HTTP)", "असली MCP सर्वर (Streamable HTTP)")}</span>
            <span className="flex items-center gap-1.5"><Mic className="size-4 text-teal" />{t("Voice in English & Hindi", "अंग्रेज़ी व हिन्दी में आवाज़")}</span>
          </div>
        </div>
        <div className="relative">
          <Photo name="shop" eager className="aspect-[4/3] w-full rounded-3xl shadow-lg" />
          <div className="relative -mt-24 ml-auto w-[92%] sm:-mt-32 sm:w-[78%]">
            <LivePreview />
          </div>
        </div>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <h2 className="text-3xl font-semibold tracking-tight">{t("The same order, recorded once — not scattered across calls.", "एक ही ऑर्डर, एक बार दर्ज — कॉल्स में बिखरा नहीं।")}</h2>
          <p className="mt-2 max-w-3xl text-muted">{t("Many shops coordinate through phone calls, chat messages, sales representatives, invoices and notebooks. Practices vary — some businesses already use software. Where records are split, these situations can follow:", "कई दुकानें फ़ोन, चैट, सेल्स प्रतिनिधि, बिल और बही से काम चलाती हैं। तरीके अलग-अलग हैं — कुछ पहले से सॉफ़्टवेयर इस्तेमाल करती हैं। जहाँ रिकॉर्ड बँटे हों, वहाँ ऐसी स्थितियाँ बन सकती हैं:")}</p>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-line bg-ivory p-6">
              <p className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted">{t("Before Dukaan Sathi", "दुकान साथी से पहले")}</p>
              <ul className="space-y-3">
                {[
                  t("Orders spread across calls and messages.", "ऑर्डर कॉल और मैसेज में बिखरे।"),
                  t("Delivery status requires follow-up.", "डिलीवरी की स्थिति के लिए बार-बार पूछना।"),
                  t("Quantity disputes require comparing separate records.", "मात्रा के विवाद में अलग-अलग रिकॉर्ड मिलाने पड़ते हैं।"),
                ].map((x) => <li key={x} className="flex gap-3"><XCircle className="mt-0.5 size-5 shrink-0 text-red" /><span>{x}</span></li>)}
              </ul>
            </div>
            <div className="rounded-2xl border border-[#bcdcd6] bg-teal-soft p-6">
              <p className="mb-4 text-sm font-semibold uppercase tracking-wide text-teal">{t("With Dukaan Sathi", "दुकान साथी के साथ")}</p>
              <ul className="space-y-3">
                {[
                  t("Shared order record.", "साझा ऑर्डर रिकॉर्ड।"),
                  t("Clear status timeline.", "साफ़ स्थिति टाइमलाइन।"),
                  t("Automated quantity comparison and a recorded resolution.", "स्वचालित मात्रा तुलना और दर्ज समाधान।"),
                ].map((x) => <li key={x} className="flex gap-3"><CheckCircle2 className="mt-0.5 size-5 shrink-0 text-teal" /><span>{x}</span></li>)}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="how" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-semibold tracking-tight">{t("How it works", "कैसे काम करता है")}</h2>
        <p className="mt-2 text-muted">{t("Six steps, one record. Each step is an event both parties can see.", "छह कदम, एक रिकॉर्ड। हर कदम दोनों पक्षों को दिखता है।")}</p>
        <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {steps.map((s, i) => {
            const [title, body] = lang === "hi" ? s.hi : s.en;
            return (
              <li key={i} className="rounded-2xl border border-line bg-surface p-5">
                <div className="flex items-center gap-3">
                  <span className="flex size-10 items-center justify-center rounded-xl bg-teal-soft text-teal">{s.icon}</span>
                  <span className="text-sm font-semibold text-faint">0{i + 1}</span>
                </div>
                <p className="mt-4 font-semibold">{title}</p>
                <p className="mt-1 text-sm text-muted">{body}</p>
              </li>
            );
          })}
        </ol>
      </section>

      <section id="example" className="scroll-mt-20 bg-[#13302d] text-white">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2">
          <div>
            <Badge className="border-white/20 bg-white/10 text-white">{t("Simulated workflow · sample data", "सिम्युलेटेड प्रक्रिया · नमूना डेटा")}</Badge>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight">{t("50 bags ordered. 48 arrived. Now what?", "50 बोरी मँगाई। 48 आईं। अब?")}</h2>
            <p className="mt-4 text-lg leading-relaxed text-white/85">
              {t("A retailer agrees to purchase 50 bags of OPC 53 cement. The distributor records 50 bags dispatched. At delivery, the retailer records 48 bags received. Dukaan Sathi flags a two-bag difference and preserves the original order, dispatch record, receipt record, and subsequent resolution.",
                "एक रिटेलर OPC 53 सीमेंट की 50 बोरी खरीदने पर सहमत होता है। डिस्ट्रीब्यूटर 50 बोरी भेजी दर्ज करता है। डिलीवरी पर रिटेलर 48 बोरी प्राप्त दर्ज करता है। दुकान साथी 2 बोरी का अंतर दर्ज करता है और मूल ऑर्डर, डिस्पैच, प्राप्ति और बाद का समाधान — सब सुरक्षित रखता है।")}
            </p>
            <ul className="mt-6 space-y-2 text-white/80">
              <li className="flex gap-2"><CheckCircle2 className="mt-0.5 size-5 shrink-0 text-[#7fd1c3]" />{t("The record says “2 bags below the recorded dispatch — cause not yet determined”. It does not blame the driver or the godown.", "रिकॉर्ड कहता है “दर्ज डिस्पैच से 2 बोरी कम — कारण अभी तय नहीं”। ड्राइवर या गोदाम पर दोष नहीं डालता।")}</li>
              <li className="flex gap-2"><CheckCircle2 className="mt-0.5 size-5 shrink-0 text-[#7fd1c3]" />{t("Both parties add notes; the agreed outcome is recorded on top of the original numbers.", "दोनों पक्ष नोट जोड़ते हैं; सहमत नतीजा मूल संख्याओं के ऊपर दर्ज होता है।")}</li>
            </ul>
            <Link to="/app/orders/DS-1042" className="mt-8 inline-flex h-11 items-center gap-2 rounded-xl bg-white px-5 font-medium text-teal hover:bg-ivory">
              {t("Open DS-1042 in the demo", "डेमो में DS-1042 खोलें")} <ArrowRight className="size-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Photo name="cement" className="col-span-2 aspect-[16/9] rounded-2xl" />
            <Photo name="truck" className="aspect-square rounded-2xl" />
            <Photo name="storefront" className="aspect-square rounded-2xl" />
          </div>
        </div>
      </section>

      <section id="context" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6">
        <h2 className="text-3xl font-semibold tracking-tight">{t("Grounded in how the trade actually works", "व्यापार असल में जैसे चलता है, उसी पर आधारित")}</h2>
        <p className="mt-2 max-w-3xl text-muted">{t("Public facts that shaped the design — each linked to its source. They describe the context, not measured results of this prototype.", "डिज़ाइन को दिशा देने वाले सार्वजनिक तथ्य — हर एक का स्रोत दिया है। ये संदर्भ बताते हैं, इस प्रोटोटाइप के मापे गए नतीजे नहीं।")}</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FACTS.map((f) => (
            <figure key={f.id} className="flex flex-col rounded-2xl border border-line bg-surface p-5">
              <p className="text-3xl font-semibold tracking-tight text-teal">{f.stat[lang]}</p>
              <blockquote className="mt-2 flex-1 text-ink-soft">{f.claim[lang]}</blockquote>
              <figcaption className="mt-4 border-t border-line pt-3 text-xs text-muted">
                <a href={f.url} target="_blank" rel="noreferrer" className="inline-flex items-start gap-1 hover:text-teal">
                  <ExternalLink className="mt-0.5 size-3 shrink-0" />{f.publisher}
                </a>
              </figcaption>
            </figure>
          ))}
        </div>
        <div className="mt-8 grid items-center gap-6 rounded-2xl border border-line bg-surface p-6 md:grid-cols-3">
          <Photo name="site" className="aspect-[4/3] rounded-xl md:col-span-1" />
          <div className="md:col-span-2">
            <p className="font-semibold">{t("What we don't claim", "हम क्या दावा नहीं करते")}</p>
            <p className="mt-1 text-sm text-ink-soft">{t("We have not measured shortage rates, time saved or disputes avoided, and we have not run field trials. The businesses in the demo are fictional. Dukaan Sathi is a prototype of a plausible workflow, built to be tested with real retailers and distributors.",
              "हमने कमी की दर, बचा समय या टले विवाद नहीं मापे हैं, और कोई फ़ील्ड ट्रायल नहीं किया है। डेमो के व्यापार काल्पनिक हैं। दुकान साथी एक संभावित प्रक्रिया का प्रोटोटाइप है, जिसे असली रिटेलर और डिस्ट्रीब्यूटर के साथ परखा जाना है।")}</p>
          </div>
        </div>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
          <h2 className="text-3xl font-semibold tracking-tight">{t("What it does", "यह क्या करता है")}</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.map((b, i) => {
              const [title, body] = lang === "hi" ? b.hi : b.en;
              return (
                <div key={i} className="rounded-2xl border border-line bg-ivory p-5">
                  <span className="flex size-10 items-center justify-center rounded-xl bg-surface text-teal shadow-sm">{b.icon}</span>
                  <p className="mt-4 font-semibold">{title}</p>
                  <p className="mt-1 text-sm text-muted">{body}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid items-center gap-8 rounded-3xl bg-gradient-to-br from-[#0b4f49] to-[#0f6b63] p-8 text-white md:grid-cols-2 md:p-12">
          <div>
            <h2 className="text-3xl font-semibold tracking-tight">{t("Ask the way you'd ask the shop next door.", "वैसे ही पूछें जैसे पड़ोस की दुकान से पूछते हैं।")}</h2>
            <p className="mt-3 text-white/85">{t("The voice experience and the optional Alexa custom skill call the same MCP tools as the website — so the answer always matches the record.", "वॉइस अनुभव और वैकल्पिक Alexa कस्टम स्किल वही MCP टूल इस्तेमाल करते हैं जो वेबसाइट — इसलिए जवाब हमेशा रिकॉर्ड से मेल खाता है।")}</p>
            <Link to="/app/voice" className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-white px-5 font-medium text-teal">{t("Try the voice experience", "वॉइस अनुभव आज़माएँ")} <Mic className="size-4" /></Link>
          </div>
          <div className="space-y-3">
            {["“Dukaan Sathi, check my cement delivery.”", "“मेरी सीमेंट डिलीवरी चेक करो”", "“किन ऑर्डर में कमी है?”", "“Order 30 bags of PPC cement.”"].map((q) => (
              <div key={q} className="rounded-2xl bg-white/10 px-4 py-3 text-lg">{q}</div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-line bg-surface">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-4">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-3 max-w-md text-sm text-muted">{t("AI-assisted order coordination and delivery discrepancy management for hardware retailers and distributors. Hackathon prototype.", "हार्डवेयर रिटेलर और डिस्ट्रीब्यूटर के लिए ऑर्डर समन्वय और डिलीवरी अंतर प्रबंधन। हैकाथॉन प्रोटोटाइप।")}</p>
          </div>
          <div className="text-sm">
            <p className="font-semibold">{t("Explore", "देखें")}</p>
            <ul className="mt-2 space-y-1.5 text-muted">
              <li><Link to="/app" className="hover:text-teal">{t("Live demo", "लाइव डेमो")}</Link></li>
              <li><Link to="/about" className="hover:text-teal">{t("About", "परिचय")}</Link></li>
              <li><Link to="/about#architecture" className="hover:text-teal">{t("Architecture", "आर्किटेक्चर")}</Link></li>
              <li><Link to="/about#sources" className="hover:text-teal">{t("Sources & photo credits", "स्रोत और फ़ोटो श्रेय")}</Link></li>
            </ul>
          </div>
          <div className="text-sm text-muted">
            <p className="font-semibold text-ink">{t("Privacy & data", "गोपनीयता और डेटा")}</p>
            <p className="mt-2">{t("The demo uses synthetic data about fictional businesses and collects no personal data. Raj Hardware Store and Sharma Building Supplies are not real companies.", "डेमो काल्पनिक व्यापारों के नमूना डेटा का उपयोग करता है और कोई निजी डेटा नहीं लेता। राज हार्डवेयर स्टोर और शर्मा बिल्डिंग सप्लाइज़ असली कंपनियाँ नहीं हैं।")}</p>
            <p className="mt-2">{t("Stock photos from Pexels; they do not depict Dukaan Sathi users.", "स्टॉक फ़ोटो Pexels से; इनमें दुकान साथी के उपयोगकर्ता नहीं हैं।")}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
