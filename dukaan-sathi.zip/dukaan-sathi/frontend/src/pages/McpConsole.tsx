import { ChevronDown, ChevronRight, Lock, PlugZap, Radio, ShieldCheck, Terminal } from "lucide-react";
import { useState } from "react";
import { ActivityFeed, ConnectionIndicator, TraceStrip } from "../components/mcp";
import { Badge, Card, CardHeader, ErrorState, PageHeader, Spinner } from "../components/ui";
import { useApi, useApp } from "../lib/app";

interface ToolInfo { name: string; title: string | null; description: string | null; input_schema: { properties?: Record<string, { description?: string; type?: string }>; required?: string[] }; has_output_schema: boolean; read_only: boolean }

export default function McpConsole() {
  const { t, health } = useApp();
  const q = useApi<{ tools: ToolInfo[]; protocol_version: string; endpoint: string; transport: string }>("/api/mcp/tools");
  const [open, setOpen] = useState<string | null>("get_order_status");
  return (
    <div>
      <PageHeader title={t("MCP console", "MCP कंसोल")} eyebrow={<ConnectionIndicator />}
        subtitle={t("Live view of the Dukaan Sathi MCP server: tools discovered by the gateway's MCP client, and every call made over Streamable HTTP.", "Dukaan Sathi MCP सर्वर का लाइव दृश्य: गेटवे के MCP क्लाइंट द्वारा खोजे गए टूल, और Streamable HTTP पर हर कॉल।")} />
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          [t("Endpoint", "एंडपॉइंट"), health?.mcp.url ?? "—", <PlugZap key="a" className="size-4" />],
          [t("Transport", "ट्रांसपोर्ट"), "Streamable HTTP", <Radio key="b" className="size-4" />],
          [t("Negotiated protocol", "तय प्रोटोकॉल"), health?.mcp.negotiated_protocol_version ?? "—", <ShieldCheck key="c" className="size-4" />],
          [t("Auth", "प्रमाणीकरण"), t("Bearer token → demo role", "बेयरर टोकन → डेमो भूमिका"), <Lock key="d" className="size-4" />],
        ].map(([label, value, icon]) => (
          <Card key={label as string} className="p-4">
            <p className="flex items-center gap-1.5 text-xs font-medium text-muted">{icon}{label}</p>
            <p className="mt-1 break-all font-mono text-sm font-semibold text-ink">{value as string}</p>
          </Card>
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader title={t("Registered tools", "पंजीकृत टूल")} subtitle={q.data ? t(`${q.data.tools.length} tools via tools/list`, `tools/list से ${q.data.tools.length} टूल`) : undefined} icon={<Terminal className="size-5" />} />
          {q.loading && <Spinner />}
          {q.error && <ErrorState error={q.error} onRetry={q.reload} />}
          <ul className="divide-y divide-line">
            {q.data?.tools.map((tool) => (
              <li key={tool.name}>
                <button className="flex w-full items-start gap-3 px-5 py-3 text-left hover:bg-ivory/70" onClick={() => setOpen(open === tool.name ? null : tool.name)} aria-expanded={open === tool.name}>
                  {open === tool.name ? <ChevronDown className="mt-0.5 size-4 text-muted" /> : <ChevronRight className="mt-0.5 size-4 text-muted" />}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <code className="font-mono text-sm font-semibold">{tool.name}</code>
                      <Badge tone={tool.read_only ? "teal" : "amber"}>{tool.read_only ? t("read", "पढ़ना") : t("write", "लिखना")}</Badge>
                      {tool.has_output_schema && <Badge>{t("structured output", "संरचित आउटपुट")}</Badge>}
                    </div>
                    {open !== tool.name && <p className="mt-0.5 line-clamp-2 text-sm text-muted">{tool.description}</p>}
                  </div>
                </button>
                {open === tool.name && (
                  <div className="px-12 pb-4">
                    <p className="mb-2 whitespace-pre-line text-sm text-ink-soft">{tool.description}</p>
                    <table className="w-full text-xs">
                      <thead><tr className="text-left text-muted"><th className="py-1 pr-3 font-medium">{t("Argument", "आर्ग्युमेंट")}</th><th className="py-1 pr-3 font-medium">{t("Type", "प्रकार")}</th><th className="py-1 font-medium">{t("Description", "विवरण")}</th></tr></thead>
                      <tbody>
                        {Object.entries(tool.input_schema.properties ?? {}).map(([k, v]) => (
                          <tr key={k} className="border-t border-line align-top">
                            <td className="py-1.5 pr-3 font-mono">{k}{tool.input_schema.required?.includes(k) && <span className="text-red">*</span>}</td>
                            <td className="py-1.5 pr-3 text-muted">{v.type ?? "object"}</td>
                            <td className="py-1.5 text-muted">{v.description ?? ""}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader title={t("Live call log", "लाइव कॉल लॉग")} subtitle={t("Newest first · website, assistant, voice demo and Alexa", "नई पहले · वेबसाइट, असिस्टेंट, वॉइस डेमो और Alexa")} icon={<Radio className="size-5" />} />
          <div className="max-h-[640px] overflow-y-auto px-5"><ActivityFeed limit={60} /></div>
        </Card>
      </div>
      <TraceStrip traces={q.traces} className="mt-6" />
      <Card className="mt-6 p-5 text-sm text-ink-soft">
        <p className="font-semibold text-ink">{t("Test it from outside the website", "वेबसाइट के बाहर से जाँचें")}</p>
        <p className="mt-1">{t("Any compatible MCP client can connect to the same endpoint with a bearer token. See README → “Testing a real MCP tool call” for an MCP Inspector walkthrough and a Python client script (scripts/mcp_smoke_test.py).", "कोई भी संगत MCP क्लाइंट बेयरर टोकन के साथ इसी एंडपॉइंट से जुड़ सकता है। MCP Inspector और Python स्क्रिप्ट (scripts/mcp_smoke_test.py) के लिए README देखें।")}</p>
      </Card>
    </div>
  );
}
