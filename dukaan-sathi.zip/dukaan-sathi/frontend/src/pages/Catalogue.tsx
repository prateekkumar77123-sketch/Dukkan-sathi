import { Search } from "lucide-react";
import { useState } from "react";
import { TraceStrip } from "../components/mcp";
import { Badge, Card, cx, EmptyState, ErrorState, inputClass, PageHeader, SampleTag, Spinner } from "../components/ui";
import { qs } from "../lib/api";
import { useApi, useApp } from "../lib/app";
import { inr, num, unitLabel } from "../lib/format";
import type { Product } from "../lib/types";

const CATS = ["", "Cement", "Steel", "Pipes", "Fasteners", "Finishes", "Electrical"];
const CAT_HI: Record<string, string> = { Cement: "सीमेंट", Steel: "स्टील", Pipes: "पाइप", Fasteners: "पेंच", Finishes: "फ़िनिश", Electrical: "इलेक्ट्रिकल" };

export default function Catalogue() {
  const { t, lang } = useApp();
  const [q, setQ] = useState("");
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState("");
  const res = useApi<{ count: number; products: Product[]; needs_clarification: boolean; clarification: string | null; clarification_hi: string | null }>(`/api/products${qs({ q: query, category: cat })}`);

  return (
    <div>
      <PageHeader eyebrow={<SampleTag />} title={t("Product catalogue", "उत्पाद कैटलॉग")}
        subtitle={t("Canonical units and explicit specifications keep orders unambiguous. Prices and stock are illustrative demo values, not market quotes.", "स्पष्ट इकाई और स्पेसिफिकेशन से ऑर्डर में भ्रम नहीं रहता। दाम और स्टॉक डेमो के लिए हैं, बाज़ार भाव नहीं।")} />
      <Card>
        <div className="flex flex-col gap-3 border-b border-line p-4 sm:flex-row">
          <form className="relative flex-1" onSubmit={(e) => { e.preventDefault(); setQuery(q); }} role="search">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
            <input value={q} onChange={(e) => setQ(e.target.value)} className={cx(inputClass, "pl-9")}
              placeholder={t("Search: OPC 53, 8 mm sariya, 2 inch pipe…", "खोजें: OPC 53, 8 मिमी सरिया, 2 इंच पाइप…")} aria-label={t("Search products", "उत्पाद खोजें")} />
          </form>
          <div className="flex flex-wrap gap-1.5">
            {CATS.map((c) => (
              <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c}
                className={cx("rounded-full border px-3 py-1.5 text-sm", cat === c ? "border-teal bg-teal text-white" : "border-line-strong bg-surface text-ink-soft hover:bg-ivory-deep")}>
                {c ? (lang === "hi" ? CAT_HI[c] : c) : t("All", "सभी")}
              </button>
            ))}
          </div>
        </div>
        {res.loading && <Spinner />}
        {res.error && <ErrorState error={res.error} onRetry={res.reload} />}
        {res.data?.needs_clarification && query && (
          <p className="border-b border-line bg-amber-soft px-5 py-2 text-sm text-amber">{lang === "hi" ? res.data.clarification_hi : res.data.clarification}</p>
        )}
        {res.data && res.data.count === 0 && <EmptyState title={t("No products match", "कोई उत्पाद नहीं मिला")} />}
        {res.data && res.data.count > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
                  <th className="px-5 py-2.5 font-medium">{t("Product & specification", "उत्पाद और स्पेसिफिकेशन")}</th>
                  <th className="px-3 py-2.5 font-medium">{t("Unit", "इकाई")}</th>
                  <th className="hidden px-3 py-2.5 font-medium md:table-cell">{t("Standard / tax", "मानक / कर")}</th>
                  <th className="px-3 py-2.5 text-right font-medium">{t("Price*", "दाम*")}</th>
                  <th className="px-5 py-2.5 text-right font-medium">{t("Available*", "उपलब्ध*")}</th>
                </tr>
              </thead>
              <tbody>
                {res.data.products.map((p) => (
                  <tr key={p.sku} className="border-b border-line last:border-0">
                    <td className="px-5 py-3 align-top">
                      <p className="font-medium text-ink">{lang === "hi" ? p.name_hi : p.name}</p>
                      <p className="text-xs text-muted">{lang === "hi" ? p.spec_hi : p.spec}</p>
                      <p className="mt-0.5 font-mono text-[11px] text-faint">{p.sku}</p>
                    </td>
                    <td className="px-3 py-3 align-top">
                      <span className="font-medium">{unitLabel(p.unit, 1, lang)}</span>
                      {p.alt_unit && <p className="text-xs text-muted">{t("also", "या")} {unitLabel(p.alt_unit, 2, lang)}: {p.alt_per_unit} = 1 {unitLabel(p.unit, 1, lang)}</p>}
                    </td>
                    <td className="hidden px-3 py-3 align-top text-xs text-muted md:table-cell">
                      {p.standard ? <Badge tone="teal">{p.standard}</Badge> : "—"}
                      {p.hsn && <p className="mt-1">HSN {p.hsn}{p.gst_rate ? ` · GST ${p.gst_rate}%` : ""}</p>}
                    </td>
                    <td className="px-3 py-3 text-right align-top tabular">{inr(p.price_inr)}<span className="block text-[11px] text-faint">/ {unitLabel(p.unit, 1, lang)}</span></td>
                    <td className="px-5 py-3 text-right align-top">
                      <Badge tone={p.availability === "out_of_stock" ? "red" : p.availability === "low_stock" ? "amber" : "green"}>
                        {p.availability === "out_of_stock" ? t("Out of stock", "स्टॉक में नहीं") : `${num(p.available_qty)} ${unitLabel(p.unit, p.available_qty, lang)}`}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="space-y-1 border-t border-line px-5 py-3 text-xs text-muted">
          <p>{t("* Illustrative prices and stock for this demo (Sharma Building Supplies is fictional). They are not current market prices.", "* इस डेमो के लिए उदाहरण दाम और स्टॉक (शर्मा बिल्डिंग सप्लाइज़ काल्पनिक है)। ये बाज़ार भाव नहीं हैं।")}</p>
          <p>{t("Standards shown are real Bureau of Indian Standards references: IS 269:2015 (OPC), IS 1489 (Part 1):2015 (fly-ash PPC), IS 1786:2008 (TMT bars). Cement (HSN 2523) moved from 28% to 18% GST on 22 Sep 2025. Bar weights use the standard d²/162 kg per metre approximation.", "दिखाए गए मानक असली BIS संदर्भ हैं: IS 269:2015 (OPC), IS 1489 (भाग 1):2015 (फ्लाई ऐश PPC), IS 1786:2008 (TMT सरिया)। सीमेंट (HSN 2523) पर GST 22 सितंबर 2025 से 28% से घटकर 18% हुआ। सरिये का वज़न d²/162 किलो प्रति मीटर के मानक अनुमान से।")}</p>
        </div>
      </Card>
      <TraceStrip traces={res.traces} className="mt-4" />
    </div>
  );
}
