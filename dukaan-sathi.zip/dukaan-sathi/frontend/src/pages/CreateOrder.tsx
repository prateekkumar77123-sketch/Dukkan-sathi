import { CheckCircle2, Loader2, Mic, MicOff, PackagePlus, Plus, Send, ShieldCheck, Sparkles, Trash2, XCircle } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { TraceStrip } from "../components/mcp";
import { Badge, Button, Card, CardHeader, cx, EmptyState, Field, inputClass, PageHeader, SampleTag } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { useApi, useApp } from "../lib/app";
import { inr, num, todayIST, unitLabel } from "../lib/format";
import { listen, micErrorMessage, speechRecognitionSupported, type ListenHandle } from "../lib/speech";
import type { ActionResult, AssistantReply, Product, ToolTrace, Validation } from "../lib/types";

interface Line { sku: string; quantity: string; unit: string }

export default function CreateOrder() {
  const { t, lang, role, toast } = useApp();
  const navigate = useNavigate();
  const catalogue = useApi<{ products: Product[] }>("/api/products");
  const products = catalogue.data?.products ?? [];
  const [lines, setLines] = useState<Line[]>([]);
  const [text, setText] = useState("");
  const [nlBusy, setNlBusy] = useState(false);
  const [nlReply, setNlReply] = useState<AssistantReply | null>(null);
  const [validation, setValidation] = useState<Validation | null>(null);
  const [validating, setValidating] = useState(false);
  const [submitting, setSubmitting] = useState<"" | "draft" | "submit">("");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");
  const [traces, setTraces] = useState<ToolTrace[]>([]);
  const [error, setError] = useState<ApiError | null>(null);
  const [listening, setListening] = useState(false);
  const handle = useRef<ListenHandle | null>(null);

  useEffect(() => {
    setValidation(null);
  }, [lines]);

  const productBySku = (sku: string) => products.find((p) => p.sku === sku);

  const interpret = async (message: string, selection?: Record<string, unknown>) => {
    if (!message.trim() && !selection) return;
    setNlBusy(true);
    setError(null);
    try {
      const r = await api.post<AssistantReply>("/api/assistant", { message, lang, source: "assistant", selection });
      setNlReply(r.data);
      setTraces(r.data.mcp);
      const action = r.data.pending_action;
      if (action && Array.isArray(action.lines)) {
        const newLines = (action.lines as { sku: string; quantity: number; unit: string }[]).map((l) => ({ sku: l.sku, quantity: String(l.quantity), unit: l.unit }));
        setLines((prev) => [...prev.filter((p) => !newLines.some((n) => n.sku === p.sku)), ...newLines]);
      }
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setNlBusy(false);
    }
  };

  const mic = () => {
    if (listening) {
      handle.current?.stop();
      return;
    }
    const h = listen(lang, {
      onInterim: (x) => setText(x),
      onFinal: (x) => { setText(x); interpret(x); },
      onError: (code) => toast(micErrorMessage(code, lang), "error"),
      onEnd: () => setListening(false),
    });
    if (h) { handle.current = h; setListening(true); }
  };

  const validate = async () => {
    setValidating(true);
    setError(null);
    try {
      const r = await api.post<Validation>("/api/orders/validate", { lines: lines.map((l) => ({ sku: l.sku, quantity: Number(l.quantity), unit: l.unit })) });
      setValidation(r.data);
      setTraces(r.mcp ?? []);
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setValidating(false);
    }
  };

  const place = async (submit: boolean) => {
    setSubmitting(submit ? "submit" : "draft");
    setError(null);
    try {
      const r = await api.post<ActionResult>("/api/orders", {
        lines: lines.map((l) => ({ sku: l.sku, quantity: Number(l.quantity), unit: l.unit })),
        requested_delivery_date: date || null, notes: notes || null, submit,
      });
      toast(lang === "hi" ? r.data.message_hi : r.data.message);
      navigate(`/app/orders/${r.data.order.id}`);
    } catch (e) {
      setError(e as ApiError);
      setTraces((e as ApiError).traces);
    } finally {
      setSubmitting("");
    }
  };

  if (role !== "retailer") {
    return (
      <Card><EmptyState icon={<PackagePlus className="size-6" />} title={t("Orders are created by the retailer", "ऑर्डर रिटेलर बनाते हैं")}
        body={t("Switch to the Raj Hardware Store demo role in the sidebar to create an order.", "ऑर्डर बनाने के लिए साइडबार में राज हार्डवेयर स्टोर भूमिका चुनें।")} /></Card>
    );
  }

  const samples = lang === "hi"
    ? ["OPC 53 सीमेंट की 50 बोरी ऑर्डर करो", "200 पीस 8 मिमी सरिया चाहिए", "2 इंच PVC पाइप की 20 लंबाई"]
    : ["Order 50 bags of OPC 53 cement", "I need 200 pieces of 8 mm TMT bar, grade 500D", "Order 20 lengths of 2-inch PVC pipe"];
  const choices = nlReply?.cards.find((c) => c.type === "choices") as { options: { label: string; sku: string; quantity: number; unit: string }[] } | undefined;
  const canValidate = lines.length > 0 && lines.every((l) => l.sku && Number(l.quantity) > 0 && l.unit);

  return (
    <div>
      <PageHeader eyebrow={<SampleTag />} title={t("New order", "नया ऑर्डर")}
        subtitle={t("Describe the order in your own words, or add items from the catalogue. Nothing is sent until you confirm.", "अपने शब्दों में ऑर्डर बताएँ, या कैटलॉग से आइटम जोड़ें। आपकी पुष्टि के बिना कुछ नहीं भेजा जाता।")} />
      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader title={t("Say or type the order", "ऑर्डर बोलें या लिखें")} icon={<Sparkles className="size-5" />}
            subtitle={t("English, Hindi or Hinglish. Products are matched against the catalogue — never invented.", "अंग्रेज़ी, हिन्दी या हिंग्लिश। उत्पाद कैटलॉग से मिलाए जाते हैं — गढ़े नहीं जाते।")} />
          <div className="space-y-3 p-5">
            <form onSubmit={(e) => { e.preventDefault(); interpret(text); }} className="space-y-2">
              <label htmlFor="nl" className="sr-only">{t("Order request", "ऑर्डर अनुरोध")}</label>
              <textarea id="nl" rows={3} className={inputClass} value={text} onChange={(e) => setText(e.target.value)}
                placeholder={samples[0]} />
              <div className="flex gap-2">
                <Button type="submit" loading={nlBusy} icon={<Sparkles className="size-4" />}>{t("Interpret", "समझें")}</Button>
                {speechRecognitionSupported() ? (
                  <Button type="button" variant={listening ? "danger" : "secondary"} onClick={mic} icon={listening ? <MicOff className="size-4" /> : <Mic className="size-4" />}>
                    {listening ? t("Stop", "रोकें") : t("Speak", "बोलें")}
                  </Button>
                ) : (
                  <span className="self-center text-xs text-muted">{t("Voice input isn't available in this browser — typing works.", "इस ब्राउज़र में आवाज़ इनपुट नहीं — टाइप करें।")}</span>
                )}
              </div>
            </form>
            <div className="flex flex-wrap gap-1.5">
              {samples.map((s) => (
                <button key={s} onClick={() => { setText(s); interpret(s); }} className="rounded-full border border-line-strong bg-ivory px-3 py-1 text-xs text-ink-soft hover:bg-ivory-deep">{s}</button>
              ))}
            </div>
            {nlReply && (
              <div className={cx("rounded-xl border p-3 text-sm", nlReply.pending_action ? "border-[#bfe3d1] bg-[#e7f5ee]" : "border-line bg-ivory")}>
                <p className="text-ink-soft">{nlReply.reply}</p>
                {choices && (
                  <div className="mt-2 space-y-1.5">
                    {choices.options.map((o) => (
                      <button key={o.sku} onClick={() => interpret(o.label, { sku: o.sku, quantity: o.quantity, unit: o.unit })}
                        className="block w-full rounded-lg border border-line-strong bg-surface px-3 py-2 text-left text-sm hover:border-teal">
                        {o.label}
                      </button>
                    ))}
                  </div>
                )}
                {nlReply.suggestions.filter((s) => s.action.type === "select").map((s) => (
                  <Button key={s.label} size="sm" variant="secondary" className="mt-2" onClick={() => interpret(s.label, s.action.selection as Record<string, unknown>)}>{s.label}</Button>
                ))}
                {nlReply.pending_action && <p className="mt-1 text-xs font-medium text-[#0b6b49]">{t("Added to the order lines → review and confirm on the right.", "ऑर्डर लाइनों में जोड़ा गया → दाईं ओर जाँचकर पुष्टि करें।")}</p>}
              </div>
            )}
          </div>
        </Card>

        <div className="space-y-6 lg:col-span-3">
          <Card>
            <CardHeader title={t("Order lines", "ऑर्डर लाइनें")} subtitle={t("Distributor: Sharma Building Supplies (demo)", "डिस्ट्रीब्यूटर: शर्मा बिल्डिंग सप्लाइज़ (डेमो)")}
              action={<Button size="sm" variant="secondary" icon={<Plus className="size-4" />} onClick={() => setLines([...lines, { sku: "", quantity: "", unit: "" }])}>{t("Add item", "आइटम जोड़ें")}</Button>} />
            <div className="space-y-3 p-5">
              {lines.length === 0 && <p className="py-6 text-center text-sm text-muted">{t("No items yet. Interpret a request or add an item.", "अभी कोई आइटम नहीं। अनुरोध समझाएँ या आइटम जोड़ें।")}</p>}
              {lines.map((l, i) => {
                const p = productBySku(l.sku);
                const units = p ? [p.unit, ...(p.alt_unit ? [p.alt_unit] : [])] : [];
                return (
                  <div key={i} className="grid grid-cols-12 items-end gap-2 rounded-xl border border-line p-3">
                    <div className="col-span-12 sm:col-span-6">
                      <Field htmlFor={`p${i}`} label={t("Product", "उत्पाद")}>
                        <select id={`p${i}`} className={inputClass} value={l.sku} onChange={(e) => {
                          const np = productBySku(e.target.value);
                          setLines(lines.map((x, j) => (j === i ? { ...x, sku: e.target.value, unit: np?.unit ?? "" } : x)));
                        }}>
                          <option value="">{t("Choose…", "चुनें…")}</option>
                          {products.map((pp) => <option key={pp.sku} value={pp.sku}>{lang === "hi" ? pp.name_hi : pp.name}</option>)}
                        </select>
                      </Field>
                    </div>
                    <div className="col-span-5 sm:col-span-2">
                      <Field htmlFor={`q${i}`} label={t("Qty", "मात्रा")}>
                        <input id={`q${i}`} type="number" min={0} className={inputClass} value={l.quantity} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, quantity: e.target.value } : x)))} />
                      </Field>
                    </div>
                    <div className="col-span-5 sm:col-span-3">
                      <Field htmlFor={`u${i}`} label={t("Unit", "इकाई")}>
                        <select id={`u${i}`} className={inputClass} value={l.unit} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, unit: e.target.value } : x)))}>
                          {units.length === 0 && <option value="">—</option>}
                          {units.map((u) => <option key={u} value={u}>{unitLabel(u, 2, lang)}{p?.alt_unit === u ? ` (${p.alt_per_unit} = 1 ${unitLabel(p.unit, 1, lang)})` : ""}</option>)}
                        </select>
                      </Field>
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <button className="mb-1 rounded-lg p-2 text-muted hover:bg-red-soft hover:text-red" onClick={() => setLines(lines.filter((_, j) => j !== i))} aria-label={t("Remove", "हटाएँ")}>
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                    {p && <p className="col-span-12 text-xs text-muted">{lang === "hi" ? p.spec_hi : p.spec}{p.standard ? ` · ${p.standard}` : ""} · {t("available", "उपलब्ध")} {num(p.available_qty)} {unitLabel(p.unit, 2, lang)}</p>}
                  </div>
                );
              })}
              <div className="grid gap-3 sm:grid-cols-2">
                <Field htmlFor="date" label={t("Requested delivery date (optional)", "डिलीवरी तारीख (वैकल्पिक)")}>
                  <input id="date" type="date" min={todayIST()} className={inputClass} value={date} onChange={(e) => setDate(e.target.value)} />
                </Field>
                <Field htmlFor="notes" label={t("Notes (optional)", "नोट (वैकल्पिक)")}>
                  <input id="notes" className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
                </Field>
              </div>
              <Button variant="secondary" disabled={!canValidate} loading={validating} icon={<ShieldCheck className="size-4" />} onClick={validate}>
                {t("Validate items, units & stock", "आइटम, इकाई और स्टॉक जाँचें")}
              </Button>
            </div>
          </Card>

          {validation && (
            <Card className={validation.valid ? "border-[#bfe3d1]" : "border-[#f2c6c1]"}>
              <CardHeader title={validation.valid ? t("Confirm this order", "इस ऑर्डर की पुष्टि करें") : t("Fix these items first", "पहले ये आइटम ठीक करें")}
                icon={validation.valid ? <CheckCircle2 className="size-5 text-[#0b6b49]" /> : <XCircle className="size-5 text-red" />}
                subtitle={lang === "hi" ? validation.summary_hi : validation.summary} />
              <ul className="divide-y divide-line">
                {validation.lines.map((l) => (
                  <li key={l.line_no} className="flex flex-col gap-1 px-5 py-3 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <p className="font-medium">{(lang === "hi" ? l.product_name_hi : l.product_name) ?? l.sku}</p>
                      {l.spec && <p className="text-xs text-muted">{l.spec}</p>}
                      {(lang === "hi" ? l.messages_hi : l.messages).map((m) => <p key={m} className={cx("text-sm", l.valid ? "text-ink-soft" : "text-red")}>{m}</p>)}
                    </div>
                    <div className="text-right">
                      {l.canonical_qty !== null && l.unit && <p className="text-lg font-semibold tabular">{num(l.canonical_qty)} {unitLabel(l.unit, l.canonical_qty, lang)}</p>}
                      <Badge tone={l.availability === "available" ? "green" : l.availability === "partial" ? "amber" : l.availability === "unknown" ? "neutral" : "red"}>
                        {{ available: t("In stock", "स्टॉक में"), partial: t("Partial stock", "आंशिक स्टॉक"), out_of_stock: t("Out of stock", "स्टॉक में नहीं"), unknown: t("Not validated", "जाँच नहीं हुई") }[l.availability]}
                      </Badge>
                      {l.line_value_inr !== null && <p className="mt-1 text-xs text-muted">{inr(l.line_value_inr)}</p>}
                    </div>
                  </li>
                ))}
              </ul>
              {validation.valid && (
                <div className="flex flex-col gap-3 border-t border-line bg-ivory/60 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-sm text-muted">{t("Illustrative total", "उदाहरण कुल")}: <b className="text-ink">{inr(validation.total_value_inr)}</b> · {t("to Sharma Building Supplies", "शर्मा बिल्डिंग सप्लाइज़ को")}</p>
                  <div className="flex gap-2">
                    <Button variant="secondary" loading={submitting === "draft"} onClick={() => place(false)}>{t("Save draft", "ड्राफ्ट सहेजें")}</Button>
                    <Button loading={submitting === "submit"} icon={<Send className="size-4" />} onClick={() => place(true)}>{t("Confirm & send order", "पुष्टि करके भेजें")}</Button>
                  </div>
                </div>
              )}
            </Card>
          )}
          {error && <div className="rounded-xl border border-[#f2c6c1] bg-red-soft px-4 py-3 text-sm text-red" role="alert">{lang === "hi" ? error.messageHi : error.message}</div>}
          {nlBusy && <p className="flex items-center gap-2 text-sm text-muted"><Loader2 className="size-4 animate-spin" />{t("Asking the MCP server…", "MCP सर्वर से पूछ रहे हैं…")}</p>}
          <TraceStrip traces={traces} />
        </div>
      </div>
    </div>
  );
}
