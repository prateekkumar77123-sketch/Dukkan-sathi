import { CheckCircle2, Scale } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { TraceStrip } from "../components/mcp";
import { DiscrepancyCard } from "../components/orders";
import { Card, cx, EmptyState, ErrorState, PageHeader, SampleTag, Spinner } from "../components/ui";
import { useApi, useApp } from "../lib/app";
import type { Discrepancy } from "../lib/types";

export default function Discrepancies() {
  const { t, lang } = useApp();
  const [filter, setFilter] = useState<"unresolved" | "resolved" | "">("unresolved");
  const q = useApi<{ count: number; discrepancies: Discrepancy[] }>(`/api/discrepancies${filter ? `?status=${filter}` : ""}`);
  const tabs = [
    { key: "unresolved" as const, en: "Needs attention", hi: "ध्यान देना ज़रूरी" },
    { key: "resolved" as const, en: "Resolved", hi: "समाधान हुआ" },
    { key: "" as const, en: "All", hi: "सभी" },
  ];
  return (
    <div>
      <PageHeader eyebrow={<SampleTag />} title={t("Deliveries & differences", "डिलीवरी और अंतर")}
        subtitle={t("Every difference between dispatched and received quantities, linked to its order line, with notes and the recorded resolution.", "भेजी और प्राप्त मात्रा का हर अंतर, ऑर्डर लाइन से जुड़ा, नोट और दर्ज समाधान के साथ।")} />
      <div className="mb-4 flex flex-wrap gap-1.5" role="tablist">
        {tabs.map((x) => (
          <button key={x.key} role="tab" aria-selected={filter === x.key} onClick={() => setFilter(x.key)}
            className={cx("rounded-full border px-3 py-1.5 text-sm", filter === x.key ? "border-teal bg-teal text-white" : "border-line-strong bg-surface text-ink-soft hover:bg-ivory-deep")}>
            {lang === "hi" ? x.hi : x.en}
          </button>
        ))}
      </div>
      <div className="mb-6 rounded-2xl border border-line bg-surface p-4 text-sm text-ink-soft">
        <p className="flex items-center gap-2 font-medium text-ink"><Scale className="size-4 text-teal" />{t("How differences are detected", "अंतर कैसे पकड़ा जाता है")}</p>
        <p className="mt-1">{t("When the retailer records receipt, the MCP server compares received with dispatched quantities for every line in the same unit. A shortfall, excess or damaged quantity opens a discrepancy. The record says where the numbers differ — not who caused it.", "जब रिटेलर प्राप्ति दर्ज करता है, MCP सर्वर हर लाइन की प्राप्त और भेजी मात्रा की तुलना उसी इकाई में करता है। कमी, अधिकता या क्षतिग्रस्त माल पर अंतर दर्ज होता है। रिकॉर्ड बताता है कि संख्या कहाँ अलग है — किसने किया, यह नहीं।")}</p>
      </div>
      {q.loading && <Spinner />}
      {q.error && <Card><ErrorState error={q.error} onRetry={q.reload} /></Card>}
      {q.data && q.data.count === 0 && (
        <Card><EmptyState icon={<CheckCircle2 className="size-6" />} title={t("No differences here", "यहाँ कोई अंतर नहीं")} body={t("Try another tab, or record a receipt on an in-transit order.", "दूसरा टैब देखें, या रास्ते वाले ऑर्डर की प्राप्ति दर्ज करें।")} /></Card>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        {q.data?.discrepancies.map((d) => (
          <DiscrepancyCard key={d.id} d={d}>
            <div className="mt-3 border-t border-line pt-3">
              <Link to={`/app/orders/${d.order_id}#${d.id}`} className="text-sm font-medium text-teal hover:underline">
                {d.status === "resolved" ? t("Open order record →", "ऑर्डर रिकॉर्ड खोलें →") : t("Open order to respond →", "जवाब देने के लिए ऑर्डर खोलें →")}
              </Link>
            </div>
          </DiscrepancyCard>
        ))}
      </div>
      <TraceStrip traces={q.traces} className="mt-6" />
    </div>
  );
}
