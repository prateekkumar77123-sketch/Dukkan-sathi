import { Clapperboard, Database, ListChecks, PlayCircle, RotateCcw } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Card, CardHeader, PageHeader, SampleTag } from "../components/ui";
import { api, ApiError } from "../lib/api";
import { useApp } from "../lib/app";

export default function DemoControls() {
  const { t, setRole, toast, lang } = useApp();
  const navigate = useNavigate();
  const [busy, setBusy] = useState<"" | "full" | "live">("");

  const reset = async (mode: "full" | "live", go?: string) => {
    setBusy(mode);
    try {
      const r = await api.post<{ message: string }>("/api/demo/reset", { mode });
      toast(lang === "hi" ? (mode === "full" ? "डेमो डेटा बहाल किया गया।" : "लाइव रिकॉर्डिंग के लिए डेमो डेटा तैयार।") : r.data.message);
      if (go) {
        setRole("retailer");
        navigate(go);
      }
    } catch (e) {
      toast((e as ApiError).message, "error");
    } finally {
      setBusy("");
    }
  };

  const steps = lang === "hi" ? [
    "“लाइव रिकॉर्डिंग” मोड में रीसेट करें — DS-1042 रास्ते में होगा (50 बोरी पुष्टि, 50 बोरी भेजी)।",
    "रिटेलर के रूप में DS-1042 खोलें → “प्राप्ति दर्ज करें” → 48 लिखें → जाँचें → दर्ज करें।",
    "सिस्टम 2 बोरी का अंतर (DSC-2004) दर्ज करता है; टाइमलाइन में नई घटनाएँ दिखती हैं।",
    "“डिस्ट्रीब्यूटर के रूप में खोलें” → वही ऑर्डर → स्वीकार करें / नोट जोड़ें।",
    "वॉइस अनुभव में पूछें: “DS-1042 में क्या हुआ?” — MCP कॉल लाइव दिखती हैं।",
    "समाधान दर्ज करें: “बाकी 2 बोरी अगले डिस्पैच में” — मूल मात्राएँ वैसी ही रहती हैं।",
  ] : [
    "Reset in “live recording” mode — DS-1042 is in transit (50 bags confirmed, 50 dispatched).",
    "As the retailer, open DS-1042 → Record receipt → enter 48 → Review → Record receipt.",
    "The system flags a 2-bag short delivery (DSC-2004); new timeline events highlight.",
    "Click “Open as distributor” → same order → acknowledge / add a note.",
    "In the Voice experience ask “What happened to DS-1042?” — watch the MCP calls.",
    "Record a resolution: “Remaining 2 bags with next dispatch” — original quantities stay unchanged.",
  ];

  return (
    <div>
      <PageHeader eyebrow={<SampleTag />} title={t("Demo controls", "डेमो नियंत्रण")}
        subtitle={t("Administrative tools for presenting the prototype. Resetting replaces all orders with the synthetic sample dataset. This is a gateway admin action, not an MCP tool.", "प्रोटोटाइप दिखाने के प्रशासनिक टूल। रीसेट करने पर सारे ऑर्डर नमूना डेटा से बदल जाते हैं। यह गेटवे की एडमिन क्रिया है, MCP टूल नहीं।")} />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title={t("Load the DS-1042 story (recommended for recording)", "DS-1042 कहानी लोड करें (रिकॉर्डिंग के लिए)")} icon={<Clapperboard className="size-5" />}
            subtitle={t("DS-1042 starts in transit so you can record the 48-bag receipt live.", "DS-1042 रास्ते में शुरू होता है ताकि आप 48 बोरी की प्राप्ति लाइव दर्ज करें।")} />
          <div className="space-y-3 p-5">
            <Button size="lg" loading={busy === "live"} icon={<PlayCircle className="size-5" />} onClick={() => reset("live", "/app/orders/DS-1042")}>
              {t("Reset for live recording & open DS-1042", "लाइव रिकॉर्डिंग के लिए रीसेट करें और DS-1042 खोलें")}
            </Button>
            <p className="text-sm text-muted">{t("Dashboard after this reset: 12 orders · 5 in transit · 1 needs review · 6 delivered.", "इस रीसेट के बाद: 12 ऑर्डर · 5 रास्ते में · 1 जाँच ज़रूरी · 6 डिलीवर।")}</p>
          </div>
        </Card>
        <Card>
          <CardHeader title={t("Restore the full sample dataset", "पूरा नमूना डेटा बहाल करें")} icon={<Database className="size-5" />}
            subtitle={t("DS-1042 already shows 48 received and an acknowledged 2-bag discrepancy.", "DS-1042 में पहले से 48 प्राप्त और स्वीकार किया गया 2 बोरी का अंतर।")} />
          <div className="space-y-3 p-5">
            <Button size="lg" variant="secondary" loading={busy === "full"} icon={<RotateCcw className="size-5" />} onClick={() => reset("full", "/app")}>
              {t("Reset to full sample data", "पूरे नमूना डेटा पर रीसेट करें")}
            </Button>
            <p className="text-sm text-muted">{t("Dashboard after this reset: 12 orders · 4 in transit · 2 need review · 6 delivered.", "इस रीसेट के बाद: 12 ऑर्डर · 4 रास्ते में · 2 जाँच ज़रूरी · 6 डिलीवर।")}</p>
          </div>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader title={t("Suggested recording path", "रिकॉर्डिंग का सुझाया क्रम")} icon={<ListChecks className="size-5" />} />
          <ol className="list-decimal space-y-2 py-5 pl-10 pr-5 text-sm text-ink-soft">
            {steps.map((s) => <li key={s}>{s}</li>)}
          </ol>
          <p className="border-t border-line px-5 py-3 text-xs text-muted">{t("Command-line alternative: python -m app.seed live (from the backend folder). Full script: docs/demo-script.md.", "कमांड-लाइन विकल्प: backend फ़ोल्डर से python -m app.seed live। पूरी स्क्रिप्ट: docs/demo-script.md।")}</p>
        </Card>
      </div>
    </div>
  );
}
