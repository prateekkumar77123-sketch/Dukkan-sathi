import { ArrowDown, ArrowRight, Database, ExternalLink, Globe, Mic, PlugZap, Server, ShieldCheck, Smartphone, Speaker, Terminal } from "lucide-react";
import { Link } from "react-router-dom";
import { LanguageToggle, Logo } from "../components/Layout";
import { ConnectionIndicator } from "../components/mcp";
import { Badge, Card } from "../components/ui";
import { useApp } from "../lib/app";
import { PHOTOS } from "../lib/photos";
import { EXTRA_SOURCES, FACTS } from "../lib/sources";

function Box({ icon, title, sub, tone = "white" }: { icon: React.ReactNode; title: string; sub: string; tone?: "white" | "teal" | "amber" | "blue" }) {
  const tones = { white: "border-line bg-surface", teal: "border-[#bcdcd6] bg-teal-soft", amber: "border-[#f0d6a8] bg-amber-soft", blue: "border-[#c9dbf2] bg-blue-soft" };
  return (
    <div className={`rounded-xl border p-3 ${tones[tone]}`}>
      <p className="flex items-center gap-2 text-sm font-semibold">{icon}{title}</p>
      <p className="mt-1 text-xs text-muted">{sub}</p>
    </div>
  );
}

function Arrow({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center px-1 py-1 text-faint lg:py-0">
      <ArrowRight className="hidden size-5 lg:block" aria-hidden />
      <ArrowDown className="size-5 lg:hidden" aria-hidden />
      {label && <span className="text-center text-[10px] leading-tight">{label}</span>}
    </div>
  );
}

export function ArchitectureDiagram() {
  const { t } = useApp();
  return (
    <div className="space-y-4" role="img" aria-label={t("Architecture: website and voice clients call the API gateway, whose MCP client calls the MCP server over Streamable HTTP; the MCP server uses the business services and SQLite database.", "आर्किटेक्चर: वेबसाइट और वॉइस क्लाइंट API गेटवे को कॉल करते हैं, जिसका MCP क्लाइंट Streamable HTTP पर MCP सर्वर को कॉल करता है; MCP सर्वर व्यापार नियम और SQLite डेटाबेस इस्तेमाल करता है।")}>
      <div className="grid items-stretch gap-1 lg:grid-cols-[1fr_auto_1.2fr_auto_1.2fr_auto_1fr]">
        <div className="space-y-2">
          <Box icon={<Globe className="size-4 text-teal" />} title={t("React website", "React वेबसाइट")} sub={t(":5173 · dashboard, orders, assistant, voice demo (Web Speech API)", ":5173 · डैशबोर्ड, ऑर्डर, असिस्टेंट, वॉइस डेमो")} />
          <Box icon={<Speaker className="size-4 text-blue" />} tone="blue" title={t("Echo device (optional)", "Echo डिवाइस (वैकल्पिक)")} sub={t("Alexa custom skill, en-IN + hi-IN → HTTPS tunnel → /alexa", "Alexa कस्टम स्किल, en-IN + hi-IN → HTTPS टनल → /alexa")} />
        </div>
        <Arrow label="REST / JSON" />
        <Box icon={<Server className="size-4 text-teal" />} title={t("FastAPI API gateway :8000", "FastAPI API गेटवे :8000")}
          sub={t("Website API, bilingual assistant (rule-based), Alexa request verification, demo reset. Holds the tokens; the browser never speaks MCP.", "वेबसाइट API, द्विभाषी असिस्टेंट, Alexa अनुरोध सत्यापन, डेमो रीसेट। टोकन यहीं; ब्राउज़र MCP से सीधे बात नहीं करता।")} />
        <Arrow label={t("MCP client · Streamable HTTP · Bearer token · 2025-11-25", "MCP क्लाइंट · Streamable HTTP · टोकन · 2025-11-25")} />
        <Box icon={<PlugZap className="size-4 text-amber" />} tone="amber" title={t("MCP server :8001/mcp", "MCP सर्वर :8001/mcp")}
          sub={t("Official Python SDK (MCPServer). 15 typed tools with structured output. Token → role; DNS-rebinding protection; rate limit.", "आधिकारिक Python SDK। 15 टाइप्ड टूल। टोकन → भूमिका; सुरक्षा; रेट लिमिट।")} />
        <Arrow />
        <div className="space-y-2">
          <Box icon={<ShieldCheck className="size-4 text-teal" />} tone="teal" title={t("Business services", "व्यापार नियम")} sub={t("Units, conversions, state machine, comparison, permissions — deterministic", "इकाई, रूपांतरण, स्थिति, तुलना, अनुमति — पक्के नियम")} />
          <Box icon={<Database className="size-4 text-teal" />} tone="teal" title="SQLite" sub={t("Orders, lines, dispatches, receipts, discrepancies, resolutions, audit events", "ऑर्डर, लाइन, डिस्पैच, प्राप्ति, अंतर, समाधान, ऑडिट")} />
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <Box icon={<Terminal className="size-4" />} title={t("Any compatible MCP client", "कोई भी संगत MCP क्लाइंट")} sub={t("MCP Inspector, scripts/mcp_smoke_test.py, or a future approved Alexa+ connection can call the same /mcp endpoint with a token.", "MCP Inspector, स्क्रिप्ट, या भविष्य का Alexa+ कनेक्शन टोकन के साथ इसी /mcp से जुड़ सकता है।")} />
        <Box icon={<Smartphone className="size-4" />} title={t("One source of truth", "एक ही सच्चाई का स्रोत")} sub={t("Website, assistant, voice demo and Alexa all read and write through the same MCP tools and database.", "वेबसाइट, असिस्टेंट, वॉइस डेमो और Alexa सब एक ही MCP टूल और डेटाबेस से पढ़ते-लिखते हैं।")} />
      </div>
    </div>
  );
}

export default function About() {
  const { t, lang } = useApp();
  return (
    <div className="min-h-screen bg-ivory">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <Logo />
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden sm:inline-flex"><ConnectionIndicator /></span>
            <LanguageToggle />
            <Link to="/app" className="inline-flex h-10 items-center rounded-lg bg-teal px-4 text-sm font-medium text-white">{t("Open demo", "डेमो खोलें")}</Link>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl space-y-10 px-4 py-10 sm:px-6">
        <section>
          <Badge tone="teal">{t("About the project", "प्रोजेक्ट के बारे में")}</Badge>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">{t("A shared, verifiable record from order to delivery", "ऑर्डर से डिलीवरी तक एक साझा, जाँचने योग्य रिकॉर्ड")}</h1>
          <p className="mt-3 max-w-3xl text-lg text-ink-soft">{t("Dukaan Sathi is a hackathon prototype for small hardware retailers and building-material distributors in India. Both sides see the same record of what was requested, confirmed, dispatched, received and resolved. Natural-language and voice access make it easy to use; deterministic business rules keep the numbers right.",
            "दुकान साथी भारत के छोटे हार्डवेयर रिटेलर और बिल्डिंग मटीरियल डिस्ट्रीब्यूटर के लिए हैकाथॉन प्रोटोटाइप है। दोनों पक्ष एक ही रिकॉर्ड देखते हैं — क्या माँगा, किसकी पुष्टि हुई, क्या भेजा, क्या मिला और क्या समाधान हुआ। बोलकर या लिखकर पूछना आसान है; पक्के नियम संख्याएँ सही रखते हैं।")}</p>
        </section>

        <section id="architecture" className="scroll-mt-6">
          <h2 className="mb-4 text-2xl font-semibold tracking-tight">{t("Architecture", "आर्किटेक्चर")}</h2>
          <Card className="p-5"><ArchitectureDiagram /></Card>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            <Card className="p-5 text-sm text-ink-soft">
              <p className="font-semibold text-ink">{t("Why a gateway?", "गेटवे क्यों?")}</p>
              <p className="mt-1">{t("Browsers should not hold MCP credentials. The gateway owns the tokens, translates website actions into MCP tool calls, and returns the tool trace so the UI can show exactly which tool produced each result.", "ब्राउज़र में MCP टोकन नहीं होने चाहिए। गेटवे टोकन रखता है, वेबसाइट की हर क्रिया को MCP टूल कॉल में बदलता है, और टूल का ब्योरा लौटाता है।")}</p>
            </Card>
            <Card className="p-5 text-sm text-ink-soft">
              <p className="font-semibold text-ink">{t("Where AI fits", "AI कहाँ काम आता है")}</p>
              <p className="mt-1">{t("Language understanding turns “50 bori OPC 53 cement” into a structured request. It never decides whether a quantity is valid or how large a difference is — the MCP server's rules do. The demo runs a rule-based bilingual parser with no paid AI key.", "भाषा समझ “50 बोरी OPC 53 सीमेंट” को संरचित अनुरोध में बदलती है। मात्रा सही है या अंतर कितना है — यह MCP सर्वर के नियम तय करते हैं। डेमो बिना किसी पेड AI की के नियम-आधारित पार्सर से चलता है।")}</p>
            </Card>
            <Card className="p-5 text-sm text-ink-soft">
              <p className="font-semibold text-ink">{t("Alexa: what's real", "Alexa: क्या असली है")}</p>
              <p className="mt-1">{t("The web Voice Experience is an independent, Alexa-inspired simulator. The repo also contains an Alexa custom skill (en-IN and hi-IN) that a developer can connect to their own Echo in development mode; it calls the same MCP tools. Gated Alexa+ add-on tooling is not used.", "वेब वॉइस अनुभव एक स्वतंत्र, Alexa-प्रेरित सिम्युलेटर है। रिपॉज़िटरी में Alexa कस्टम स्किल (en-IN और hi-IN) भी है जिसे डेवलपर अपने Echo से डेवलपमेंट मोड में जोड़ सकता है; यह वही MCP टूल इस्तेमाल करती है। गेटेड Alexa+ टूल का उपयोग नहीं है।")}</p>
            </Card>
          </div>
        </section>

        <section>
          <h2 className="mb-4 text-2xl font-semibold tracking-tight">{t("Honest limitations", "सच्ची सीमाएँ")}</h2>
          <Card className="p-5">
            <ul className="grid list-disc gap-2 pl-5 text-sm text-ink-soft md:grid-cols-2">
              {(lang === "hi" ? [
                "एक काल्पनिक रिटेलर और एक काल्पनिक डिस्ट्रीब्यूटर; नमूना डेटा।",
                "डेमो भूमिकाएँ सिम्युलेटेड हैं — असली लॉगिन नहीं।",
                "लाइव GPS नहीं; ट्रैकिंग दर्ज घटनाओं पर आधारित।",
                "किसी असली डिस्ट्रीब्यूटर, बिलिंग या इन्वेंटरी सिस्टम से जुड़ाव नहीं।",
                "असिस्टेंट नियम-आधारित है; बाहरी LLM नहीं जुड़ा।",
                "प्रोडक्शन के लिए मज़बूत पहचान, प्रमाणीकरण और अनुमति ज़रूरी।",
              ] : [
                "One fictional retailer and one fictional distributor; synthetic data.",
                "Demo roles are simulated — not production authentication.",
                "No live GPS; tracking is milestone-based from recorded events.",
                "No integration with real distributor, billing or inventory systems.",
                "The assistant is rule-based; no external LLM is connected.",
                "Production use needs strong identity, authentication and authorization.",
              ]).map((x) => <li key={x}>{x}</li>)}
            </ul>
          </Card>
        </section>

        <section id="sources" className="scroll-mt-6">
          <h2 className="mb-4 text-2xl font-semibold tracking-tight">{t("Sources", "स्रोत")}</h2>
          <Card className="divide-y divide-line">
            {FACTS.map((f) => (
              <div key={f.id} className="p-4 text-sm">
                <p className="text-ink-soft"><b className="text-ink">{f.stat[lang]}</b> {f.claim[lang]}</p>
                <a href={f.url} target="_blank" rel="noreferrer" className="mt-1 inline-flex items-center gap-1 text-xs text-teal hover:underline">
                  <ExternalLink className="size-3" /> {f.publisher} — “{f.source}”
                </a>
              </div>
            ))}
            {EXTRA_SOURCES.map((s) => (
              <div key={s.url} className="p-4 text-sm">
                <a href={s.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-teal hover:underline"><ExternalLink className="size-3" />{s.label}</a>
              </div>
            ))}
          </Card>
          <h3 className="mb-3 mt-8 text-lg font-semibold">{t("Photo credits", "फ़ोटो श्रेय")}</h3>
          <Card className="divide-y divide-line">
            {Object.values(PHOTOS).map((p) => (
              <div key={p.key} className="flex flex-col gap-1 p-4 text-sm sm:flex-row sm:items-center sm:justify-between">
                <span className="text-ink-soft">{p.alt[lang]}</span>
                <a href={p.page} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs text-teal hover:underline"><ExternalLink className="size-3" />{p.credit} · Pexels License</a>
              </div>
            ))}
          </Card>
          <p className="mt-3 text-xs text-muted">{t("Stock photographs show real places but are not Dukaan Sathi customers or deployments. Full log: docs/sources-and-image-attributions.md.", "स्टॉक फ़ोटो असली जगहें दिखाते हैं, पर दुकान साथी के ग्राहक नहीं हैं। पूरा ब्योरा: docs/sources-and-image-attributions.md।")}</p>
        </section>
        <section className="flex flex-wrap gap-3">
          <Link to="/app/voice" className="inline-flex h-11 items-center gap-2 rounded-xl bg-teal px-5 font-medium text-white"><Mic className="size-4" />{t("Voice experience", "वॉइस अनुभव")}</Link>
          <Link to="/app/mcp" className="inline-flex h-11 items-center gap-2 rounded-xl border border-line-strong bg-surface px-5 font-medium"><PlugZap className="size-4" />{t("MCP console", "MCP कंसोल")}</Link>
        </section>
      </main>
    </div>
  );
}
