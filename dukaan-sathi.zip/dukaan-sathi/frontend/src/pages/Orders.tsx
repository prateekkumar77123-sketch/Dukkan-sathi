import { Filter, PackageSearch, PlusCircle, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { TraceStrip } from "../components/mcp";
import { OrderTable } from "../components/orders";
import { Button, Card, cx, EmptyState, ErrorState, inputClass, PageHeader, SampleTag, Spinner } from "../components/ui";
import { qs } from "../lib/api";
import { useApi, useApp } from "../lib/app";
import type { OrderListResult } from "../lib/types";

const FILTERS = [
  { key: "", en: "All", hi: "सभी" },
  { key: "pending_confirmation,confirmed", en: "Awaiting", hi: "बाकी" },
  { key: "in_transit", en: "In transit", hi: "रास्ते में" },
  { key: "needs_review", en: "Needs review", hi: "जाँच ज़रूरी" },
  { key: "delivered,resolved", en: "Delivered", hi: "डिलीवर" },
  { key: "draft", en: "Drafts", hi: "ड्राफ्ट" },
];

const CATEGORIES = ["", "Cement", "Steel", "Pipes", "Fasteners", "Finishes", "Electrical"];

export default function Orders() {
  const { t, lang, role } = useApp();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const status = params.get("status") ?? "";
  const category = params.get("category") ?? "";
  const [search, setSearch] = useState(params.get("search") ?? "");
  useEffect(() => {
    setSearch(params.get("search") ?? "");
  }, [params]);
  const path = `/api/orders${qs({ status, category, search: params.get("search") ?? "" })}`;
  const { data, error, loading, traces, reload } = useApi<OrderListResult>(path);

  const set = (k: string, v: string) => {
    const next = new URLSearchParams(params);
    if (v) next.set(k, v);
    else next.delete(k);
    setParams(next, { replace: true });
  };

  return (
    <div>
      <PageHeader
        eyebrow={<SampleTag />}
        title={t("Orders", "ऑर्डर")}
        subtitle={t("One shared record per order — the retailer and distributor see the same quantities and history.", "हर ऑर्डर का एक साझा रिकॉर्ड — रिटेलर और डिस्ट्रीब्यूटर दोनों एक जैसी मात्रा और इतिहास देखते हैं।")}
        actions={role === "retailer" ? <Button icon={<PlusCircle className="size-4" />} onClick={() => navigate("/app/orders/new")}>{t("New order", "नया ऑर्डर")}</Button> : undefined}
      />
      <Card>
        <div className="flex flex-col gap-3 border-b border-line p-4 lg:flex-row lg:items-center">
          <div className="flex flex-wrap gap-1.5" role="tablist" aria-label={t("Status filter", "स्थिति फ़िल्टर")}>
            {FILTERS.filter((f) => role === "retailer" || f.key !== "draft").map((f) => (
              <button
                key={f.key}
                role="tab"
                aria-selected={status === f.key}
                onClick={() => set("status", f.key)}
                className={cx("rounded-full border px-3 py-1.5 text-sm transition-colors",
                  status === f.key ? "border-teal bg-teal text-white" : "border-line-strong bg-surface text-ink-soft hover:bg-ivory-deep")}
              >
                {lang === "hi" ? f.hi : f.en}
              </button>
            ))}
          </div>
          <div className="flex flex-1 flex-col gap-2 sm:flex-row lg:justify-end">
            <label className="relative">
              <span className="sr-only">{t("Category", "श्रेणी")}</span>
              <Filter className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
              <select value={category} onChange={(e) => set("category", e.target.value)} className={cx(inputClass, "pl-9 sm:w-44")}>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c || t("All categories", "सभी श्रेणियाँ")}</option>)}
              </select>
            </label>
            <form onSubmit={(e) => { e.preventDefault(); set("search", search.trim()); }} className="relative sm:w-72" role="search">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} className={cx(inputClass, "pl-9")}
                placeholder={t("Order no. or product…", "ऑर्डर नंबर या उत्पाद…")} aria-label={t("Search", "खोजें")} />
            </form>
          </div>
        </div>
        {loading && <Spinner />}
        {error && <ErrorState error={error} onRetry={reload} />}
        {data && (
          <OrderTable
            orders={data.orders}
            empty={<EmptyState icon={<PackageSearch className="size-6" />} title={t("No orders match these filters", "इन फ़िल्टर से कोई ऑर्डर नहीं मिला")}
              action={<Button variant="secondary" onClick={() => setParams({})}>{t("Clear filters", "फ़िल्टर हटाएँ")}</Button>} />}
          />
        )}
        {data && <p className="border-t border-line px-5 py-3 text-xs text-muted">{t(`${data.count} order(s)`, `${data.count} ऑर्डर`)}</p>}
      </Card>
      <TraceStrip traces={traces} className="mt-4" />
    </div>
  );
}
