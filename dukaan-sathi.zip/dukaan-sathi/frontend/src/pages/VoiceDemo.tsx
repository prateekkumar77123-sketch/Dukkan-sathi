import { Bot, Keyboard, Loader2, Mic, MicOff, Radio, RotateCcw, Send, Speaker, Volume2, VolumeX } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { AssistantCards, ModeNote, useActionRouter, useConversation } from "../components/assistant";
import { ActivityFeed, ConnectionIndicator, TraceRow } from "../components/mcp";
import { LanguageToggle } from "../components/Layout";
import { Button, Card, CardHeader, cx, inputClass, SampleTag } from "../components/ui";
import { useApp } from "../lib/app";
import { listen, micErrorMessage, speak, speechRecognitionSupported, speechSynthesisSupported, stopSpeaking, type ListenHandle } from "../lib/speech";
import type { AssistantReply } from "../lib/types";

function Waveform({ active }: { active: boolean }) {
  return (
    <div className="flex h-10 items-center justify-center gap-1" aria-hidden>
      {Array.from({ length: 13 }).map((_, i) => (
        <span key={i} className={cx("w-1.5 rounded-full bg-white/80", active ? "wave-bar" : "")}
          style={{ height: active ? `${14 + ((i * 7) % 26)}px` : "6px", animationDelay: `${(i % 6) * 0.11}s` }} />
      ))}
    </div>
  );
}

export default function VoiceDemo() {
  const { t, lang, toast, role, activity } = useApp();
  const [tts, setTts] = useState(() => speechSynthesisSupported());
  const [speaking, setSpeaking] = useState(false);
  const ttsRef = useRef(tts);
  ttsRef.current = tts;
  const onReply = useCallback((r: AssistantReply) => {
    if (ttsRef.current && r.speech) {
      setSpeaking(speak(r.speech, r.lang, () => setSpeaking(false)));
    }
  }, []);
  const conv = useConversation("voice", onReply);
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [typed, setTyped] = useState("");
  const [noteFor, setNoteFor] = useState<{ orderId: string; discrepancyId: string } | null>(null);
  const [noteText, setNoteText] = useState("");
  const handle = useRef<ListenHandle | null>(null);
  const noteMode = useRef(false);
  const route = useActionRouter(conv, (orderId, discrepancyId) => { setNoteFor({ orderId, discrepancyId }); setNoteText(""); });
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    // block body on purpose: newer browsers return a Promise from scrollIntoView, which an effect must not return
    void endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [conv.messages.length, conv.busy]);
  useEffect(() => () => stopSpeaking(), []);

  const supported = speechRecognitionSupported();
  const alexaEvents = activity.filter((a) => a.source === "alexa");

  const startListening = (forNote = false) => {
    if (listening) { handle.current?.stop(); return; }
    stopSpeaking();
    noteMode.current = forNote;
    setInterim("");
    const h = listen(lang, {
      onInterim: (x) => (forNote ? setNoteText(x) : setInterim(x)),
      onFinal: (x) => {
        if (forNote) setNoteText(x);
        else { setInterim(""); conv.send(x); }
      },
      onError: (code) => toast(micErrorMessage(code, lang), "error"),
      onEnd: () => setListening(false),
    });
    if (h) { handle.current = h; setListening(true); }
  };

  const samples = lang === "hi"
    ? ["दुकान साथी, मेरी सीमेंट डिलीवरी चेक करो", "DS-1042 में क्या हुआ?", "किन ऑर्डर में कमी है?", "रास्ते में कौन से ऑर्डर हैं?", "मेरी दुकान का हिसाब बताओ"]
    : ["Dukaan Sathi, check my cement delivery.", "What happened to DS-1042?", "Which deliveries need attention?", "Which orders are on the way?", "Give me my shop summary"];

  const lastReply = [...conv.messages].reverse().find((m) => m.reply)?.reply;

  return (
    <div>
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="mb-2 flex items-center gap-2"><SampleTag /><ConnectionIndicator /></div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-[28px]">{t("Dukaan Sathi Voice Experience", "दुकान साथी वॉइस अनुभव")}</h1>
          <p className="mt-1 max-w-2xl text-muted">{t("An Alexa-inspired interactive demonstration of voice-enabled shop management. Independent prototype — not an Amazon product.", "आवाज़ से दुकान संभालने का Alexa-प्रेरित इंटरैक्टिव डेमो। स्वतंत्र प्रोटोटाइप — Amazon का उत्पाद नहीं।")}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <LanguageToggle />
          {speechSynthesisSupported() && (
            <Button variant="secondary" size="sm" icon={tts ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />} onClick={() => { setTts(!tts); stopSpeaking(); }} aria-pressed={tts}>
              {tts ? t("Voice replies on", "आवाज़ में जवाब चालू") : t("Voice replies off", "आवाज़ में जवाब बंद")}
            </Button>
          )}
          <Button variant="ghost" size="sm" icon={<RotateCcw className="size-4" />} onClick={() => { conv.reset(); stopSpeaking(); }}>{t("Reset", "रीसेट")}</Button>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-5">
        <div className="space-y-6 xl:col-span-3">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0b4f49] via-[#0f6b63] to-[#12403c] p-6 text-white shadow-lg sm:p-8">
            <div className="pointer-events-none absolute -right-20 -top-20 size-72 rounded-full bg-white/5" aria-hidden />
            <div className="pointer-events-none absolute -bottom-24 -left-10 size-72 rounded-full bg-[#e8a33d]/10" aria-hidden />
            <div className="relative flex flex-col items-center text-center">
              <p className="text-sm text-white/70">{role === "retailer" ? t("Speaking as Raj Hardware Store", "राज हार्डवेयर स्टोर के रूप में") : t("Speaking as Sharma Building Supplies", "शर्मा बिल्डिंग सप्लाइज़ के रूप में")} · {lang === "hi" ? "हिन्दी (hi-IN)" : "English (en-IN)"}</p>
              <button
                onClick={() => (supported ? startListening(false) : toast(t("Voice input isn't supported in this browser. Use Chrome or Edge, or type below.", "इस ब्राउज़र में आवाज़ इनपुट नहीं है। Chrome या Edge इस्तेमाल करें, या नीचे टाइप करें।"), "info"))}
                className={cx("mt-6 flex size-28 items-center justify-center rounded-full border-4 transition-all focus-visible:outline-white",
                  listening ? "listening border-white bg-white text-teal" : "border-white/30 bg-white/10 text-white hover:bg-white/20")}
                aria-label={listening ? t("Stop listening", "सुनना बंद करें") : t("Start speaking", "बोलना शुरू करें")}
                aria-pressed={listening}
              >
                {listening ? <MicOff className="size-11" /> : <Mic className="size-11" />}
              </button>
              <div className="mt-5"><Waveform active={listening || speaking} /></div>
              <p className="mt-3 min-h-[3.5rem] max-w-xl text-lg font-medium">
                {listening ? (interim || t("Listening…", "सुन रहा हूँ…")) : conv.busy ? <span className="inline-flex items-center gap-2 text-white/80"><Loader2 className="size-5 animate-spin" />{t("Checking the records over MCP…", "MCP से रिकॉर्ड देख रहा हूँ…")}</span>
                  : speaking ? <span className="inline-flex items-center gap-2"><Speaker className="size-5" />{t("Speaking…", "बोल रहा हूँ…")}</span>
                    : supported ? t("Tap the mic and ask about an order", "माइक दबाएँ और किसी ऑर्डर के बारे में पूछें") : t("Type below — voice input needs Chrome or Edge", "नीचे टाइप करें — आवाज़ के लिए Chrome या Edge चाहिए")}
              </p>
              <form className="mt-4 flex w-full max-w-xl gap-2" onSubmit={(e) => { e.preventDefault(); conv.send(typed); setTyped(""); }}>
                <label htmlFor="vtype" className="sr-only">{t("Type instead", "टाइप करें")}</label>
                <div className="relative flex-1">
                  <Keyboard className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-white/50" />
                  <input id="vtype" value={typed} onChange={(e) => setTyped(e.target.value)} autoComplete="off"
                    className="h-11 w-full rounded-xl border border-white/20 bg-white/10 pl-9 pr-3 text-sm text-white placeholder:text-white/50 focus:border-white/60 focus:outline-none"
                    placeholder={t("Or type: check my cement delivery", "या लिखें: मेरी सीमेंट डिलीवरी चेक करो")} />
                </div>
                <button type="submit" disabled={!typed.trim() || conv.busy} className="flex h-11 items-center gap-1.5 rounded-xl bg-white px-4 text-sm font-semibold text-teal disabled:opacity-50">
                  <Send className="size-4" /> {t("Send", "भेजें")}
                </button>
              </form>
              <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                <span className="self-center text-xs text-white/60">{t("Try:", "आज़माएँ:")}</span>
                {samples.map((s) => (
                  <button key={s} onClick={() => conv.send(s)} className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs text-white/90 hover:bg-white/20">{s}</button>
                ))}
              </div>
            </div>
          </div>

          <Card>
            <CardHeader title={t("Conversation", "बातचीत")} icon={<Bot className="size-5" />} />
            <div className="max-h-[620px] space-y-4 overflow-y-auto p-5" aria-live="polite">
              {conv.messages.length === 0 && <p className="py-6 text-center text-sm text-muted">{t("The transcript and answers appear here.", "बातचीत और जवाब यहाँ दिखेंगे।")}</p>}
              {conv.messages.map((m) => (
                <div key={m.id} className={cx("flex", m.from === "user" ? "justify-end" : "justify-start")}>
                  <div className={cx("max-w-[90%]", m.from === "user" && "text-right")}>
                    <p className="mb-1 text-[11px] font-medium uppercase tracking-wide text-faint">{m.from === "user" ? (role === "retailer" ? t("Retailer", "रिटेलर") : t("Distributor", "डिस्ट्रीब्यूटर")) : "Dukaan Sathi"}</p>
                    <div className={cx("inline-block rounded-2xl px-4 py-3 text-left", m.from === "user" ? "bg-ink text-white" : m.error ? "border border-[#f2c6c1] bg-red-soft text-red" : "border border-line bg-ivory text-ink text-[15px] leading-relaxed")}>
                      {m.text}
                    </div>
                    {m.reply && <AssistantCards reply={m.reply} onAction={route} busy={conv.busy} />}
                  </div>
                </div>
              ))}
              {noteFor && (
                <div className="rounded-xl border border-[#f0d6a8] bg-amber-soft p-4">
                  <p className="text-sm font-semibold text-amber">{t(`Record a note on ${noteFor.discrepancyId}`, `${noteFor.discrepancyId} पर नोट दर्ज करें`)}</p>
                  <textarea rows={2} className={cx(inputClass, "mt-2")} value={noteText} onChange={(e) => setNoteText(e.target.value)} aria-label={t("Note", "नोट")}
                    placeholder={t("e.g. Two bags were missing when the truck was unloaded.", "जैसे: ट्रक उतारते समय दो बोरी कम थीं।")} />
                  <div className="mt-2 flex flex-wrap gap-2">
                    {supported && <Button size="sm" variant="secondary" icon={<Mic className="size-4" />} onClick={() => startListening(true)}>{listening ? t("Stop", "रोकें") : t("Dictate", "बोलकर लिखें")}</Button>}
                    <Button size="sm" disabled={!noteText.trim()} onClick={() => { conv.confirm({ type: "add_note", discrepancy_id: noteFor.discrepancyId, note: noteText, order_id: noteFor.orderId }, t(`Save note: “${noteText}”`, `नोट सहेजें: “${noteText}”`)); setNoteFor(null); }}>{t("Save note", "नोट सहेजें")}</Button>
                    <Button size="sm" variant="ghost" onClick={() => setNoteFor(null)}>{t("Cancel", "रद्द करें")}</Button>
                  </div>
                </div>
              )}
              <div ref={endRef} />
            </div>
            <div className="border-t border-line px-5 py-3"><ModeNote /></div>
          </Card>
        </div>

        <div className="space-y-6 xl:col-span-2">
          <Card>
            <CardHeader title={t("MCP calls for the last answer", "पिछले जवाब की MCP कॉल")} icon={<Radio className="size-5" />}
              subtitle={t("Voice → API gateway → MCP client → Streamable HTTP → MCP server → SQLite", "आवाज़ → API गेटवे → MCP क्लाइंट → Streamable HTTP → MCP सर्वर → SQLite")} />
            <div className="px-5">
              {lastReply?.mcp.length ? <ul className="divide-y divide-line">{lastReply.mcp.map((x) => <TraceRow key={x.id} trace={x} />)}</ul>
                : <p className="py-6 text-sm text-muted">{t("Ask something to watch the tool calls.", "कुछ पूछें और टूल कॉल देखें।")}</p>}
            </div>
          </Card>
          <Card>
            <CardHeader title={t("Calls from a real Alexa device", "असली Alexa डिवाइस से कॉल")}
              subtitle={t("If you've connected the optional Alexa custom skill (see README), requests from your Echo appear here live.", "अगर आपने वैकल्पिक Alexa कस्टम स्किल जोड़ी है (README देखें), तो आपके Echo से आई कॉल यहाँ लाइव दिखेंगी।")} />
            <div className="max-h-80 overflow-y-auto px-5">
              {alexaEvents.length ? <ActivityFeed filterSource="alexa" limit={20} /> : <p className="py-6 text-sm text-muted">{t("No Alexa requests yet in this session.", "इस सत्र में अभी कोई Alexa अनुरोध नहीं।")}</p>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
