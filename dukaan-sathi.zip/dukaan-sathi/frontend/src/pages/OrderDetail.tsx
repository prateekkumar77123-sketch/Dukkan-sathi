import {
  AlertTriangle, ArrowLeft, ArrowLeftRight, Camera, ClipboardCheck, FileText, MessageSquareText, PackageCheck, Send,
  ShieldCheck, Truck,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { TraceStrip } from "../components/mcp";
import { DiscrepancyCard, QuantityFlow, TimelineList } from "../components/orders";
import {
  Badge, Button, Card, CardHeader, cx, ErrorState, Field, inputClass, Modal, SampleTag, Spinner, StatusBadge,
} from "../components/ui";
import { api, ApiError } from "../lib/api";
import { useApi, useApp } from "../lib/app";
import {
  dateOnly, dateTime, inr, localInputToIso, nowLocalInput, num, qty, RESOLUTION_LABEL, todayIST, unitLabel,
} from "../lib/format";
import type { ActionResult, Discrepancy, Order, Timeline, ToolTrace } from "../lib/types";

type ModalKind = null | "confirm" | "dispatch" | "receipt" | "resolve" | "note" | "report";

export default function OrderDetail() {
  const { id = "" } = useParams();
  const { t, lang, role, setRole, toast } = useApp();
  const orderQ = useApi<Order>(`/api/orders/${encodeURIComponent(id)}`);
  const timelineQ = useApi<Timeline>(`/api/orders/${encodeURIComponent(id)}/timeline`);
  const [modal, setModal] = useState<ModalKind>(null);
  const [activeDisc, setActiveDisc] = useState<Discrepancy | null>(null);
  const [lastTraces, setLastTraces] = useState<ToolTrace[]>([]);
  const [seenEventId, setSeenEventId] = useState<number | undefined>(undefined);
  const order = orderQ.data;

  useEffect(() => {
    if (timelineQ.data && seenEventId === undefined) {
      setSeenEventId(Math.max(0, ...timelineQ.data.events.map((e) => e.id)));
    }
  }, [timelineQ.data, seenEventId]);

  const after = (r: { data: ActionResult; mcp?: ToolTrace[] }) => {
    setLastTraces(r.mcp ?? []);
    orderQ.setData(r.data.order);
    timelineQ.reload();
    toast(lang === "hi" ? r.data.message_hi : r.data.message, r.data.discrepancies_created.length ? "error" : "ok");
    setModal(null);
  };

  if (orderQ.loading) return <Spinner label={t("Loading order via MCP…", "MCP से ऑर्डर लोड हो रहा है…")} />;
  if (orderQ.error || !order) {
    return (
      <div>
        <Link to="/app/orders" className="mb-4 inline-flex items-center gap-1 text-sm text-teal"><ArrowLeft className="size-4" /> {t("All orders", "सभी ऑर्डर")}</Link>
        <Card>{orderQ.error && <ErrorState error={orderQ.error} onRetry={orderQ.reload} />}</Card>
        <TraceStrip traces={orderQ.traces} className="mt-4" />
      </div>
    );
  }

  const can = (action: string) => order.allowed_actions[role]?.includes(action);
  const otherRole = role === "retailer" ? "distributor" : "retailer";
  const otherCan = (action: string) => order.allowed_actions[otherRole]?.includes(action);

  const primaryActions = (
    <div className="flex flex-wrap gap-2">
      {can("submit_order") && (
        <Button icon={<Send className="size-4" />} onClick={async () => {
          try { after(await api.post<ActionResult>(`/api/orders/${order.id}/submit`)); } catch (e) { toast((e as ApiError).message, "error"); }
        }}>{t("Submit to distributor", "डिस्ट्रीब्यूटर को भेजें")}</Button>
      )}
      {can("confirm_order") && <Button icon={<ClipboardCheck className="size-4" />} onClick={() => setModal("confirm")}>{t("Confirm quantities", "मात्रा की पुष्टि करें")}</Button>}
      {can("record_dispatch") && <Button icon={<Truck className="size-4" />} onClick={() => setModal("dispatch")}>{t("Record dispatch", "डिस्पैच दर्ज करें")}</Button>}
      {can("record_delivery") && <Button icon={<PackageCheck className="size-4" />} onClick={() => setModal("receipt")}>{t("Record receipt", "प्राप्ति दर्ज करें")}</Button>}
      {can("report_discrepancy") && <Button variant="secondary" icon={<AlertTriangle className="size-4" />} onClick={() => setModal("report")}>{t("Report a difference", "अंतर दर्ज करें")}</Button>}
    </div>
  );

  const waitingOnOther = ["submit_order", "confirm_order", "record_dispatch", "record_delivery"].find((a) => otherCan(a));

  return (
    <div>
      <Link to="/app/orders" className="mb-4 inline-flex items-center gap-1 text-sm text-teal hover:underline"><ArrowLeft className="size-4" /> {t("All orders", "सभी ऑर्डर")}</Link>
      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-3xl font-semibold tracking-tight">{order.id}</h1>
            <StatusBadge status={order.status} />
            {order.is_sample && <SampleTag />}
            {order.partially_confirmed && <Badge tone="amber">{t("Partially confirmed", "आंशिक पुष्टि")}</Badge>}
          </div>
          <p className="mt-1 text-muted">
            {lang === "hi" ? order.retailer.name_hi : order.retailer.name}
            <ArrowLeftRight className="mx-2 inline size-4 text-faint" aria-label="and" />
            {lang === "hi" ? order.distributor.name_hi : order.distributor.name} · {order.retailer.city}
          </p>
          <p className="mt-0.5 text-sm text-muted">{t("Created", "बना")} {dateTime(order.created_at, lang)} · {t("Value", "मूल्य")} {inr(order.total_value_inr)} <span className="text-faint">({t("illustrative prices", "उदाहरण दाम")})</span></p>
        </div>
        {primaryActions}
      </div>

      {(order.next_action || waitingOnOther) && order.status !== "resolved" && order.status !== "delivered" && (
        <div className={cx("mb-6 flex flex-col gap-3 rounded-2xl border px-5 py-4 sm:flex-row sm:items-center",
          order.status === "needs_review" ? "border-[#f2c6c1] bg-red-soft" : "border-[#f0d6a8] bg-amber-soft")}>
          <div className="flex-1">
            <p className={cx("font-semibold", order.status === "needs_review" ? "text-red" : "text-amber")}>{t("Next step", "अगला कदम")}</p>
            <p className="text-sm text-ink-soft">{lang === "hi" ? order.next_action_hi : order.next_action}</p>
          </div>
          {waitingOnOther && (
            <Button variant="secondary" size="sm" icon={<ArrowLeftRight className="size-4" />} onClick={() => { setRole(otherRole); toast(t("Switched demo role — same order, other party's view.", "डेमो भूमिका बदली — वही ऑर्डर, दूसरे पक्ष की नज़र से।"), "info"); }}>
              {otherRole === "distributor" ? t("Open as distributor", "डिस्ट्रीब्यूटर के रूप में खोलें") : t("Open as retailer", "रिटेलर के रूप में खोलें")}
            </Button>
          )}
        </div>
      )}

      {lastTraces.length > 0 && <TraceStrip traces={lastTraces} className="mb-6" />}

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="space-y-6 lg:col-span-3">
          <Card>
            <CardHeader title={t("Items and quantities", "आइटम और मात्रा")} subtitle={t("Each stage is recorded once and never overwritten.", "हर चरण एक बार दर्ज होता है और बदला नहीं जाता।")} />
            <div className="space-y-4 p-5">
              {order.lines.map((ln) => <QuantityFlow key={ln.line_id} line={ln} />)}
            </div>
          </Card>

          {order.discrepancies.length > 0 && (
            <Card>
              <CardHeader title={t("Discrepancies", "अंतर")} icon={<AlertTriangle className="size-5 text-red" />}
                subtitle={t("Linked to the exact order line. Originals stay intact; resolutions are added on top.", "सटीक ऑर्डर लाइन से जुड़ा। मूल रिकॉर्ड जस के तस; समाधान ऊपर से जोड़ा जाता है।")} />
              <div className="space-y-3 p-5">
                {order.discrepancies.map((d) => (
                  <DiscrepancyCard key={d.id} d={d} showOrderLink={false}>
                    {d.status !== "resolved" && (
                      <div className="mt-3 flex flex-wrap gap-2 border-t border-line pt-3">
                        <Button size="sm" variant="secondary" icon={<MessageSquareText className="size-4" />} onClick={() => { setActiveDisc(d); setModal("note"); }}>
                          {role === "distributor" && d.status === "open" ? t("Acknowledge / add note", "स्वीकार करें / नोट") : t("Add note", "नोट जोड़ें")}
                        </Button>
                        <Button size="sm" icon={<ShieldCheck className="size-4" />} onClick={() => { setActiveDisc(d); setModal("resolve"); }}>
                          {t("Record resolution", "समाधान दर्ज करें")}
                        </Button>
                      </div>
                    )}
                  </DiscrepancyCard>
                ))}
              </div>
            </Card>
          )}
        </div>

        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title={t("Fulfilment details", "पूर्ति विवरण")} icon={<FileText className="size-5" />} />
            <dl className="divide-y divide-line text-sm">
              <Row label={t("Requested delivery", "माँगी गई डिलीवरी")} value={dateOnly(order.requested_delivery_date, lang)} />
              {order.revised_delivery_date && <Row label={t("Revised delivery date", "नई डिलीवरी तारीख")} value={dateOnly(order.revised_delivery_date, lang)} />}
              {order.distributor_notes && <Row label={t("Distributor note", "डिस्ट्रीब्यूटर नोट")} value={order.distributor_notes} />}
              {order.notes && <Row label={t("Retailer note", "रिटेलर नोट")} value={order.notes} />}
              {order.dispatch ? (
                <>
                  <Row label={t("Delivery challan", "डिलीवरी चालान")} value={<span className="font-mono">{order.dispatch.challan_ref}</span>} />
                  {order.dispatch.eway_bill_ref && <Row label={t("E-way bill", "ई-वे बिल")} value={<span className="font-mono">{order.dispatch.eway_bill_ref}</span>} />}
                  <Row label={t("Dispatched", "डिस्पैच")} value={dateTime(order.dispatch.dispatched_at, lang)} />
                  <Row label={t("Expected delivery", "अपेक्षित डिलीवरी")} value={dateOnly(order.dispatch.expected_delivery_date, lang)} />
                  {order.dispatch.vehicle_ref && <Row label={t("Vehicle", "वाहन")} value={<span className="font-mono">{order.dispatch.vehicle_ref}</span>} />}
                  {order.dispatch.driver_note && <Row label={t("Carrier note", "वाहक नोट")} value={order.dispatch.driver_note} />}
                </>
              ) : <Row label={t("Dispatch", "डिस्पैच")} value={<span className="text-faint">{t("Not recorded yet", "अभी दर्ज नहीं")}</span>} />}
              {order.receipt ? (
                <>
                  <Row label={t("Received", "प्राप्त")} value={dateTime(order.receipt.received_at, lang)} />
                  {order.receipt.condition_notes && <Row label={t("Condition notes", "हालत नोट")} value={order.receipt.condition_notes} />}
                  {order.receipt.evidence_file && (
                    <Row label={t("Evidence", "सबूत")} value={<a href={`/api/uploads/${order.receipt.evidence_file}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-teal underline"><Camera className="size-4" />{t("View photo", "फ़ोटो देखें")}</a>} />
                  )}
                </>
              ) : <Row label={t("Receipt", "प्राप्ति")} value={<span className="text-faint">{t("Not recorded yet", "अभी दर्ज नहीं")}</span>} />}
            </dl>
            <p className="border-t border-line px-5 py-3 text-xs text-muted">{t("Tracking is milestone-based from recorded events. There is no live GPS in this prototype.", "ट्रैकिंग दर्ज घटनाओं पर आधारित है। इस प्रोटोटाइप में लाइव GPS नहीं है।")}</p>
          </Card>
          <Card>
            <CardHeader title={t("Audit timeline", "ऑडिट टाइमलाइन")} subtitle={order.is_sample ? t("Sample events are illustrative; new actions appear live.", "नमूना घटनाएँ उदाहरण हैं; नई कार्रवाई लाइव दिखती है।") : undefined} />
            <div className="px-5 pt-4">
              {timelineQ.data ? <TimelineList events={timelineQ.data.events} highlightNewerThan={seenEventId} /> : <Spinner />}
            </div>
          </Card>
        </div>
      </div>
      <TraceStrip traces={[...orderQ.traces, ...timelineQ.traces]} className="mt-6" />

      {modal === "confirm" && <ConfirmModal order={order} onClose={() => setModal(null)} onDone={after} />}
      {modal === "dispatch" && <DispatchModal order={order} onClose={() => setModal(null)} onDone={after} />}
      {modal === "receipt" && <ReceiptModal order={order} onClose={() => setModal(null)} onDone={after} />}
      {modal === "report" && <ReportModal order={order} onClose={() => setModal(null)} onDone={after} />}
      {modal === "note" && activeDisc && <NoteModal d={activeDisc} onClose={() => setModal(null)} onDone={after} />}
      {modal === "resolve" && activeDisc && <ResolveModal d={activeDisc} onClose={() => setModal(null)} onDone={after} />}
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="grid grid-cols-5 gap-3 px-5 py-2.5">
      <dt className="col-span-2 text-muted">{label}</dt>
      <dd className="col-span-3 text-ink-soft break-words">{value}</dd>
    </div>
  );
}

type Done = (r: { data: ActionResult; mcp?: ToolTrace[] }) => void;

function useSubmit(onDone: Done) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const run = async (path: string, body: unknown) => {
    setBusy(true);
    setError(null);
    try {
      onDone(await api.post<ActionResult>(path, body));
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setBusy(false);
    }
  };
  return { busy, error, run };
}

function FormError({ error }: { error: ApiError | null }) {
  const { lang, t } = useApp();
  if (!error) return null;
  return (
    <div className="mt-4 rounded-lg border border-[#f2c6c1] bg-red-soft px-3 py-2 text-sm text-red" role="alert">
      {lang === "hi" ? error.messageHi : error.message}
      {error.traces[0] && <div className="mt-1 text-xs opacity-80">{t("Rejected by MCP tool", "MCP टूल ने अस्वीकार किया")} <code>{error.traces[0].tool}</code> ({error.code})</div>}
    </div>
  );
}

function ConfirmModal({ order, onClose, onDone }: { order: Order; onClose: () => void; onDone: Done }) {
  const { t, lang } = useApp();
  const [values, setValues] = useState<Record<number, string>>(Object.fromEntries(order.lines.map((l) => [l.line_id, String(l.requested_qty)])));
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");
  const { busy, error, run } = useSubmit(onDone);
  return (
    <Modal open onClose={onClose} title={t(`Confirm ${order.id}`, `${order.id} की पुष्टि`)}
      footer={<>
        <Button variant="secondary" onClick={onClose}>{t("Cancel", "रद्द करें")}</Button>
        <Button loading={busy} icon={<ClipboardCheck className="size-4" />} onClick={() => run(`/api/orders/${order.id}/confirm`, {
          lines: order.lines.map((l) => ({ line_id: l.line_id, confirmed_qty: Number(values[l.line_id]) })),
          revised_delivery_date: date || null, notes: notes || null,
        })}>{t("Confirm order", "पुष्टि करें")}</Button>
      </>}>
      <p className="mb-4 text-sm text-muted">{t("Confirm the full quantity, or enter what you can actually supply. A lower number is recorded as a partial confirmation.", "पूरी मात्रा की पुष्टि करें, या जितना भेज सकते हैं वह लिखें। कम संख्या आंशिक पुष्टि मानी जाएगी।")}</p>
      <div className="space-y-3">
        {order.lines.map((l) => (
          <Field key={l.line_id} htmlFor={`c${l.line_id}`} label={`${lang === "hi" ? l.product_name_hi : l.product_name}`}
            hint={t(`Requested ${qty(l.requested_qty, l.unit, "en")}`, `माँगी गई ${qty(l.requested_qty, l.unit, "hi")}`)}>
            <div className="flex items-center gap-2">
              <input id={`c${l.line_id}`} type="number" min={0} max={l.requested_qty} step={l.unit === "kg" ? 0.5 : 1} className={inputClass}
                value={values[l.line_id]} onChange={(e) => setValues({ ...values, [l.line_id]: e.target.value })} />
              <span className="w-20 text-sm text-muted">{unitLabel(l.unit, 2, lang)}</span>
            </div>
          </Field>
        ))}
        <Field htmlFor="rdate" label={t("Revised delivery date (optional)", "नई डिलीवरी तारीख (वैकल्पिक)")}>
          <input id="rdate" type="date" min={todayIST()} className={inputClass} value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field htmlFor="cnotes" label={t("Note to retailer (optional)", "रिटेलर के लिए नोट (वैकल्पिक)")}>
          <textarea id="cnotes" rows={2} className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
      </div>
      <FormError error={error} />
    </Modal>
  );
}

function DispatchModal({ order, onClose, onDone }: { order: Order; onClose: () => void; onDone: Done }) {
  const { t, lang } = useApp();
  const [values, setValues] = useState<Record<number, string>>(Object.fromEntries(order.lines.map((l) => [l.line_id, String(l.confirmed_qty ?? 0)])));
  const [challan, setChallan] = useState(`SBS/DC/26-27/${order.id.replace("DS-", "0")}`);
  const [eway, setEway] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [driver, setDriver] = useState("");
  const [at, setAt] = useState(nowLocalInput());
  const [expected, setExpected] = useState(todayIST(1));
  const { busy, error, run } = useSubmit(onDone);
  const value = order.lines.reduce((a, l) => a + Number(values[l.line_id] || 0) * l.unit_price_inr, 0);
  return (
    <Modal open wide onClose={onClose} title={t(`Record dispatch — ${order.id}`, `डिस्पैच दर्ज करें — ${order.id}`)}
      footer={<>
        <Button variant="secondary" onClick={onClose}>{t("Cancel", "रद्द करें")}</Button>
        <Button loading={busy} icon={<Truck className="size-4" />} onClick={() => run(`/api/orders/${order.id}/dispatch`, {
          challan_ref: challan, lines: order.lines.map((l) => ({ line_id: l.line_id, dispatched_qty: Number(values[l.line_id]) })),
          dispatched_at: localInputToIso(at), expected_delivery_date: expected || null, eway_bill_ref: eway || null,
          vehicle_ref: vehicle || null, driver_note: driver || null,
        })}>{t("Record dispatch", "डिस्पैच दर्ज करें")}</Button>
      </>}>
      <div className="grid gap-4 sm:grid-cols-2">
        {order.lines.map((l) => (
          <Field key={l.line_id} htmlFor={`d${l.line_id}`} label={lang === "hi" ? l.product_name_hi : l.product_name}
            hint={t(`Confirmed ${qty(l.confirmed_qty, l.unit, "en")}`, `पुष्टि ${qty(l.confirmed_qty, l.unit, "hi")}`)}>
            <div className="flex items-center gap-2">
              <input id={`d${l.line_id}`} type="number" min={0} max={l.confirmed_qty ?? 0} className={inputClass} value={values[l.line_id]}
                onChange={(e) => setValues({ ...values, [l.line_id]: e.target.value })} />
              <span className="w-20 text-sm text-muted">{unitLabel(l.unit, 2, lang)}</span>
            </div>
          </Field>
        ))}
        <Field htmlFor="challan" label={t("Delivery challan / dispatch reference", "डिलीवरी चालान / डिस्पैच संदर्भ")}>
          <input id="challan" className={cx(inputClass, "font-mono")} value={challan} onChange={(e) => setChallan(e.target.value)} required />
        </Field>
        <Field htmlFor="eway" label={t("E-way bill no. (if applicable)", "ई-वे बिल नंबर (यदि लागू)")}
          hint={value > 50000 ? t(`Consignment ≈ ${inr(value)}: above ₹50,000 an e-way bill is generally required (CGST Rule 138; exemptions apply).`, `माल ≈ ${inr(value)}: ₹50,000 से ऊपर आम तौर पर ई-वे बिल ज़रूरी (CGST नियम 138; कुछ छूट)।`) : t(`Consignment ≈ ${inr(value)}`, `माल ≈ ${inr(value)}`)}>
          <input id="eway" className={cx(inputClass, "font-mono")} value={eway} onChange={(e) => setEway(e.target.value)} />
        </Field>
        <Field htmlFor="dat" label={t("Dispatched at (IST)", "डिस्पैच समय (IST)")}>
          <input id="dat" type="datetime-local" className={inputClass} value={at} onChange={(e) => setAt(e.target.value)} />
        </Field>
        <Field htmlFor="exp" label={t("Expected delivery date", "अपेक्षित डिलीवरी तारीख")}>
          <input id="exp" type="date" min={todayIST()} className={inputClass} value={expected} onChange={(e) => setExpected(e.target.value)} />
        </Field>
        <Field htmlFor="veh" label={t("Vehicle (optional)", "वाहन (वैकल्पिक)")}>
          <input id="veh" className={inputClass} value={vehicle} onChange={(e) => setVehicle(e.target.value)} placeholder="RJ14 XX 0000" />
        </Field>
        <Field htmlFor="drv" label={t("Carrier / driver note (optional)", "वाहक / ड्राइवर नोट (वैकल्पिक)")}>
          <input id="drv" className={inputClass} value={driver} onChange={(e) => setDriver(e.target.value)} />
        </Field>
      </div>
      <FormError error={error} />
    </Modal>
  );
}

function ReceiptModal({ order, onClose, onDone }: { order: Order; onClose: () => void; onDone: Done }) {
  const { t, lang } = useApp();
  const [received, setReceived] = useState<Record<number, string>>({});
  const [damaged, setDamaged] = useState<Record<number, string>>({});
  const [at, setAt] = useState(nowLocalInput());
  const [notes, setNotes] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [review, setReview] = useState(false);
  const [uploadErr, setUploadErr] = useState<string | null>(null);
  const { busy, error, run } = useSubmit(onDone);
  const missing = order.lines.some((l) => received[l.line_id] === undefined || received[l.line_id] === "");

  const submit = async () => {
    let evidence: string | null = null;
    if (file) {
      const form = new FormData();
      form.append("file", file);
      try {
        const r = await api.upload<{ file: string }>("/api/uploads", form);
        evidence = r.data.file;
      } catch (e) {
        setUploadErr((e as ApiError).message);
        return;
      }
    }
    await run(`/api/orders/${order.id}/receipt`, {
      lines: order.lines.map((l) => ({ line_id: l.line_id, received_qty: Number(received[l.line_id]), damaged_qty: Number(damaged[l.line_id] || 0) })),
      received_at: localInputToIso(at), condition_notes: notes || null, evidence_file: evidence,
    });
  };

  return (
    <Modal open wide onClose={onClose} title={review ? t("Review before recording", "दर्ज करने से पहले जाँचें") : t(`Record receipt — ${order.id}`, `प्राप्ति दर्ज करें — ${order.id}`)}
      footer={review ? <>
        <Button variant="secondary" onClick={() => setReview(false)}>{t("Back to edit", "वापस बदलें")}</Button>
        <Button loading={busy} icon={<PackageCheck className="size-4" />} onClick={submit}>{t("Record receipt", "प्राप्ति दर्ज करें")}</Button>
      </> : <>
        <Button variant="secondary" onClick={onClose}>{t("Cancel", "रद्द करें")}</Button>
        <Button disabled={missing} onClick={() => setReview(true)}>{t("Review", "जाँचें")}</Button>
      </>}>
      {!review ? (
        <div className="space-y-4">
          <p className="text-sm text-muted">{t("Count what actually arrived and enter it for every line. Enter damaged units separately — they are part of the received count.", "जो माल असल में आया उसे गिनकर हर लाइन में लिखें। क्षतिग्रस्त माल अलग से लिखें — वह प्राप्त गिनती का हिस्सा है।")}</p>
          {order.lines.map((l) => (
            <div key={l.line_id} className="rounded-xl border border-line p-4">
              <p className="font-medium">{lang === "hi" ? l.product_name_hi : l.product_name}</p>
              <p className="mb-3 text-xs text-muted">{t("Dispatched", "भेजी गई")}: {qty(l.dispatched_qty, l.unit, lang)}</p>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field htmlFor={`r${l.line_id}`} label={t(`Received (${unitLabel(l.unit, 2, "en")})`, `प्राप्त (${unitLabel(l.unit, 2, "hi")})`)}>
                  <input id={`r${l.line_id}`} type="number" min={0} step={l.unit === "kg" ? 0.5 : 1} className={cx(inputClass, "text-lg font-semibold")} value={received[l.line_id] ?? ""}
                    onChange={(e) => setReceived({ ...received, [l.line_id]: e.target.value })} placeholder={t("Count", "गिनती")} />
                </Field>
                <Field htmlFor={`g${l.line_id}`} label={t("Of which damaged", "इनमें क्षतिग्रस्त")}>
                  <input id={`g${l.line_id}`} type="number" min={0} className={inputClass} value={damaged[l.line_id] ?? ""}
                    onChange={(e) => setDamaged({ ...damaged, [l.line_id]: e.target.value })} placeholder="0" />
                </Field>
              </div>
            </div>
          ))}
          <div className="grid gap-4 sm:grid-cols-2">
            <Field htmlFor="rat" label={t("Received at (IST)", "प्राप्ति समय (IST)")}>
              <input id="rat" type="datetime-local" className={inputClass} value={at} onChange={(e) => setAt(e.target.value)} />
            </Field>
            <Field htmlFor="ev" label={t("Evidence photo (optional)", "सबूत फ़ोटो (वैकल्पिक)")} hint={t("JPEG, PNG or WebP, up to 5 MB", "JPEG, PNG या WebP, 5 MB तक")} error={uploadErr ?? undefined}>
              <input id="ev" type="file" accept="image/jpeg,image/png,image/webp" className="block w-full text-sm file:mr-3 file:rounded-lg file:border-0 file:bg-ivory-deep file:px-3 file:py-2"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            </Field>
          </div>
          <Field htmlFor="cond" label={t("Delivery condition notes", "डिलीवरी की हालत")}>
            <textarea id="cond" rows={2} className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)}
              placeholder={t("e.g. Counted at unloading. Bags dry and intact.", "जैसे: उतारते समय गिना। बोरियाँ सूखी और ठीक।")} />
          </Field>
        </div>
      ) : (
        <div className="space-y-3">
          {order.lines.map((l) => {
            const r = Number(received[l.line_id]);
            const diff = r - (l.dispatched_qty ?? 0);
            return (
              <div key={l.line_id} className={cx("rounded-xl border p-4", diff !== 0 ? "border-red bg-red-soft" : "border-[#bfe3d1] bg-[#e7f5ee]")}>
                <p className="font-medium">{lang === "hi" ? l.product_name_hi : l.product_name}</p>
                <p className="text-sm">
                  {t("Dispatched", "भेजी गई")} <b className="tabular">{num(l.dispatched_qty)}</b> · {t("Received", "प्राप्त")} <b className="tabular">{num(r)}</b>
                  {Number(damaged[l.line_id] || 0) > 0 && <> · {t("Damaged", "क्षतिग्रस्त")} <b>{damaged[l.line_id]}</b></>}
                </p>
                <p className={cx("mt-1 text-sm font-semibold", diff !== 0 ? "text-red" : "text-[#0b6b49]")}>
                  {diff === 0 ? t("Matches the dispatch record.", "डिस्पैच रिकॉर्ड से मेल खाता है।")
                    : diff < 0 ? t(`${qty(-diff, l.unit, "en")} below the dispatched quantity — a discrepancy will be opened.`, `डिस्पैच से ${qty(-diff, l.unit, "hi")} कम — अंतर दर्ज होगा।`)
                      : t(`${qty(diff, l.unit, "en")} above the dispatched quantity — a discrepancy will be opened.`, `डिस्पैच से ${qty(diff, l.unit, "hi")} अधिक — अंतर दर्ज होगा।`)}
                </p>
              </div>
            );
          })}
          <p className="text-xs text-muted">{t("This preview is for your review. The MCP server recomputes the comparison and records the result; it never assigns blame.", "यह झलक आपकी जाँच के लिए है। MCP सर्वर तुलना दोबारा करके परिणाम दर्ज करता है; किसी को दोष नहीं देता।")}</p>
        </div>
      )}
      <FormError error={error} />
    </Modal>
  );
}

function ReportModal({ order, onClose, onDone }: { order: Order; onClose: () => void; onDone: Done }) {
  const { t, lang } = useApp();
  const [line, setLine] = useState(order.lines[0].line_id);
  const [kind, setKind] = useState("damaged");
  const [quantity, setQuantity] = useState("1");
  const [desc, setDesc] = useState("");
  const { busy, error, run } = useSubmit(onDone);
  return (
    <Modal open onClose={onClose} title={t("Report a difference", "अंतर दर्ज करें")}
      footer={<>
        <Button variant="secondary" onClick={onClose}>{t("Cancel", "रद्द करें")}</Button>
        <Button loading={busy} onClick={() => run(`/api/orders/${order.id}/discrepancies`, { line_id: line, kind, quantity: Number(quantity), description: desc })}>{t("Record", "दर्ज करें")}</Button>
      </>}>
      <div className="space-y-3">
        <Field htmlFor="rl" label={t("Line", "लाइन")}>
          <select id="rl" className={inputClass} value={line} onChange={(e) => setLine(Number(e.target.value))}>
            {order.lines.map((l) => <option key={l.line_id} value={l.line_id}>{lang === "hi" ? l.product_name_hi : l.product_name}</option>)}
          </select>
        </Field>
        <Field htmlFor="rk" label={t("Type", "प्रकार")}>
          <select id="rk" className={inputClass} value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="damaged">{t("Damaged", "क्षतिग्रस्त")}</option>
            <option value="short">{t("Short", "कम")}</option>
            <option value="excess">{t("Excess", "अधिक")}</option>
            <option value="other">{t("Other", "अन्य")}</option>
          </select>
        </Field>
        <Field htmlFor="rq" label={t("Quantity", "मात्रा")}>
          <input id="rq" type="number" min={0} className={inputClass} value={quantity} onChange={(e) => setQuantity(e.target.value)} />
        </Field>
        <Field htmlFor="rd" label={t("What was observed?", "क्या देखा गया?")}>
          <textarea id="rd" rows={3} className={inputClass} value={desc} onChange={(e) => setDesc(e.target.value)} />
        </Field>
      </div>
      <FormError error={error} />
    </Modal>
  );
}

function NoteModal({ d, onClose, onDone }: { d: Discrepancy; onClose: () => void; onDone: Done }) {
  const { t, role } = useApp();
  const [note, setNote] = useState("");
  const [ack, setAck] = useState(role === "distributor" && d.status === "open");
  const { busy, error, run } = useSubmit(onDone);
  return (
    <Modal open onClose={onClose} title={t(`Note on ${d.id}`, `${d.id} पर नोट`)}
      footer={<>
        <Button variant="secondary" onClick={onClose}>{t("Cancel", "रद्द करें")}</Button>
        <Button loading={busy} disabled={!note.trim()} onClick={() => run(`/api/discrepancies/${d.id}/notes`, { note, acknowledge: ack })}>{t("Save note", "नोट सहेजें")}</Button>
      </>}>
      <Field htmlFor="note" label={t("Note", "नोट")}>
        <textarea id="note" rows={3} className={inputClass} value={note} onChange={(e) => setNote(e.target.value)}
          placeholder={t("e.g. Checking the loading register with the warehouse.", "जैसे: गोदाम के लोडिंग रजिस्टर से जाँच कर रहे हैं।")} />
      </Field>
      <label className="mt-3 flex items-center gap-2 text-sm">
        <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="size-4 accent-teal" />
        {t("Formally acknowledge this discrepancy", "इस अंतर को औपचारिक रूप से स्वीकार करें")}
      </label>
      <FormError error={error} />
    </Modal>
  );
}

function ResolveModal({ d, onClose, onDone }: { d: Discrepancy; onClose: () => void; onDone: Done }) {
  const { t, lang } = useApp();
  const [type, setType] = useState("supply_remaining");
  const [notes, setNotes] = useState(lang === "hi" ? `बाकी ${num(d.difference_qty)} ${d.unit_label_hi} अगले डिस्पैच के साथ भेजी जाएँगी।` : `Remaining ${num(d.difference_qty)} ${d.unit_label} to be supplied with the next dispatch.`);
  const [follow, setFollow] = useState(String(d.difference_qty));
  const { busy, error, run } = useSubmit(onDone);
  return (
    <Modal open onClose={onClose} title={t(`Record resolution — ${d.id}`, `समाधान दर्ज करें — ${d.id}`)}
      footer={<>
        <Button variant="secondary" onClick={onClose}>{t("Cancel", "रद्द करें")}</Button>
        <Button loading={busy} disabled={!notes.trim()} icon={<ShieldCheck className="size-4" />} onClick={() => run(`/api/discrepancies/${d.id}/resolve`, {
          resolution_type: type, notes, follow_up_qty: type === "supply_remaining" ? Number(follow) : null,
        })}>{t("Record resolution", "समाधान दर्ज करें")}</Button>
      </>}>
      <p className="mb-3 rounded-lg bg-ivory-deep px-3 py-2 text-sm text-ink-soft">{lang === "hi" ? d.description_hi : d.description}</p>
      <div className="space-y-3">
        <Field htmlFor="rt" label={t("Resolution", "समाधान")}>
          <select id="rt" className={inputClass} value={type} onChange={(e) => setType(e.target.value)}>
            {Object.entries(RESOLUTION_LABEL).map(([k, v]) => <option key={k} value={k}>{v[lang]}</option>)}
          </select>
        </Field>
        {type === "supply_remaining" && (
          <Field htmlFor="fq" label={t(`Quantity to supply (${d.unit_label})`, `भेजी जाने वाली मात्रा (${d.unit_label_hi})`)}>
            <input id="fq" type="number" min={0} className={inputClass} value={follow} onChange={(e) => setFollow(e.target.value)} />
          </Field>
        )}
        <Field htmlFor="rn" label={t("Decision and reason", "निर्णय और कारण")}>
          <textarea id="rn" rows={3} className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
      </div>
      <p className="mt-3 text-xs text-muted">{t("The original order, dispatch and receipt values stay exactly as recorded. “Under review” keeps the discrepancy open.", "मूल ऑर्डर, डिस्पैच और प्राप्ति की मात्राएँ वैसी ही रहती हैं। “जाँच जारी” से अंतर खुला रहता है।")}</p>
      <FormError error={error} />
    </Modal>
  );
}
