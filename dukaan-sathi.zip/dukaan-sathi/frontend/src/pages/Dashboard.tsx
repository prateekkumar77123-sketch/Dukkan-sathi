import { AlertTriangle, ArrowRight, CheckCircle2, ClipboardList, Hourglass, MessagesSquare, PackageCheck, PlusCircle, Truck } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { TraceStrip } from "../components/mcp";
import { OrderTable, StatusBar, TimelineList } from "../components/orders";
import { Button, Card, CardHeader, EmptyState, ErrorState, PageHeader, SampleTag, Spinner, StatusBadge } from "../components/ui";
import { useApi, useApp } from "../lib/app";
import { dateOnly, relative } from "../lib/format";
import type { Dashboard as DashboardT, OrderSummary } from "../lib/types";

function greeting(lang: "en" | "hi", name: string) {
  const hour = Number(new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kolkata", hour: "numeric", hour12: false }).format(new Date()));
  if (lang === "hi") return `नमस्ते ${name}, ${hour < 12 ? "सुप्रभात" : hour < 17 ? "शुभ दोपहर" : "शुभ संध्या"}।`;
  return `${hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening"}, ${name}.`;
}

function Metric({ label, value, icon, tone, to, hint }: { label: string; value: number; icon: React.ReactNode; tone: string; to: string; hint?: string }) {
  return (
    <Link to={to} className="group rounded-2xl border border-line bg-surface p-5 shadow-[0_1px_2px_rgba(31,35,40,0.04)] transition hover:border-line-strong hover:shadow-md">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted">{label}</span>
        <span className={`rounded-lg p-2 ${tone}`}>{icon}</span>
      </div>
      <div className="mt-3 text-4xl font-semibold tracking-tight tabular text-ink">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted">{hint}</div>}
      <div className="mt-3 inline-flex items-center gap-1 text-xs font-medium text-teal opacity-0 transition group-hover:opacity-100">
        View <ArrowRight className="size-3" />
      </div>
    </Link>
  );
}

function MiniList({ orders, emptyText }: { orders: OrderSummary[]; emptyText: string }) {
  const { lang } = useApp();
  if (!orders.length) return <p className="px-5 py-6 text-sm text-muted">{emptyText}</p>;
  return (
    <ul className="divide-y divide-line">
      {orders.map((o) => (
        <li key={o.id}>
          <Link to={`/app/orders/${o.id}`} className="flex items-center gap-3 px-5 py-3 hover:bg-ivory/80">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-semibold">{o.id}</span>
                <StatusBadge status={o.status} />
              </div>
              <p className="truncate text-sm text-muted">{lang === "hi" ? o.headline_hi : o.headline}</p>
            </div>
            <div className="text-right text-xs text-muted">
              {o.expected_delivery_date ? dateOnly(o.expected_delivery_date, lang) : relative(o.created_at, lang)}
            </div>
            <ArrowRight className="size-4 text-faint" />
          </Link>
        </li>
      ))}
    </ul>
  );
}

export default function Dashboard() {
  const { t, lang, role } = useApp();
  const navigate = useNavigate();
  const { data, error, loading, traces, reload } = useApi<DashboardT>("/api/dashboard");
  const name = role === "retailer" ? (lang === "hi" ? "राज" : "Raj") : (lang === "hi" ? "अनिल" : "Anil");

  return (
    <div>
      <PageHeader
        eyebrow={<div className="flex items-center gap-2"><SampleTag />{data && <span className="text-xs text-muted">{lang === "hi" ? data.party_name_hi : data.party_name} · {role === "retailer" ? t("Retailer", "रिटेलर") : t("Distributor", "डिस्ट्रीब्यूटर")}</span>}</div>}
        title={greeting(lang, name)}
        subtitle={role === "retailer" ? t("Here's your order activity with Sharma Building Supplies.", "शर्मा बिल्डिंग सप्लाइज़ के साथ आपके ऑर्डर की जानकारी।") : t("Here's incoming order activity from Raj Hardware Store.", "राज हार्डवेयर स्टोर से आए ऑर्डर की जानकारी।")}
        actions={
          <>
            {role === "retailer" && <Button icon={<PlusCircle className="size-4" />} onClick={() => navigate("/app/orders/new")}>{t("Create order", "ऑर्डर बनाएँ")}</Button>}
            <Button variant="secondary" icon={<MessagesSquare className="size-4" />} onClick={() => navigate("/app/assistant")}>{t("Ask Dukaan Sathi", "दुकान साथी से पूछें")}</Button>
          </>
        }
      />
      {loading && <Spinner label={t("Loading dashboard from MCP…", "MCP से डैशबोर्ड लोड हो रहा है…")} />}
      {error && <Card><ErrorState error={error} onRetry={reload} /></Card>}
      {data && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Metric label={t("Total orders", "कुल ऑर्डर")} value={data.total_orders} icon={<ClipboardList className="size-4" />} tone="bg-ivory-deep text-ink-soft" to="/app/orders"
              hint={data.drafts ? t(`+ ${data.drafts} unsent draft(s)`, `+ ${data.drafts} ड्राफ्ट`) : undefined} />
            <Metric label={t("In transit", "रास्ते में")} value={data.in_transit} icon={<Truck className="size-4" />} tone="bg-blue-soft text-blue" to="/app/orders?status=in_transit" />
            <Metric label={t("Need review", "जाँच ज़रूरी")} value={data.needs_review} icon={<AlertTriangle className="size-4" />} tone="bg-red-soft text-red" to="/app/discrepancies"
              hint={t(`${data.open_discrepancies} open difference(s)`, `${data.open_discrepancies} खुले अंतर`)} />
            <Metric label={t("Delivered", "डिलीवर")} value={data.delivered} icon={<PackageCheck className="size-4" />} tone="bg-[#e7f5ee] text-[#0b6b49]" to="/app/orders?status=delivered,resolved"
              hint={t(`${data.resolved} after a resolved difference`, `${data.resolved} में अंतर का समाधान हुआ`)} />
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader title={t("Orders requiring attention", "ध्यान देने वाले ऑर्डर")} icon={<AlertTriangle className="size-5 text-red" />}
                subtitle={t("Received quantity differs from the recorded dispatch, or damage was reported.", "प्राप्त मात्रा डिस्पैच से अलग है, या नुकसान दर्ज है।")}
                action={<Link to="/app/discrepancies" className="text-sm font-medium text-teal hover:underline">{t("All differences", "सभी अंतर")}</Link>} />
              <OrderTable orders={data.attention} empty={<EmptyState icon={<CheckCircle2 className="size-6" />} title={t("Nothing needs review", "कुछ भी जाँच के लिए नहीं")} body={t("Every recorded difference has a resolution.", "हर दर्ज अंतर का समाधान हो चुका है।")} />} />
            </Card>
            <Card>
              <CardHeader title={t("Status distribution", "स्थिति के अनुसार")} subtitle={t(`${data.total_orders} submitted orders`, `${data.total_orders} भेजे गए ऑर्डर`)} />
              <div className="p-5"><StatusBar d={data} /></div>
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader title={t("Shipments & deliveries", "शिपमेंट और डिलीवरी")} icon={<Truck className="size-5" />}
                subtitle={t("Milestone tracking from dispatch records — no live GPS.", "डिस्पैच रिकॉर्ड से माइलस्टोन ट्रैकिंग — लाइव GPS नहीं।")} />
              <MiniList orders={data.shipments} emptyText={t("No orders are confirmed or in transit.", "कोई ऑर्डर पुष्टि या रास्ते में नहीं है।")} />
            </Card>
            <Card>
              <CardHeader title={t("Pending confirmations", "पुष्टि बाकी")} icon={<Hourglass className="size-5 text-amber" />}
                subtitle={role === "retailer" ? t("Drafts and orders waiting for the distributor.", "ड्राफ्ट और डिस्ट्रीब्यूटर की पुष्टि का इंतज़ार।") : t("Requests waiting for your confirmation.", "आपकी पुष्टि का इंतज़ार कर रहे ऑर्डर।")} />
              <MiniList orders={data.pending_confirmations} emptyText={role === "retailer" ? t("Nothing waiting. New orders you submit appear here until the distributor confirms.", "कुछ बाकी नहीं। नए ऑर्डर पुष्टि होने तक यहाँ दिखेंगे।") : t("No requests waiting for confirmation.", "कोई ऑर्डर पुष्टि के इंतज़ार में नहीं।")} />
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-5">
            <Card className="lg:col-span-3">
              <CardHeader title={t("Recent orders", "हाल के ऑर्डर")} action={<Link to="/app/orders" className="text-sm font-medium text-teal hover:underline">{t("View all", "सभी देखें")}</Link>} />
              <OrderTable orders={data.recent_orders} />
            </Card>
            <Card className="lg:col-span-2">
              <CardHeader title={t("Recent activity", "हाल की गतिविधि")} subtitle={t("From the shared audit trail", "साझा ऑडिट रिकॉर्ड से")} />
              <div className="max-h-[440px] overflow-y-auto px-5 pt-4">
                <TimelineList events={data.recent_activity} />
              </div>
            </Card>
          </div>
          <TraceStrip traces={traces} />
        </div>
      )}
    </div>
  );
}
