export type Role = "retailer" | "distributor";
export type Lang = "en" | "hi";
export type OrderStatus =
  | "draft"
  | "pending_confirmation"
  | "confirmed"
  | "in_transit"
  | "delivered"
  | "needs_review"
  | "resolved";

export interface ToolTrace {
  id: number;
  at: string;
  tool: string;
  role: string;
  source: string;
  input_summary: string;
  ok: boolean;
  result_summary: string;
  error_code: string | null;
  elapsed_ms: number;
  protocol_version: string | null;
  transport: string;
  endpoint: string;
  is_write: boolean;
}

export interface ApiEnvelope<T> {
  data: T;
  mcp?: ToolTrace[];
}

export interface Party {
  id: string;
  name: string;
  name_hi: string;
  city: string;
  contact_name: string;
}

export interface Comparison {
  outcome: "match" | "short" | "excess" | "awaiting_dispatch" | "awaiting_receipt";
  comparable: boolean;
  dispatch_variance: number | null;
  receipt_variance: number | null;
  summary: string;
  summary_hi: string;
}

export interface OrderLine {
  line_id: number;
  line_no: number;
  sku: string;
  product_name: string;
  product_name_hi: string;
  category: string;
  spec: string;
  spec_hi: string;
  grade: string | null;
  size: string | null;
  unit: string;
  unit_label: string;
  unit_label_hi: string;
  requested_qty: number;
  confirmed_qty: number | null;
  dispatched_qty: number | null;
  received_qty: number | null;
  damaged_qty: number | null;
  unit_price_inr: number;
  line_value_inr: number;
  comparison: Comparison;
}

export interface DiscrepancyNote {
  author_role: string;
  author_name: string;
  kind: "note" | "acknowledgement";
  note: string;
  source: string;
  created_at: string;
}

export interface Resolution {
  resolution_type: string;
  follow_up_qty: number | null;
  notes: string;
  decided_by_role: string;
  decided_by_name: string;
  source: string;
  decided_at: string;
}

export interface Discrepancy {
  id: string;
  order_id: string;
  line_id: number;
  sku: string;
  product_name: string;
  product_name_hi: string;
  kind: "short" | "excess" | "damaged" | "other";
  expected_qty: number | null;
  observed_qty: number | null;
  difference_qty: number;
  unit: string;
  unit_label: string;
  unit_label_hi: string;
  status: "open" | "acknowledged" | "under_review" | "resolved";
  detected_by: string;
  detected_at: string;
  description: string;
  description_hi: string;
  attributed_to: string | null;
  notes: DiscrepancyNote[];
  resolutions: Resolution[];
}

export interface Order {
  id: string;
  status: OrderStatus;
  is_sample: boolean;
  retailer: Party;
  distributor: Party;
  created_at: string;
  submitted_at: string | null;
  confirmed_at: string | null;
  requested_delivery_date: string | null;
  revised_delivery_date: string | null;
  notes: string | null;
  distributor_notes: string | null;
  lines: OrderLine[];
  dispatch: {
    challan_ref: string;
    eway_bill_ref: string | null;
    vehicle_ref: string | null;
    driver_note: string | null;
    notes: string | null;
    dispatched_at: string;
    expected_delivery_date: string | null;
    recorded_by: string;
  } | null;
  receipt: {
    received_at: string;
    condition_notes: string | null;
    evidence_file: string | null;
    recorded_by: string;
  } | null;
  discrepancies: Discrepancy[];
  open_discrepancy_count: number;
  partially_confirmed: boolean;
  total_value_inr: number;
  headline: string;
  headline_hi: string;
  next_action: string | null;
  next_action_hi: string | null;
  allowed_actions: Record<Role, string[]>;
}

export interface OrderSummary {
  id: string;
  status: OrderStatus;
  is_sample: boolean;
  retailer_name: string;
  distributor_name: string;
  created_at: string;
  expected_delivery_date: string | null;
  headline: string;
  headline_hi: string;
  line_count: number;
  total_value_inr: number;
  open_discrepancy_count: number;
  categories: string[];
}

export interface TimelineEvent {
  id: number;
  at: string;
  actor_role: string;
  actor_name: string;
  event_type: string;
  summary: string;
  summary_hi: string;
  source: string;
  data: Record<string, unknown>;
}

export interface Timeline {
  order_id: string;
  status: OrderStatus;
  events: TimelineEvent[];
}

export interface Dashboard {
  role: Role;
  party_name: string;
  party_name_hi: string;
  is_sample_data: boolean;
  total_orders: number;
  in_transit: number;
  needs_review: number;
  delivered: number;
  resolved: number;
  pending_confirmation: number;
  confirmed_awaiting_dispatch: number;
  drafts: number;
  open_discrepancies: number;
  status_breakdown: { status: string; count: number }[];
  attention: OrderSummary[];
  pending_confirmations: OrderSummary[];
  shipments: OrderSummary[];
  recent_orders: OrderSummary[];
  recent_activity: TimelineEvent[];
  computed_at: string;
}

export interface Product {
  sku: string;
  name: string;
  name_hi: string;
  category: string;
  grade: string | null;
  size: string | null;
  spec: string;
  spec_hi: string;
  unit: string;
  unit_label: string;
  unit_label_hi: string;
  alt_unit: string | null;
  alt_per_unit: number | null;
  standard: string | null;
  hsn: string | null;
  gst_rate: number | null;
  price_inr: number;
  price_is_illustrative: boolean;
  available_qty: number;
  availability: "in_stock" | "low_stock" | "out_of_stock";
}

export interface LineValidation {
  line_no: number;
  sku: string;
  product_name: string | null;
  product_name_hi: string | null;
  spec: string | null;
  requested_qty: number;
  requested_unit: string;
  canonical_qty: number | null;
  unit: string | null;
  conversion_note: string | null;
  valid: boolean;
  availability: "available" | "partial" | "out_of_stock" | "unknown";
  available_qty: number | null;
  unit_price_inr: number | null;
  line_value_inr: number | null;
  messages: string[];
  messages_hi: string[];
}

export interface Validation {
  valid: boolean;
  fully_available: boolean;
  order_id: string | null;
  distributor_id: string;
  lines: LineValidation[];
  total_value_inr: number;
  summary: string;
  summary_hi: string;
}

export interface ActionResult {
  ok: boolean;
  message: string;
  message_hi: string;
  order: Order;
  discrepancies_created: string[];
}

export interface AssistantAction {
  type: string;
  [key: string]: unknown;
}

export interface AssistantCard {
  type: string;
  [key: string]: unknown;
}

export interface AssistantReply {
  lang: Lang;
  reply: string;
  speech: string;
  intent: string;
  cards: AssistantCard[];
  suggestions: { label: string; action: AssistantAction }[];
  context_order_id: string | null;
  pending_action: AssistantAction | null;
  mcp: ToolTrace[];
  error: { code: string; message: string; message_hi?: string } | null;
  mode: string;
}

export interface Health {
  gateway: string;
  mcp: {
    reachable: boolean;
    url: string;
    negotiated_protocol_version?: string;
    tool_count?: number;
    handshake_protocol_versions?: string[];
    modern_protocol_versions?: string[];
    client_mode?: string;
    error?: string;
  };
  assistant_mode: string;
  alexa: { endpoint: string; verify_signatures: boolean; skill_id_configured: boolean; role: string };
  data_version: number;
}

export interface OrderListResult {
  count: number;
  orders: OrderSummary[];
  filters_applied: Record<string, unknown>;
}
