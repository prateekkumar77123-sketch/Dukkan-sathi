/* External facts used on the website. Each entry records the claim exactly as we use it and the source that
   supports it. See docs/sources-and-image-attributions.md for the full research log. */

export interface Fact {
  id: string;
  stat: { en: string; hi: string };
  claim: { en: string; hi: string };
  source: string;
  publisher: string;
  url: string;
}

export const FACTS: Fact[] = [
  {
    id: "udyam",
    stat: { en: "7.83 crore+", hi: "7.83 करोड़+" },
    claim: {
      en: "enterprises registered on India's Udyam Registration Portal and Udyam Assist Platform since July 2020.",
      hi: "उद्यम रजिस्ट्रेशन पोर्टल और उद्यम असिस्ट प्लेटफ़ॉर्म पर जुलाई 2020 से पंजीकृत उद्यम।",
    },
    source: "Over 7.83 crore enterprises registered on Udyam Registration Portal (URP)",
    publisher: "Press Information Bureau, Ministry of MSME (2026)",
    url: "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2246892",
  },
  {
    id: "msme-gdp",
    stat: { en: "30.1%", hi: "30.1%" },
    claim: {
      en: "of India's GDP comes from the MSME sector, per the Union Minister for MSME.",
      hi: "भारत की GDP MSME क्षेत्र से आती है (केंद्रीय MSME मंत्री के अनुसार)।",
    },
    source: "MSME sector accounts for 30.1% of India's GDP, 35.4% of manufacturing and 45.73% of exports",
    publisher: "Press Information Bureau (2025)",
    url: "https://www.pib.gov.in/PressReleseDetailm.aspx?PRID=2142170",
  },
  {
    id: "gst-cement",
    stat: { en: "28% → 18%", hi: "28% → 18%" },
    claim: {
      en: "GST on cement from 22 September 2025, as recommended by the 56th GST Council meeting.",
      hi: "सीमेंट पर GST 22 सितंबर 2025 से, 56वीं GST परिषद की सिफ़ारिश पर।",
    },
    source: "Recommendations of the 56th Meeting of the GST Council",
    publisher: "Press Information Bureau, Ministry of Finance (Sept 2025)",
    url: "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2163555",
  },
  {
    id: "eway",
    stat: { en: "₹50,000", hi: "₹50,000" },
    claim: {
      en: "consignment value above which moving goods generally needs an e-way bill under CGST Rule 138 (exemptions apply).",
      hi: "इससे अधिक मूल्य के माल की ढुलाई पर CGST नियम 138 के तहत आम तौर पर ई-वे बिल ज़रूरी (कुछ छूट लागू)।",
    },
    source: "E-way Bill Rules (CGST Rule 138)",
    publisher: "Central Board of Indirect Taxes and Customs",
    url: "https://cbic-gst.gov.in/ewaybill-rules.html",
  },
  {
    id: "challan",
    stat: { en: "3 copies", hi: "3 प्रतियाँ" },
    claim: {
      en: "of a delivery challan under CGST Rule 55 — for the consignee, the transporter and the consignor. Three parties, three records of the same load.",
      hi: "CGST नियम 55 के तहत डिलीवरी चालान की — माल पाने वाले, ट्रांसपोर्टर और भेजने वाले के लिए। एक ही माल के तीन रिकॉर्ड।",
    },
    source: "CGST Rules, 2017 — Rule 55 (Transportation of goods without issue of invoice)",
    publisher: "Central Board of Indirect Taxes and Customs",
    url: "https://cbic-gst.gov.in/gst-invoice-rules.html",
  },
  {
    id: "bis",
    stat: { en: "IS 269 · IS 1786", hi: "IS 269 · IS 1786" },
    claim: {
      en: "BIS standards behind “OPC 53” cement and “Fe 500D” TMT bars — grade is part of the product, not a detail, so we store it explicitly.",
      hi: "“OPC 53” सीमेंट और “Fe 500D” सरिये के BIS मानक — ग्रेड उत्पाद का हिस्सा है, इसलिए हम इसे अलग से दर्ज करते हैं।",
    },
    source: "IS 269:2015 product manual; IS 1786:2008 product manual",
    publisher: "Bureau of Indian Standards",
    url: "https://www.bis.gov.in/wp-content/uploads/2020/07/PM-IS-1786-JULY-2020-Revised-4.pdf",
  },
];

export const EXTRA_SOURCES = [
  { label: "IS 269:2015 (Ordinary Portland Cement) product manual — Bureau of Indian Standards", url: "https://www.bis.gov.in/wp-content/uploads/2019/10/PM_IS_269.pdf" },
  { label: "Indian Cement Industry Analysis — IBEF (India is the world's second-largest cement producer)", url: "https://www.ibef.org/industry/cement-presentation" },
  { label: "Model Context Protocol specification 2025-11-25", url: "https://modelcontextprotocol.io/specification/2025-11-25" },
  { label: "MCP Python SDK documentation", url: "https://py.sdk.modelcontextprotocol.io/" },
  { label: "Alexa Skills Kit — Host a custom skill as a web service (request verification)", url: "https://developer.amazon.com/docs/custom-skills/host-a-custom-skill-as-a-web-service.html" },
  { label: "Alexa Skills Kit — How to update your Alexa skills for Hindi", url: "https://developer.amazon.com/en-IN/blogs/alexa/alexa-skills-kit/2019/07/how-to-update-your-alexa-skills-for-hindi" },
];
