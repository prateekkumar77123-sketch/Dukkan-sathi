import type { ApiEnvelope, Role, ToolTrace } from "./types";

export class ApiError extends Error {
  code: string;
  messageHi: string;
  status: number;
  traces: ToolTrace[];
  details: Record<string, unknown>;

  constructor(status: number, code: string, message: string, messageHi?: string, traces: ToolTrace[] = [], details = {}) {
    super(message);
    this.status = status;
    this.code = code;
    this.messageHi = messageHi ?? message;
    this.traces = traces;
    this.details = details;
  }
}

let currentRole: Role = "retailer";
export function setApiRole(role: Role) {
  currentRole = role;
}

async function request<T>(method: string, path: string, body?: unknown, roleOverride?: Role): Promise<ApiEnvelope<T>> {
  let res: Response;
  try {
    res = await fetch(path, {
      method,
      headers: {
        "X-Demo-Role": roleOverride ?? currentRole,
        ...(body !== undefined && !(body instanceof FormData) ? { "Content-Type": "application/json" } : {}),
      },
      body: body === undefined ? undefined : body instanceof FormData ? body : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, "gateway_unreachable", "Cannot reach the Dukaan Sathi API gateway on port 8000. Is it running?",
      "API गेटवे (पोर्ट 8000) से संपर्क नहीं हो पा रहा। क्या वह चल रहा है?");
  }
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const p = (payload ?? {}) as { error?: { code?: string; message?: string; message_hi?: string; details?: Record<string, unknown> }; detail?: unknown; mcp?: ToolTrace[] };
    const err = p.error ?? {};
    let message = err.message ?? `Request failed (${res.status})`;
    if (!p.error && p.detail) {
      message = typeof p.detail === "string" ? p.detail : "Some fields are invalid. Please check the form.";
    }
    if (res.status >= 500 && !p.error) {
      throw new ApiError(res.status, "gateway_unreachable", "The API gateway on port 8000 is not responding.", "API गेटवे जवाब नहीं दे रहा।");
    }
    throw new ApiError(res.status, err.code ?? "http_error", message, err.message_hi, p.mcp ?? [], err.details ?? {});
  }
  return payload as ApiEnvelope<T>;
}

export const api = {
  get: <T,>(path: string, role?: Role) => request<T>("GET", path, undefined, role),
  post: <T,>(path: string, body?: unknown, role?: Role) => request<T>("POST", path, body ?? {}, role),
  upload: <T,>(path: string, form: FormData) => request<T>("POST", path, form),
};

export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== "") sp.set(k, String(v));
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
}
