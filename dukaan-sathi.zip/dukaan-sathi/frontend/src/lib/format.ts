import type { Lang, OrderStatus } from "./types";

const TZ = "Asia/Kolkata";

const UNIT_LABELS: Record<string, { en: string; en_pl: string; hi: string }> = {
  bag: { en: "bag", en_pl: "bags", hi: "बोरी" },
  piece: { en: "piece", en_pl: "pieces", hi: "पीस" },
  length: { en: "length", en_pl: "lengths", hi: "लंबाई" },
  kg: { en: "kg", en_pl: "kg", hi: "किलो" },
  pack: { en: "pack", en_pl: "packs", hi: "पैकेट" },
  metre: { en: "metre", en_pl: "metres", hi: "मीटर" },
};

export function num(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return Number.isInteger(n) ? n.toLocaleString("en-IN") : n.toLocaleString("en-IN", { maximumFractionDigits: 1 });
}

export function unitLabel(unit: string, qty: number | null | undefined, lang: Lang): string {
  const u = UNIT_LABELS[unit];
  if (!u) return unit;
  if (lang === "hi") return u.hi;
  return qty === 1 ? u.en : u.en_pl;
}

export function qty(n: number | null | undefined, unit: string, lang: Lang): string {
  if (n === null || n === undefined) return "—";
  return `${num(n)} ${unitLabel(unit, n, lang)}`;
}

export function inr(n: number | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

function locale(lang: Lang) {
  return lang === "hi" ? "hi-IN" : "en-IN";
}

export function dateTime(ts: string | null | undefined, lang: Lang): string {
  if (!ts) return "—";
  const d = new Date(ts);
  return new Intl.DateTimeFormat(locale(lang), {
    timeZone: TZ, day: "numeric", month: "short", hour: "numeric", minute: "2-digit", numberingSystem: "latn",
  }).format(d);
}

export function timeOnly(ts: string, lang: Lang): string {
  return new Intl.DateTimeFormat(locale(lang), { timeZone: TZ, hour: "numeric", minute: "2-digit", numberingSystem: "latn" }).format(new Date(ts));
}

export function dayLabel(ts: string, lang: Lang): string {
  const d = new Date(ts);
  const key = (x: Date) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(x);
  const today = new Date();
  const yesterday = new Date(Date.now() - 86400000);
  if (key(d) === key(today)) return lang === "hi" ? "आज" : "Today";
  if (key(d) === key(yesterday)) return lang === "hi" ? "कल" : "Yesterday";
  return new Intl.DateTimeFormat(locale(lang), { timeZone: TZ, weekday: "short", day: "numeric", month: "short", numberingSystem: "latn" }).format(d);
}

export function dateOnly(d: string | null | undefined, lang: Lang): string {
  if (!d) return "—";
  const date = d.length === 10 ? new Date(`${d}T12:00:00+05:30`) : new Date(d);
  return new Intl.DateTimeFormat(locale(lang), { timeZone: TZ, day: "numeric", month: "short", year: "numeric", numberingSystem: "latn" }).format(date);
}

export function relative(ts: string, lang: Lang): string {
  const diff = (Date.now() - new Date(ts).getTime()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(locale(lang), { numeric: "auto" });
  if (diff < 60) return rtf.format(-Math.round(diff), "second");
  if (diff < 3600) return rtf.format(-Math.round(diff / 60), "minute");
  if (diff < 86400) return rtf.format(-Math.round(diff / 3600), "hour");
  return rtf.format(-Math.round(diff / 86400), "day");
}

export function todayIST(offsetDays = 0): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(new Date(Date.now() + offsetDays * 86400000));
}

export function nowLocalInput(): string {
  // value for <input type="datetime-local"> in IST
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false,
  }).formatToParts(new Date());
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  return `${get("year")}-${get("month")}-${get("day")}T${get("hour") === "24" ? "00" : get("hour")}:${get("minute")}`;
}

export function localInputToIso(v: string): string | undefined {
  if (!v) return undefined;
  return `${v}:00+05:30`;
}

export const STATUS_META: Record<OrderStatus, { en: string; hi: string; tone: "neutral" | "amber" | "blue" | "teal" | "red" | "green" }> = {
  draft: { en: "Draft", hi: "ड्राफ्ट", tone: "neutral" },
  pending_confirmation: { en: "Awaiting confirmation", hi: "पुष्टि बाकी", tone: "amber" },
  confirmed: { en: "Confirmed", hi: "पुष्टि हुई", tone: "amber" },
  in_transit: { en: "In transit", hi: "रास्ते में", tone: "blue" },
  delivered: { en: "Delivered", hi: "डिलीवर", tone: "green" },
  needs_review: { en: "Needs review", hi: "जाँच ज़रूरी", tone: "red" },
  resolved: { en: "Delivered · resolved", hi: "डिलीवर · समाधान हुआ", tone: "teal" },
};

export const SOURCE_LABEL: Record<string, { en: string; hi: string }> = {
  web: { en: "Website", hi: "वेबसाइट" },
  assistant: { en: "Assistant", hi: "असिस्टेंट" },
  voice: { en: "Voice demo", hi: "वॉइस डेमो" },
  alexa: { en: "Alexa (Echo)", hi: "Alexa (Echo)" },
  mcp: { en: "MCP client", hi: "MCP क्लाइंट" },
  system: { en: "Automatic check", hi: "स्वचालित जाँच" },
};

export const RESOLUTION_LABEL: Record<string, { en: string; hi: string }> = {
  supply_remaining: { en: "Remaining quantity to be supplied", hi: "बाकी मात्रा भेजी जाएगी" },
  credit_note: { en: "Credit / adjustment agreed", hi: "क्रेडिट / समायोजन पर सहमति" },
  under_review: { en: "Quantity difference under review", hi: "अंतर की जाँच चल रही है" },
  no_adjustment: { en: "No adjustment required", hi: "कोई समायोजन ज़रूरी नहीं" },
  other: { en: "Other agreed resolution", hi: "अन्य सहमत समाधान" },
};

export const KIND_LABEL: Record<string, { en: string; hi: string }> = {
  short: { en: "Short delivery", hi: "कम डिलीवरी" },
  excess: { en: "Excess delivery", hi: "अधिक डिलीवरी" },
  damaged: { en: "Damaged quantity", hi: "क्षतिग्रस्त माल" },
  other: { en: "Other difference", hi: "अन्य अंतर" },
};

export const DISC_STATUS_LABEL: Record<string, { en: string; hi: string }> = {
  open: { en: "Open", hi: "खुला" },
  acknowledged: { en: "Acknowledged", hi: "स्वीकार किया" },
  under_review: { en: "Under review", hi: "जाँच जारी" },
  resolved: { en: "Resolved", hi: "समाधान हुआ" },
};
