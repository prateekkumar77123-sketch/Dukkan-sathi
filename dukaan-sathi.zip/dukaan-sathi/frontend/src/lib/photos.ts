/* Real photographs from Pexels (Pexels License: free to use, attribution not required — we credit anyway).
   A local copy is used when present (run scripts/fetch-photos.ps1); otherwise the Pexels CDN; otherwise an
   illustrated fallback. These are stock photos of real places, not Dukaan Sathi customers or deployments.
   Full attribution: docs/sources-and-image-attributions.md */

export interface PhotoInfo {
  key: string;
  local: string;
  remote: string;
  page: string;
  credit: string;
  place?: string;
  alt: { en: string; hi: string };
}

const cdn = (id: number) => `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=1600`;

export const PHOTOS: Record<string, PhotoInfo> = {
  shop: {
    key: "shop",
    local: "/images/photos/hardware-shop.jpg",
    remote: cdn(19756443),
    page: "https://www.pexels.com/photo/man-working-at-hardware-store-19756443/",
    credit: "vijesh vijayan / Pexels",
    alt: { en: "A shopkeeper arranging tools inside a busy hardware store", hi: "एक व्यस्त हार्डवेयर दुकान में औज़ार सजाते दुकानदार" },
  },
  truck: {
    key: "truck",
    local: "/images/photos/truck-with-sacks.jpg",
    remote: cdn(15733306),
    page: "https://www.pexels.com/photo/truck-filled-with-sacks-15733306/",
    credit: "Pexels contributor (see source page)",
    place: "Bagbahara, Chhattisgarh",
    alt: { en: "A goods truck loaded with sacks in Bagbahara, India", hi: "बागबाहरा (भारत) में बोरियों से लदा मालवाहक ट्रक" },
  },
  cement: {
    key: "cement",
    local: "/images/photos/cement-bags.jpg",
    remote: cdn(29519165),
    page: "https://www.pexels.com/photo/stack-of-cement-bags-in-warehouse-setting-29519165/",
    credit: "Pexels contributor (see source page)",
    alt: { en: "Cement bags stacked in a warehouse", hi: "गोदाम में रखी सीमेंट की बोरियाँ" },
  },
  storefront: {
    key: "storefront",
    local: "/images/photos/hardware-storefront.jpg",
    remote: cdn(29151932),
    page: "https://www.pexels.com/photo/old-hardware-storefront-with-tools-and-supplies-29151932/",
    credit: "Pexels contributor (see source page)",
    alt: { en: "A shopkeeper at a hardware store window lined with tools and supplies", hi: "औज़ारों और सामान से भरी हार्डवेयर दुकान की खिड़की पर दुकानदार" },
  },
  site: {
    key: "site",
    local: "/images/photos/construction-delhi.jpg",
    remote: cdn(30580529),
    page: "https://www.pexels.com/photo/construction-worker-renovating-interior-in-delhi-30580529/",
    credit: "Pexels contributor (see source page)",
    place: "Delhi",
    alt: { en: "A construction worker renovating an interior in Delhi", hi: "दिल्ली में एक भवन के अंदर मरम्मत करता निर्माण मज़दूर" },
  },
  market: {
    key: "market",
    local: "/images/photos/indian-market.jpg",
    remote: cdn(16747112),
    page: "https://www.pexels.com/photo/traditional-indian-market-16747112/",
    credit: "Pexels contributor (see source page)",
    alt: { en: "A traditional Indian market street", hi: "एक पारंपरिक भारतीय बाज़ार" },
  },
};
