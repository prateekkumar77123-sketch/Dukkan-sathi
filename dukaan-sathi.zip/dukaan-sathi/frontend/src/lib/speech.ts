import type { Lang } from "./types";

/* Browser speech helpers. Recognition uses the Web Speech API where available (Chrome / Edge);
   everything degrades to typed input when it is not. */

interface RecognitionLike {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
}

type RecognitionCtor = new () => RecognitionLike;

function ctor(): RecognitionCtor | null {
  const w = window as unknown as { SpeechRecognition?: RecognitionCtor; webkitSpeechRecognition?: RecognitionCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function speechRecognitionSupported(): boolean {
  return typeof window !== "undefined" && ctor() !== null;
}

export function speechSynthesisSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export interface ListenHandle {
  stop: () => void;
}

export function listen(
  lang: Lang,
  handlers: { onInterim: (text: string) => void; onFinal: (text: string) => void; onError: (code: string) => void; onEnd: () => void },
): ListenHandle | null {
  const C = ctor();
  if (!C) return null;
  const rec = new C();
  rec.lang = lang === "hi" ? "hi-IN" : "en-IN";
  rec.interimResults = true;
  rec.continuous = false;
  rec.maxAlternatives = 1;
  let finalSent = false;
  rec.onresult = (e) => {
    let interim = "";
    let final = "";
    for (let i = 0; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) final += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (final && !finalSent) {
      finalSent = true;
      handlers.onFinal(final.trim());
    } else if (interim) {
      handlers.onInterim(interim.trim());
    }
  };
  rec.onerror = (e) => handlers.onError(e.error);
  rec.onend = () => handlers.onEnd();
  try {
    rec.start();
  } catch {
    handlers.onError("start-failed");
    return null;
  }
  return { stop: () => rec.stop() };
}

export function speak(text: string, lang: Lang, onEnd?: () => void): boolean {
  if (!speechSynthesisSupported()) return false;
  const synth = window.speechSynthesis;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text.replace(/DS-(\d+)/g, (_, d: string) => `D S ${d.split("").join(" ")}`));
  u.lang = lang === "hi" ? "hi-IN" : "en-IN";
  const voices = synth.getVoices();
  const voice = voices.find((v) => v.lang === u.lang) ?? voices.find((v) => v.lang.startsWith(lang === "hi" ? "hi" : "en-IN"))
    ?? voices.find((v) => v.lang.startsWith(lang === "hi" ? "hi" : "en"));
  if (voice) u.voice = voice;
  u.rate = lang === "hi" ? 0.95 : 1;
  u.onend = () => onEnd?.();
  synth.speak(u);
  return true;
}

export function stopSpeaking() {
  if (speechSynthesisSupported()) window.speechSynthesis.cancel();
}

export function micErrorMessage(code: string, lang: Lang): string {
  const map: Record<string, [string, string]> = {
    "not-allowed": ["Microphone permission was blocked. You can type your request instead.", "माइक्रोफ़ोन की अनुमति नहीं मिली। आप अपना सवाल टाइप कर सकते हैं।"],
    "service-not-allowed": ["Speech recognition is not allowed in this browser. Please type instead.", "इस ब्राउज़र में आवाज़ पहचान की अनुमति नहीं है। कृपया टाइप करें।"],
    "no-speech": ["I didn't hear anything. Tap the mic and try again, or type.", "कुछ सुनाई नहीं दिया। माइक दबाकर फिर बोलें, या टाइप करें।"],
    "network": ["Speech recognition needs an internet connection in this browser. Please type instead.", "आवाज़ पहचान के लिए इंटरनेट चाहिए। कृपया टाइप करें।"],
    "audio-capture": ["No microphone was found. Please type your request.", "माइक्रोफ़ोन नहीं मिला। कृपया टाइप करें।"],
  };
  const [en, hi] = map[code] ?? ["Voice input stopped. You can type your request.", "आवाज़ इनपुट रुक गया। आप टाइप कर सकते हैं।"];
  return lang === "hi" ? hi : en;
}
