import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { api, ApiError, setApiRole } from "./api";
import type { Health, Lang, Role, ToolTrace } from "./types";

interface AppState {
  role: Role;
  setRole: (r: Role) => void;
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (en: string, hi: string) => string;
  health: Health | null;
  healthError: string | null;
  activity: ToolTrace[];
  dataVersion: number;
  refreshHealth: () => void;
  toast: (message: string, tone?: "ok" | "error" | "info") => void;
  toasts: { id: number; message: string; tone: "ok" | "error" | "info" }[];
}

const Ctx = createContext<AppState | null>(null);

function stored<T extends string>(key: string, fallback: T, allowed: readonly T[]): T {
  try {
    const v = localStorage.getItem(key) as T | null;
    return v && allowed.includes(v) ? v : fallback;
  } catch {
    return fallback;
  }
}

function persist(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* storage unavailable (private mode) - the setting simply isn't remembered */
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [role, setRoleState] = useState<Role>(() => stored("ds.role", "retailer", ["retailer", "distributor"] as const));
  const [lang, setLangState] = useState<Lang>(() => stored("ds.lang", "en", ["en", "hi"] as const));
  const [health, setHealth] = useState<Health | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);
  const [activity, setActivity] = useState<ToolTrace[]>([]);
  const [dataVersion, setDataVersion] = useState(0);
  const [toasts, setToasts] = useState<AppState["toasts"]>([]);
  const lastId = useRef(0);

  setApiRole(role);

  const setRole = useCallback((r: Role) => {
    setApiRole(r);
    setRoleState(r);
    persist("ds.role", r);
  }, []);
  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    persist("ds.lang", l);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const t = useCallback((en: string, hi: string) => (lang === "hi" ? hi : en), [lang]);

  const refreshHealth = useCallback(() => {
    api.get<Health>("/api/health").then(
      (r) => {
        setHealth(r as unknown as Health);
        setHealthError(null);
      },
      (e: ApiError) => {
        setHealth(null);
        setHealthError(e.message);
      },
    );
  }, []);

  useEffect(() => {
    refreshHealth();
    const id = setInterval(refreshHealth, 15000);
    return () => clearInterval(id);
  }, [refreshHealth]);

  useEffect(() => {
    let alive = true;
    const poll = async () => {
      try {
        const r = await api.get<{ events: ToolTrace[]; data_version: number }>(`/api/mcp/activity?after=${lastId.current}`);
        if (!alive) return;
        const events = r.data.events;
        if (events.length) {
          lastId.current = events[events.length - 1].id;
          setActivity((prev) => [...prev, ...events].slice(-150));
        }
        setDataVersion((v) => (v === r.data.data_version ? v : r.data.data_version));
      } catch {
        /* gateway down: the status indicator shows it */
      }
    };
    poll();
    const id = setInterval(poll, 2000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  const toast = useCallback((message: string, tone: "ok" | "error" | "info" = "ok") => {
    const id = Date.now() + Math.random();
    setToasts((p) => [...p, { id, message, tone }]);
    setTimeout(() => setToasts((p) => p.filter((x) => x.id !== id)), 4800);
  }, []);

  const value = useMemo(
    () => ({ role, setRole, lang, setLang, t, health, healthError, activity, dataVersion, refreshHealth, toast, toasts }),
    [role, setRole, lang, setLang, t, health, healthError, activity, dataVersion, refreshHealth, toast, toasts],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp outside AppProvider");
  return v;
}

/** Fetch through the gateway; refetches when the role changes or when any write happens (including from Alexa). */
export function useApi<T>(path: string | null, deps: unknown[] = []) {
  const { role, dataVersion } = useApp();
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState<boolean>(!!path);
  const [traces, setTraces] = useState<ToolTrace[]>([]);
  const [tick, setTick] = useState(0);
  const firstLoad = useRef(true);

  useEffect(() => {
    firstLoad.current = true;
  }, [path, role]);

  useEffect(() => {
    if (!path) return;
    let alive = true;
    if (firstLoad.current) setLoading(true);
    api.get<T>(path).then(
      (r) => {
        if (!alive) return;
        setData(r.data);
        setTraces(r.mcp ?? []);
        setError(null);
        setLoading(false);
        firstLoad.current = false;
      },
      (e: ApiError) => {
        if (!alive) return;
        setError(e);
        setTraces(e.traces);
        setLoading(false);
      },
    );
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, role, dataVersion, tick, ...deps]);

  return { data, error, loading, traces, reload: () => setTick((x) => x + 1), setData };
}
