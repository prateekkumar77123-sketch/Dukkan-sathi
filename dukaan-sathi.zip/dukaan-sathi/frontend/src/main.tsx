import "@fontsource-variable/inter";
import "@fontsource/noto-sans-devanagari/400.css";
import "@fontsource/noto-sans-devanagari/500.css";
import "@fontsource/noto-sans-devanagari/600.css";
import "./index.css";
import { StrictMode, lazy, Suspense } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import { AppLayout } from "./components/Layout";
import { Spinner } from "./components/ui";
import { AppProvider, useApp } from "./lib/app";
import Landing from "./pages/Landing";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const Orders = lazy(() => import("./pages/Orders"));
const OrderDetail = lazy(() => import("./pages/OrderDetail"));
const CreateOrder = lazy(() => import("./pages/CreateOrder"));
const Distributor = lazy(() => import("./pages/Distributor"));
const Discrepancies = lazy(() => import("./pages/Discrepancies"));
const Assistant = lazy(() => import("./pages/Assistant"));
const VoiceDemo = lazy(() => import("./pages/VoiceDemo"));
const Catalogue = lazy(() => import("./pages/Catalogue"));
const McpConsole = lazy(() => import("./pages/McpConsole"));
const DemoControls = lazy(() => import("./pages/DemoControls"));
const About = lazy(() => import("./pages/About"));

function NotFound() {
  const { t } = useApp();
  return (
    <div className="py-20 text-center">
      <p className="text-2xl font-semibold">{t("Page not found", "पेज नहीं मिला")}</p>
      <Link to="/app" className="mt-4 inline-block text-teal underline">{t("Go to dashboard", "डैशबोर्ड पर जाएँ")}</Link>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <AppProvider>
      <BrowserRouter>
        <Suspense fallback={<Spinner />}>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/about" element={<About />} />
            <Route path="/app" element={<AppLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="orders" element={<Orders />} />
              <Route path="orders/new" element={<CreateOrder />} />
              <Route path="orders/:id" element={<OrderDetail />} />
              <Route path="distributor" element={<Distributor />} />
              <Route path="discrepancies" element={<Discrepancies />} />
              <Route path="assistant" element={<Assistant />} />
              <Route path="voice" element={<VoiceDemo />} />
              <Route path="catalogue" element={<Catalogue />} />
              <Route path="mcp" element={<McpConsole />} />
              <Route path="demo" element={<DemoControls />} />
              <Route path="*" element={<NotFound />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </AppProvider>
  </StrictMode>,
);
