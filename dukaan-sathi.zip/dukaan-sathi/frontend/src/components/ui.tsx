import { AlertTriangle, CheckCircle2, Info, Loader2, RefreshCw, X } from "lucide-react";
import { useEffect, useRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { useApp } from "../lib/app";
import { STATUS_META } from "../lib/format";
import type { OrderStatus } from "../lib/types";

export function cx(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

type Variant = "primary" | "secondary" | "ghost" | "danger" | "amber";

export function Button({
  variant = "primary", size = "md", loading, icon, children, className, ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" | "lg"; loading?: boolean; icon?: ReactNode }) {
  const styles: Record<Variant, string> = {
    primary: "bg-teal text-white hover:bg-teal-deep shadow-sm",
    secondary: "bg-surface text-ink border border-line-strong hover:bg-ivory-deep",
    ghost: "text-ink-soft hover:bg-ivory-deep",
    danger: "bg-red text-white hover:bg-[#931c13]",
    amber: "bg-amber text-white hover:bg-[#87480a]",
  };
  const sizes = { sm: "h-8 px-3 text-sm gap-1.5", md: "h-10 px-4 text-sm gap-2", lg: "h-12 px-6 text-base gap-2" };
  return (
    <button
      className={cx(
        "inline-flex items-center justify-center rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap",
        styles[variant], sizes[size], className,
      )}
      disabled={loading || rest.disabled}
      {...rest}
    >
      {loading ? <Loader2 className="size-4 animate-spin" aria-hidden /> : icon}
      {children}
    </button>
  );
}

export function Card({ children, className, ...rest }: { children: ReactNode; className?: string } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx("rounded-2xl border border-line bg-surface shadow-[0_1px_2px_rgba(31,35,40,0.04)]", className)} {...rest}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, action, icon }: { title: ReactNode; subtitle?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-line px-5 py-4">
      <div className="flex items-start gap-3 min-w-0">
        {icon && <div className="mt-0.5 text-teal">{icon}</div>}
        <div className="min-w-0">
          <h2 className="font-semibold text-ink">{title}</h2>
          {subtitle && <p className="text-sm text-muted mt-0.5">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

const TONES = {
  neutral: "bg-ivory-deep text-ink-soft border-line-strong",
  amber: "bg-amber-soft text-amber border-[#f0d6a8]",
  blue: "bg-blue-soft text-blue border-[#c9dbf2]",
  teal: "bg-teal-soft text-teal border-[#bcdcd6]",
  green: "bg-[#e7f5ee] text-[#0b6b49] border-[#bfe3d1]",
  red: "bg-red-soft text-red border-[#f2c6c1]",
};

export function Badge({ tone = "neutral", children, className }: { tone?: keyof typeof TONES; children: ReactNode; className?: string }) {
  return (
    <span className={cx("inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap", TONES[tone], className)}>
      {children}
    </span>
  );
}

export function StatusBadge({ status }: { status: OrderStatus }) {
  const { lang } = useApp();
  const meta = STATUS_META[status];
  const dot = { neutral: "bg-faint", amber: "bg-amber", blue: "bg-blue", teal: "bg-teal", green: "bg-[#0e8a5f]", red: "bg-red" }[meta.tone];
  return (
    <Badge tone={meta.tone}>
      <span className={cx("size-1.5 rounded-full", dot)} aria-hidden />
      {lang === "hi" ? meta.hi : meta.en}
    </Badge>
  );
}

export function SampleTag({ className }: { className?: string }) {
  const { t } = useApp();
  return (
    <span
      className={cx("inline-flex items-center gap-1 rounded-md border border-dashed border-line-strong bg-ivory px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide text-muted", className)}
      title={t("Fictional businesses and synthetic orders for demonstration", "डेमो के लिए काल्पनिक व्यापार और नमूना ऑर्डर")}
    >
      {t("Demo data", "डेमो डेटा")}
    </span>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-muted" role="status">
      <Loader2 className="size-5 animate-spin" aria-hidden />
      <span className="text-sm">{label}</span>
    </div>
  );
}

export function EmptyState({ icon, title, body, action }: { icon?: ReactNode; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center text-center px-6 py-10">
      {icon && <div className="mb-3 rounded-full bg-ivory-deep p-3 text-muted">{icon}</div>}
      <p className="font-medium text-ink">{title}</p>
      {body && <p className="mt-1 max-w-sm text-sm text-muted">{body}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ error, onRetry }: { error: { message: string; messageHi?: string; code?: string }; onRetry?: () => void }) {
  const { t, lang } = useApp();
  return (
    <div className="m-4 flex items-start gap-3 rounded-xl border border-[#f2c6c1] bg-red-soft p-4 text-sm text-red" role="alert">
      <AlertTriangle className="size-5 shrink-0" aria-hidden />
      <div className="flex-1">
        <p className="font-medium">{lang === "hi" ? error.messageHi ?? error.message : error.message}</p>
        {error.code && <p className="mt-0.5 text-xs opacity-80">{t("Error code", "त्रुटि कोड")}: {error.code}</p>}
      </div>
      {onRetry && (
        <Button variant="secondary" size="sm" onClick={onRetry} icon={<RefreshCw className="size-3.5" />}>
          {t("Retry", "फिर कोशिश करें")}
        </Button>
      )}
    </div>
  );
}

export function Field({ label, hint, children, htmlFor, error }: { label: string; hint?: string; children: ReactNode; htmlFor: string; error?: string }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block text-sm font-medium text-ink-soft mb-1.5">{label}</label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-muted">{hint}</p>}
      {error && <p className="mt-1 text-xs text-red">{error}</p>}
    </div>
  );
}

export const inputClass =
  "w-full rounded-lg border border-line-strong bg-surface px-3 py-2 text-sm text-ink placeholder:text-faint focus:border-teal focus:outline-none focus:ring-2 focus:ring-teal/20";

export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    ref.current?.querySelector<HTMLElement>("input, textarea, select, button")?.focus();
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-ink/40 p-0 sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" className={cx("w-full rounded-t-2xl sm:rounded-2xl bg-surface shadow-xl max-h-[92vh] flex flex-col", wide ? "sm:max-w-3xl" : "sm:max-w-lg")}>
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <h2 className="font-semibold text-lg">{title}</h2>
          <button onClick={onClose} className="rounded-lg p-1.5 text-muted hover:bg-ivory-deep" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-line px-5 py-3 bg-ivory/60 rounded-b-2xl">{footer}</div>}
      </div>
    </div>
  );
}

export function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="fixed right-4 top-20 z-[60] flex w-[min(92vw,380px)] flex-col gap-2" aria-live="polite">
      {toasts.map((x) => (
        <div
          key={x.id}
          className={cx(
            "flex items-start gap-2 rounded-xl border px-4 py-3 text-sm shadow-lg bg-surface",
            x.tone === "ok" && "border-[#bfe3d1]",
            x.tone === "error" && "border-[#f2c6c1]",
            x.tone === "info" && "border-line",
          )}
        >
          {x.tone === "ok" && <CheckCircle2 className="size-4 mt-0.5 text-[#0b6b49] shrink-0" />}
          {x.tone === "error" && <AlertTriangle className="size-4 mt-0.5 text-red shrink-0" />}
          {x.tone === "info" && <Info className="size-4 mt-0.5 text-blue shrink-0" />}
          <span>{x.message}</span>
        </div>
      ))}
    </div>
  );
}

export function PageHeader({ title, subtitle, actions, eyebrow }: { title: ReactNode; subtitle?: ReactNode; actions?: ReactNode; eyebrow?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        {eyebrow && <div className="mb-2">{eyebrow}</div>}
        <h1 className="text-2xl sm:text-[28px] font-semibold tracking-tight text-ink">{title}</h1>
        {subtitle && <p className="mt-1 text-muted max-w-2xl">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
