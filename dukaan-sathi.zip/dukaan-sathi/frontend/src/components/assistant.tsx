import { AlertTriangle, ArrowRight, Check, CheckCircle2, ClipboardList, PackageCheck, Truck, X } from "lucide-react";
import { useCallback, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, ApiError } from "../lib/api";
import { useApp } from "../lib/app";
import { inr, num, qty } from "../lib/format";
import type { AssistantAction, AssistantCard, AssistantReply, Dashboard, Discrepancy, Order, OrderSummary, Product, Timeline, ToolTrace, Validation } from "../lib/types";
import { TimelineList } from "./orders";
import { Badge, Button, cx, StatusBadge } from "./ui";

export interface ChatMessage {
  id: number;
  from: "user" | "assistant";
  text: string;
  reply?: AssistantReply;
  error?: boolean;
}

export function useConversation(source: "assistant" | "voice", onReply?: (r: AssistantReply) => void) {
  const { lang } = useApp();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [contextOrderId, setContextOrderId] = useState<string | null>(null);
  const [lastMessage, setLastMessage] = useState<string>("");
  const [traces, setTraces] = useState<ToolTrace[]>([]);

  const push = (m: Omit<ChatMessage, "id">) => setMessages((p) => [...p, { ...m, id: Date.now() + Math.random() }]);

  const handle = useCallback((r: AssistantReply) => {
    push({ from: "assistant", text: r.reply, reply: r });
    setTraces(r.mcp);
    if (r.context_order_id) setContextOrderId(r.context_order_id);
    onReply?.(r);
  }, [onReply]);

  const call = useCallback(async (path: string, body: Record<string, unknown>) => {
    setBusy(true);
    try {
      const r = await api.post<AssistantReply>(path, { lang, source, ...body });
      handle(r.data);
    } catch (e) {
      const err = e as ApiError;
      push({ from: "assistant", text: lang === "hi" ? err.messageHi : err.message, error: true });
    } finally {
      setBusy(false);
    }
  }, [lang, source, handle]);

  const send = useCallback(async (text: string, selection?: Record<string, unknown>) => {
    if (!text.trim() && !selection) return;
    push({ from: "user", text });
    setLastMessage(text);
    await call("/api/assistant", { message: text, context_order_id: contextOrderId, selection });
  }, [call, contextOrderId]);

  const confirm = useCallback(async (action: AssistantAction, label: string) => {
    push({ from: "user", text: label });
    await call("/api/assistant/confirm", { action });
  }, [call]);

  const timeline = useCallback(async (orderId: string, label: string) => {
    push({ from: "user", text: label });
    await call("/api/assistant/timeline", { order_id: orderId });
  }, [call]);

  const retry = useCallback(() => send(lastMessage), [send, lastMessage]);
  const reset = () => { setMessages([]); setContextOrderId(null); setTraces([]); };

  return { messages, busy, send, confirm, timeline, retry, reset, traces, contextOrderId, push };
}

function OrderMini({ order }: { order: Order }) {
  const { t, lang } = useApp();
  return (
    <div className="rounded-xl border border-line bg-surface p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link to={`/app/orders/${order.id}`} className="font-semibold text-ink hover:text-teal">{order.id}</Link>
        <StatusBadge status={order.status} />
      </div>
      {order.lines.map((l) => {
        const v = l.comparison.receipt_variance;
        return (
          <div key={l.line_id} className="mt-2">
            <p className="text-sm font-medium">{lang === "hi" ? l.product_name_hi : l.product_name}</p>
            <dl className="mt-1 grid grid-cols-4 gap-1 text-center text-xs">
              {[
                [t("Confirmed", "पुष्टि"), l.confirmed_qty],
                [t("Dispatched", "भेजी"), l.dispatched_qty],
                [t("Received", "मिली"), l.received_qty],
              ].map(([label, value]) => (
                <div key={label as string} className="rounded-lg bg-ivory px-1 py-1.5">
                  <dt className="text-muted">{label}</dt>
                  <dd className="text-base font-semibold tabular">{value === null ? "—" : num(value as number)}</dd>
                </div>
              ))}
              <div className={cx("rounded-lg px-1 py-1.5", v && v !== 0 ? "bg-red-soft text-red" : "bg-[#e7f5ee] text-[#0b6b49]")}>
                <dt className={v && v !== 0 ? "" : "text-[#0b6b49]/80"}>{t("Difference", "अंतर")}</dt>
                <dd className="text-base font-semibold tabular">{v === null ? "—" : v === 0 ? "0" : `${v > 0 ? "+" : ""}${num(v)}`}</dd>
              </div>
            </dl>
            <p className="mt-1 text-[11px] text-muted">{t("Unit", "इकाई")}: {qty(l.requested_qty, l.unit, lang).split(" ").slice(1).join(" ")}</p>
          </div>
        );
      })}
      {order.open_discrepancy_count > 0 && (
        <p className="mt-2 flex items-center gap-1 text-xs font-medium text-red"><AlertTriangle className="size-3.5" />{order.discrepancies.filter((d) => d.status !== "resolved").map((d) => d.id).join(", ")} · {t("needs review", "जाँच ज़रूरी")}</p>
      )}
    </div>
  );
}

export function AssistantCards({ reply, onAction, busy }: { reply: AssistantReply; onAction: (label: string, action: AssistantAction) => void; busy: boolean }) {
  const { t, lang } = useApp();
  const [decided, setDecided] = useState(false);
  return (
    <div className="mt-2 space-y-2">
      {reply.cards.map((card: AssistantCard, i) => {
        switch (card.type) {
          case "order":
            return <OrderMini key={i} order={card.order as Order} />;
          case "order_list": {
            const orders = card.orders as OrderSummary[];
            return (
              <ul key={i} className="divide-y divide-line rounded-xl border border-line bg-surface">
                {orders.slice(0, 6).map((o) => (
                  <li key={o.id}>
                    <Link to={`/app/orders/${o.id}`} className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-ivory">
                      <span className="font-semibold">{o.id}</span>
                      <span className="min-w-0 flex-1 truncate text-muted">{lang === "hi" ? o.headline_hi : o.headline}</span>
                      <StatusBadge status={o.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            );
          }
          case "discrepancies":
            return (
              <ul key={i} className="space-y-1">
                {(card.discrepancies as Discrepancy[]).map((d) => (
                  <li key={d.id} className="flex items-center gap-2 rounded-lg bg-red-soft px-3 py-1.5 text-xs text-red">
                    <AlertTriangle className="size-3.5" /> <b>{d.id}</b> · {d.order_id} · {num(d.difference_qty)} {lang === "hi" ? d.unit_label_hi : d.unit_label} · {d.kind}
                  </li>
                ))}
              </ul>
            );
          case "timeline": {
            const tl = card.timeline as Timeline;
            return (
              <div key={i} className="rounded-xl border border-line bg-surface px-3 pt-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">{t("Timeline", "टाइमलाइन")} · {tl.order_id}</p>
                <TimelineList events={tl.events.slice(-6)} />
              </div>
            );
          }
          case "confirm_order": {
            const v = card.validation as Validation;
            const action = card.action as AssistantAction;
            return (
              <div key={i} className="rounded-xl border border-[#f0d6a8] bg-amber-soft p-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-amber">{action.type === "create_draft" ? t("Confirm draft", "ड्राफ्ट की पुष्टि") : t("Confirm order", "ऑर्डर की पुष्टि")}</p>
                {v.lines.map((l) => (
                  <div key={l.line_no} className="mt-1">
                    <p className="font-semibold">{num(l.canonical_qty)} × {(lang === "hi" ? l.product_name_hi : l.product_name)}</p>
                    <p className="text-xs text-muted">{l.spec} · {t("unit", "इकाई")}: {l.unit} · {inr(l.line_value_inr)} <span className="text-faint">({t("illustrative", "उदाहरण")})</span></p>
                  </div>
                ))}
                <p className="mt-1 text-xs text-muted">{t("Distributor", "डिस्ट्रीब्यूटर")}: Sharma Building Supplies</p>
                {!decided ? (
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" loading={busy} icon={<Check className="size-4" />} onClick={() => { setDecided(true); onAction(t("Yes, confirm", "हाँ, पुष्टि करें"), { type: "confirm", action }); }}>
                      {action.type === "create_draft" ? t("Create draft", "ड्राफ्ट बनाएँ") : t("Confirm & send", "पुष्टि करके भेजें")}
                    </Button>
                    <Button size="sm" variant="secondary" icon={<X className="size-4" />} onClick={() => { setDecided(true); onAction(t("Cancel", "रद्द करें"), { type: "cancel" }); }}>{t("Cancel", "रद्द करें")}</Button>
                  </div>
                ) : <p className="mt-2 text-xs text-muted">{t("Decision recorded.", "निर्णय दर्ज।")}</p>}
              </div>
            );
          }
          case "confirm_note": {
            const action = card.action as AssistantAction;
            return !decided ? (
              <div key={i} className="flex gap-2">
                <Button size="sm" onClick={() => { setDecided(true); onAction(t("Yes, save the note", "हाँ, नोट सहेजें"), { type: "confirm", action }); }}>{t("Save note", "नोट सहेजें")}</Button>
                <Button size="sm" variant="secondary" onClick={() => { setDecided(true); onAction(t("Cancel", "रद्द करें"), { type: "cancel" }); }}>{t("Cancel", "रद्द करें")}</Button>
              </div>
            ) : null;
          }
          case "choices":
            return (
              <div key={i} className="space-y-1.5">
                {(card.options as { label: string; sku: string; quantity: number; unit: string; draft_only?: boolean }[]).map((o) => (
                  <button key={o.sku} onClick={() => onAction(o.label, { type: "select", selection: { sku: o.sku, quantity: o.quantity, unit: o.unit, draft_only: o.draft_only } })}
                    className="block w-full rounded-lg border border-line-strong bg-surface px-3 py-2 text-left text-sm hover:border-teal">
                    {o.label}
                  </button>
                ))}
              </div>
            );
          case "validation": {
            const v = card.validation as Validation;
            return (
              <div key={i} className="rounded-xl border border-[#f2c6c1] bg-red-soft p-3 text-sm text-red">
                {v.lines.flatMap((l) => (lang === "hi" ? l.messages_hi : l.messages)).map((m) => <p key={m}>{m}</p>)}
              </div>
            );
          }
          case "dashboard": {
            const d = card.summary as Dashboard;
            return (
              <div key={i} className="grid grid-cols-4 gap-1.5 text-center">
                {[
                  [t("Total", "कुल"), d.total_orders, <ClipboardList key="a" className="mx-auto size-4" />],
                  [t("In transit", "रास्ते में"), d.in_transit, <Truck key="b" className="mx-auto size-4 text-blue" />],
                  [t("Review", "जाँच"), d.needs_review, <AlertTriangle key="c" className="mx-auto size-4 text-red" />],
                  [t("Delivered", "डिलीवर"), d.delivered, <PackageCheck key="d" className="mx-auto size-4 text-[#0b6b49]" />],
                ].map(([label, value, icon]) => (
                  <div key={label as string} className="rounded-lg border border-line bg-surface p-2">
                    {icon}
                    <p className="text-lg font-semibold tabular">{value as number}</p>
                    <p className="text-[11px] text-muted">{label}</p>
                  </div>
                ))}
              </div>
            );
          }
          case "products":
            return (
              <ul key={i} className="divide-y divide-line rounded-xl border border-line bg-surface text-sm">
                {(card.products as Product[]).map((p) => (
                  <li key={p.sku} className="flex items-center justify-between gap-2 px-3 py-2">
                    <span>{lang === "hi" ? p.name_hi : p.name}</span>
                    <Badge tone={p.availability === "out_of_stock" ? "red" : p.availability === "low_stock" ? "amber" : "green"}>
                      {p.availability === "out_of_stock" ? t("Out of stock", "स्टॉक में नहीं") : `${num(p.available_qty)} ${lang === "hi" ? p.unit_label_hi : p.unit_label}`}
                    </Badge>
                  </li>
                ))}
              </ul>
            );
          default:
            return null;
        }
      })}
      {reply.suggestions.length > 0 && (
        <div className="flex flex-wrap gap-1.5 pt-1">
          {reply.suggestions.map((s) => (
            <button key={s.label} onClick={() => onAction(s.label, s.action)}
              className="inline-flex items-center gap-1 rounded-full border border-teal/30 bg-teal-soft px-3 py-1 text-xs font-medium text-teal hover:bg-[#d3e9e5]">
              {s.label} <ArrowRight className="size-3" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/** Routes a suggestion / card action to the right endpoint. */
export function useActionRouter(conv: ReturnType<typeof useConversation>, openNote: (orderId: string, discrepancyId: string) => void) {
  const navigate = useNavigate();
  const { t } = useApp();
  return (label: string, action: AssistantAction) => {
    switch (action.type) {
      case "message": conv.send(String(action.text)); break;
      case "timeline": conv.timeline(String(action.order_id), label); break;
      case "navigate": navigate(String(action.to)); break;
      case "select": conv.send(label, action.selection as Record<string, unknown>); break;
      case "confirm": conv.confirm(action.action as AssistantAction, label); break;
      case "record_note": openNote(String(action.order_id), String(action.discrepancy_id)); break;
      case "retry": conv.retry(); break;
      case "cancel": conv.push({ from: "user", text: label }); conv.push({ from: "assistant", text: t("Okay, cancelled. Nothing was sent or changed.", "ठीक है, रद्द किया। कुछ भी भेजा या बदला नहीं गया।") }); break;
      default: break;
    }
  };
}

export function ModeNote() {
  const { t } = useApp();
  return (
    <p className="flex items-start gap-1.5 text-[11px] leading-snug text-muted">
      <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-teal" />
      {t("Rule-based bilingual parser (no external LLM connected). Every fact comes from a live MCP tool result; writes need your confirmation.",
        "नियम-आधारित द्विभाषी पार्सर (कोई बाहरी LLM नहीं जुड़ा)। हर जानकारी लाइव MCP टूल से आती है; बदलाव से पहले आपकी पुष्टि ज़रूरी।")}
    </p>
  );
}
