import {
  AlertTriangle, BookOpen, Boxes, LayoutDashboard, ListOrdered, Menu, MessagesSquare, Mic, PlugZap, PlusCircle,
  Search, Settings2, Truck, X,
} from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useApp } from "../lib/app";
import type { Role } from "../lib/types";
import { ActivityDrawer, ConnectionIndicator } from "./mcp";
import { cx, Toasts } from "./ui";

export function Logo({ light }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5" aria-label="Dukaan Sathi home">
      <svg viewBox="0 0 64 64" className="size-9" aria-hidden>
        <rect width="64" height="64" rx="14" fill="#0F5F58" />
        <path d="M14 27 32 15l18 12v4H14z" fill="#F4C27A" />
        <rect x="18" y="33" width="28" height="16" rx="2" fill="#FAF7F0" />
        <rect x="28" y="38" width="8" height="11" fill="#0F5F58" />
      </svg>
      <div className="leading-tight">
        <div className={cx("font-semibold tracking-tight", light ? "text-white" : "text-ink")}>Dukaan Sathi</div>
        <div className={cx("text-[11px]", light ? "text-white/70" : "text-muted")}>दुकान साथी</div>
      </div>
    </Link>
  );
}

export function LanguageToggle({ className }: { className?: string }) {
  const { lang, setLang } = useApp();
  return (
    <div className={cx("inline-flex rounded-lg border border-line-strong bg-surface p-0.5 text-sm", className)} role="group" aria-label="Language / भाषा">
      {(["en", "hi"] as const).map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cx("rounded-md px-2.5 py-1 font-medium transition-colors", lang === l ? "bg-teal text-white" : "text-ink-soft hover:bg-ivory-deep")}
        >
          {l === "en" ? "English" : "हिन्दी"}
        </button>
      ))}
    </div>
  );
}

export function RoleSwitcher() {
  const { role, setRole, t, toast } = useApp();
  const change = (r: Role) => {
    if (r === role) return;
    setRole(r);
    toast(r === "retailer" ? t("Now viewing as Raj Hardware Store (retailer)", "अब राज हार्डवेयर स्टोर (रिटेलर) के रूप में") : t("Now viewing as Sharma Building Supplies (distributor)", "अब शर्मा बिल्डिंग सप्लाइज़ (डिस्ट्रीब्यूटर) के रूप में"), "info");
  };
  return (
    <div className="rounded-xl border border-line bg-ivory/70 p-1" role="group" aria-label={t("Demo role", "डेमो भूमिका")}>
      {(["retailer", "distributor"] as const).map((r) => (
        <button
          key={r}
          onClick={() => change(r)}
          aria-pressed={role === r}
          className={cx(
            "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm transition-colors",
            role === r ? "bg-surface shadow-sm ring-1 ring-line" : "text-muted hover:text-ink",
          )}
        >
          <span className={cx("flex size-7 items-center justify-center rounded-md text-xs font-bold", r === "retailer" ? "bg-[#fbe7cc] text-[#8a4b06]" : "bg-teal-soft text-teal")}>
            {r === "retailer" ? "RH" : "SB"}
          </span>
          <span className="min-w-0">
            <span className="block truncate font-medium text-ink">{r === "retailer" ? t("Raj Hardware Store", "राज हार्डवेयर स्टोर") : t("Sharma Building Supplies", "शर्मा बिल्डिंग सप्लाइज़")}</span>
            <span className="block text-[11px] text-muted">{r === "retailer" ? t("Retailer", "रिटेलर") : t("Distributor", "डिस्ट्रीब्यूटर")}</span>
          </span>
        </button>
      ))}
      <p className="px-2 pb-1 pt-1.5 text-[10.5px] leading-snug text-faint">{t("Simulated demo roles — not real sign-in.", "सिम्युलेटेड डेमो भूमिकाएँ — असली लॉगिन नहीं।")}</p>
    </div>
  );
}

export function AppLayout() {
  const { t, role } = useApp();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  const nav = [
    { to: "/app", end: true, icon: LayoutDashboard, label: t("Dashboard", "डैशबोर्ड") },
    { to: "/app/orders", end: true, icon: ListOrdered, label: t("Orders", "ऑर्डर") },
    ...(role === "retailer" ? [{ to: "/app/orders/new", end: true, icon: PlusCircle, label: t("New order", "नया ऑर्डर") }] : []),
    { to: "/app/distributor", end: true, icon: Truck, label: t("Distributor workspace", "डिस्ट्रीब्यूटर वर्कस्पेस") },
    { to: "/app/discrepancies", end: true, icon: AlertTriangle, label: t("Deliveries & differences", "डिलीवरी और अंतर") },
    { to: "/app/assistant", end: true, icon: MessagesSquare, label: t("Ask Dukaan Sathi", "दुकान साथी से पूछें") },
    { to: "/app/voice", end: true, icon: Mic, label: t("Voice experience", "वॉइस अनुभव") },
    { to: "/app/catalogue", end: true, icon: Boxes, label: t("Catalogue", "कैटलॉग") },
    { to: "/app/mcp", end: true, icon: PlugZap, label: t("MCP console", "MCP कंसोल") },
    { to: "/app/demo", end: true, icon: Settings2, label: t("Demo controls", "डेमो नियंत्रण") },
    { to: "/about", end: true, icon: BookOpen, label: t("About & architecture", "परिचय और आर्किटेक्चर") },
  ];

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    if (!term) return;
    if (/^(ds[-\s]?)?\d{4}$/i.test(term)) navigate(`/app/orders/DS-${term.replace(/\D/g, "")}`);
    else navigate(`/app/orders?search=${encodeURIComponent(term)}`);
    setQ("");
  };

  return (
    <div className="min-h-screen bg-ivory">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-[70] focus:rounded focus:bg-surface focus:px-3 focus:py-2">
        {t("Skip to content", "सामग्री पर जाएँ")}
      </a>
      <aside
        className={cx(
          "fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-line bg-surface transition-transform lg:translate-x-0",
          open ? "translate-x-0 shadow-xl" : "-translate-x-full",
        )}
        aria-label={t("Main navigation", "मुख्य नेविगेशन")}
      >
        <div className="flex items-center justify-between px-5 py-4">
          <Logo />
          <button className="rounded-lg p-1.5 text-muted hover:bg-ivory-deep lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
            <X className="size-5" />
          </button>
        </div>
        <div className="px-3"><RoleSwitcher /></div>
        <nav className="mt-3 flex-1 overflow-y-auto px-3 pb-4">
          <ul className="space-y-0.5">
            {nav.map((n) => (
              <li key={n.to}>
                <NavLink
                  to={n.to}
                  end={n.end}
                  className={({ isActive }) =>
                    cx("flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                      isActive ? "bg-teal-soft font-semibold text-teal" : "text-ink-soft hover:bg-ivory-deep")}
                >
                  <n.icon className="size-4" aria-hidden />
                  {n.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <div className="border-t border-line px-5 py-3 text-[11px] text-faint">
          {t("Hackathon prototype · fictional businesses · synthetic data", "हैकाथॉन प्रोटोटाइप · काल्पनिक व्यापार · नमूना डेटा")}
        </div>
      </aside>
      {open && <div className="fixed inset-0 z-40 bg-ink/30 lg:hidden" onClick={() => setOpen(false)} aria-hidden />}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-30 border-b border-line bg-ivory/90 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
            <button className="rounded-lg p-2 text-ink-soft hover:bg-ivory-deep lg:hidden" onClick={() => setOpen(true)} aria-label={t("Open menu", "मेन्यू खोलें")}>
              <Menu className="size-5" />
            </button>
            <form onSubmit={onSearch} className="relative hidden flex-1 sm:block sm:max-w-md" role="search">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" aria-hidden />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t("Search order number or product (e.g. 1042, cement)", "ऑर्डर नंबर या उत्पाद खोजें (जैसे 1042, सीमेंट)")}
                className="h-10 w-full rounded-lg border border-line-strong bg-surface pl-9 pr-3 text-sm placeholder:text-faint focus:border-teal focus:outline-none focus:ring-2 focus:ring-teal/20"
                aria-label={t("Search orders", "ऑर्डर खोजें")}
              />
            </form>
            <div className="ml-auto flex items-center gap-2">
              <span className="hidden md:inline-flex"><ConnectionIndicator /></span>
              <span className="md:hidden"><ConnectionIndicator compact /></span>
              <LanguageToggle />
            </div>
          </div>
        </header>
        <main id="main" className="mx-auto max-w-7xl px-4 py-6 pb-24 sm:px-6 lg:px-8">
          <Outlet />
        </main>
      </div>
      <ActivityDrawer />
      <Toasts />
    </div>
  );
}
