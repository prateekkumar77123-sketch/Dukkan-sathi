import {
  AlertTriangle, Bot, CheckCircle2, CircleDot, ClipboardCheck, FilePlus2, MessageSquareText, PackageCheck,
  Scale, Send, ShieldCheck, Truck,
} from "lucide-react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../lib/app";
import {
  dateOnly, dateTime, dayLabel, DISC_STATUS_LABEL, inr, KIND_LABEL, num, qty, RESOLUTION_LABEL, SOURCE_LABEL, STATUS_META, timeOnly, unitLabel,
} from "../lib/format";
import type { Dashboard, Discrepancy, OrderLine, OrderSummary, TimelineEvent } from "../lib/types";
import { Badge, cx, StatusBadge } from "./ui";

export function OrderTable({ orders, empty }: { orders: OrderSummary[]; empty?: React.ReactNode }) {
  const { t, lang } = useApp();
  const navigate = useNavigate();
  if (!orders.length) return <>{empty}</>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-muted">
            <th className="px-5 py-2.5 font-medium">{t("Order", "ऑर्डर")}</th>
            <th className="px-3 py-2.5 font-medium">{t("Items", "आइटम")}</th>
            <th className="px-3 py-2.5 font-medium">{t("Status", "स्थिति")}</th>
            <th className="hidden px-3 py-2.5 font-medium md:table-cell">{t("Expected", "अपेक्षित")}</th>
            <th className="hidden px-5 py-2.5 text-right font-medium sm:table-cell">{t("Value", "मूल्य")}</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr
              key={o.id}
              className="cursor-pointer border-b border-line last:border-0 hover:bg-ivory/80"
              onClick={() => navigate(`/app/orders/${o.id}`)}
            >
              <td className="px-5 py-3 align-top">
                <Link to={`/app/orders/${o.id}`} className="font-semibold text-ink hover:text-teal" onClick={(e) => e.stopPropagation()}>
                  {o.id}
                </Link>
                <div className="text-xs text-muted">{dateTime(o.created_at, lang)}</div>
              </td>
              <td className="px-3 py-3 align-top">
                <div className="text-ink-soft">{lang === "hi" ? o.headline_hi : o.headline}</div>
                {o.open_discrepancy_count > 0 && (
                  <div className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-red">
                    <AlertTriangle className="size-3.5" aria-hidden /> {o.open_discrepancy_count} {t("open difference", "खुला अंतर")}
                  </div>
                )}
              </td>
              <td className="px-3 py-3 align-top"><StatusBadge status={o.status} /></td>
              <td className="hidden px-3 py-3 align-top text-muted md:table-cell">{o.expected_delivery_date ? dateOnly(o.expected_delivery_date, lang) : "—"}</td>
              <td className="hidden px-5 py-3 text-right align-top tabular text-ink-soft sm:table-cell">{inr(o.total_value_inr)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Requested → Confirmed → Dispatched → Received for one line, with the computed difference. */
export function QuantityFlow({ line }: { line: OrderLine }) {
  const { t, lang } = useApp();
  const steps: { label: string; value: number | null; icon: React.ReactNode }[] = [
    { label: t("Requested", "माँगा"), value: line.requested_qty, icon: <FilePlus2 className="size-4" /> },
    { label: t("Confirmed", "पुष्टि"), value: line.confirmed_qty, icon: <ClipboardCheck className="size-4" /> },
    { label: t("Dispatched", "भेजा"), value: line.dispatched_qty, icon: <Truck className="size-4" /> },
    { label: t("Received", "मिला"), value: line.received_qty, icon: <PackageCheck className="size-4" /> },
  ];
  const cmp = line.comparison;
  const short = cmp.outcome === "short";
  const excess = cmp.outcome === "excess";
  return (
    <div className="rounded-xl border border-line bg-ivory/40 p-4">
      <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <p className="font-semibold text-ink">{lang === "hi" ? line.product_name_hi : line.product_name}</p>
          <p className="text-xs text-muted">{lang === "hi" ? line.spec_hi : line.spec} · <span className="font-mono">{line.sku}</span></p>
        </div>
        <p className="text-xs text-muted tabular">{inr(line.unit_price_inr)} / {unitLabel(line.unit, 1, lang)} <span className="text-faint">({t("illustrative", "उदाहरण")})</span></p>
      </div>
      <ol className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {steps.map((s, i) => {
          const isReceived = i === 3;
          const flagged = isReceived && (short || excess);
          const partial = i === 1 && s.value !== null && s.value < line.requested_qty;
          return (
            <li
              key={s.label}
              className={cx(
                "rounded-lg border bg-surface px-3 py-2.5",
                s.value === null && "border-dashed border-line-strong bg-transparent",
                s.value !== null && !flagged && "border-line",
                flagged && "border-red bg-red-soft",
              )}
            >
              <div className={cx("flex items-center gap-1.5 text-xs font-medium", flagged ? "text-red" : "text-muted")}>
                {s.icon} {s.label}
              </div>
              <div className={cx("mt-1 text-xl font-semibold tabular", s.value === null ? "text-faint" : flagged ? "text-red" : "text-ink")}>
                {s.value === null ? "—" : num(s.value)}
                <span className="ml-1 text-sm font-normal text-muted">{s.value === null ? t("pending", "बाकी") : unitLabel(line.unit, s.value, lang)}</span>
              </div>
              {partial && <div className="mt-0.5 text-[11px] font-medium text-amber">{t("Partial confirmation", "आंशिक पुष्टि")}</div>}
              {isReceived && line.damaged_qty ? <div className="mt-0.5 text-[11px] font-medium text-amber">{qty(line.damaged_qty, line.unit, lang)} {t("damaged", "क्षतिग्रस्त")}</div> : null}
            </li>
          );
        })}
      </ol>
      <div
        className={cx(
          "mt-3 flex items-start gap-2 rounded-lg px-3 py-2 text-sm",
          short || excess ? "bg-red-soft text-red" : cmp.outcome === "match" ? "bg-[#e7f5ee] text-[#0b6b49]" : "bg-ivory-deep text-muted",
        )}
      >
        {short || excess ? <Scale className="mt-0.5 size-4 shrink-0" /> : cmp.outcome === "match" ? <CheckCircle2 className="mt-0.5 size-4 shrink-0" /> : <CircleDot className="mt-0.5 size-4 shrink-0" />}
        <div>
          {(short || excess) && (
            <p className="font-semibold">
              {t("Quantity discrepancy", "मात्रा में अंतर")}: {qty(Math.abs(cmp.receipt_variance ?? 0), line.unit, lang)} {short ? t("short", "कम") : t("extra", "अधिक")}
            </p>
          )}
          <p>{lang === "hi" ? cmp.summary_hi : cmp.summary}</p>
        </div>
      </div>
    </div>
  );
}

const EVENT_ICON: Record<string, React.ReactNode> = {
  draft_created: <FilePlus2 className="size-4" />,
  order_submitted: <Send className="size-4" />,
  order_confirmed: <ClipboardCheck className="size-4" />,
  dispatch_recorded: <Truck className="size-4" />,
  receipt_recorded: <PackageCheck className="size-4" />,
  discrepancy_flagged: <AlertTriangle className="size-4" />,
  damage_reported: <AlertTriangle className="size-4" />,
  discrepancy_reported: <AlertTriangle className="size-4" />,
  discrepancy_acknowledged: <MessageSquareText className="size-4" />,
  discrepancy_note: <MessageSquareText className="size-4" />,
  resolution_recorded: <ShieldCheck className="size-4" />,
  review_started: <Scale className="size-4" />,
  order_resolved: <CheckCircle2 className="size-4" />,
  quantities_matched: <CheckCircle2 className="size-4" />,
};

function eventTone(type: string) {
  if (["discrepancy_flagged", "damage_reported", "discrepancy_reported"].includes(type)) return "bg-red-soft text-red border-[#f2c6c1]";
  if (["resolution_recorded", "order_resolved", "quantities_matched"].includes(type)) return "bg-[#e7f5ee] text-[#0b6b49] border-[#bfe3d1]";
  if (["discrepancy_acknowledged", "discrepancy_note", "review_started"].includes(type)) return "bg-amber-soft text-amber border-[#f0d6a8]";
  return "bg-teal-soft text-teal border-[#bcdcd6]";
}

export function TimelineList({ events, highlightNewerThan }: { events: TimelineEvent[]; highlightNewerThan?: number }) {
  const { lang, t } = useApp();
  let lastDay = "";
  return (
    <ol className="relative">
      {events.map((e, i) => {
        const day = dayLabel(e.at, lang);
        const showDay = day !== lastDay;
        lastDay = day;
        const src = SOURCE_LABEL[e.source] ?? { en: e.source, hi: e.source };
        return (
          <li key={e.id} className={cx(highlightNewerThan !== undefined && e.id > highlightNewerThan && "flash rounded-lg")}>
            {showDay && <p className="mb-2 mt-1 text-xs font-semibold uppercase tracking-wide text-faint">{day}</p>}
            <div className="relative flex gap-3 pb-5">
              {i < events.length - 1 && <span className="absolute left-[15px] top-8 h-[calc(100%-1.75rem)] w-px bg-line-strong" aria-hidden />}
              <span className={cx("relative z-10 flex size-8 shrink-0 items-center justify-center rounded-full border", eventTone(e.event_type))}>
                {EVENT_ICON[e.event_type] ?? <CircleDot className="size-4" />}
              </span>
              <div className="min-w-0 flex-1 pt-0.5">
                <div className="flex flex-wrap items-baseline gap-x-2">
                  <time className="font-mono text-xs font-semibold text-ink tabular" dateTime={e.at}>{timeOnly(e.at, lang)}</time>
                  <span className="text-xs text-muted">{e.actor_role === "system" ? t("Dukaan Sathi automatic check", "Dukaan Sathi स्वचालित जाँच") : e.actor_name}</span>
                  <span className={cx("rounded px-1.5 text-[10px] font-medium", e.source === "alexa" ? "bg-blue-soft text-blue" : "bg-ivory-deep text-muted")}>
                    {e.source === "alexa" && <Bot className="mr-0.5 inline size-3" />}
                    {lang === "hi" ? src.hi : src.en}
                  </span>
                </div>
                <p className="mt-0.5 text-sm text-ink-soft">{lang === "hi" ? e.summary_hi : e.summary}</p>
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

export function DiscrepancyCard({ d, showOrderLink = true, children }: { d: Discrepancy; showOrderLink?: boolean; children?: React.ReactNode }) {
  const { t, lang } = useApp();
  const tone = d.status === "resolved" ? "green" : d.status === "open" ? "red" : "amber";
  return (
    <div id={d.id} className={cx("rounded-xl border bg-surface p-4", d.status === "resolved" ? "border-line" : "border-[#f2c6c1]")}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-sm font-semibold">{d.id}</span>
            <Badge tone={d.kind === "damaged" ? "amber" : "red"}>{KIND_LABEL[d.kind][lang]}</Badge>
            <Badge tone={tone}>{DISC_STATUS_LABEL[d.status][lang]}</Badge>
          </div>
          <p className="mt-1 text-sm text-muted">
            {showOrderLink && (
              <>
                <Link to={`/app/orders/${d.order_id}`} className="font-medium text-teal hover:underline">{d.order_id}</Link>{" · "}
              </>
            )}
            {lang === "hi" ? d.product_name_hi : d.product_name} · <span className="font-mono text-xs">{d.sku}</span>
          </p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-semibold tabular text-red">{num(d.difference_qty)} <span className="text-sm font-normal text-muted">{lang === "hi" ? d.unit_label_hi : d.unit_label}</span></p>
          <p className="text-xs text-muted">{t("detected", "दर्ज")} {dateTime(d.detected_at, lang)}</p>
        </div>
      </div>
      <p className="mt-2 text-sm text-ink-soft">{lang === "hi" ? d.description_hi : d.description}</p>
      <p className="mt-1 text-xs text-muted">
        {d.detected_by === "system" ? t("Flagged automatically by comparing recorded quantities. No party is assumed to be at fault.", "दर्ज मात्राओं की तुलना से अपने-आप दर्ज। किसी पक्ष को दोषी नहीं माना गया है।")
          : t(`Reported by the ${d.detected_by}.`, `${d.detected_by} द्वारा दर्ज।`)}
      </p>
      {(d.notes.length > 0 || d.resolutions.length > 0) && (
        <ul className="mt-3 space-y-2 border-t border-line pt-3">
          {d.notes.map((n, i) => (
            <li key={`n${i}`} className="flex gap-2 text-sm">
              <MessageSquareText className="mt-0.5 size-4 shrink-0 text-amber" />
              <div>
                <span className="font-medium">{n.author_name}</span>{" "}
                <span className="text-xs text-muted">{n.kind === "acknowledgement" ? t("acknowledged", "स्वीकार किया") : t("noted", "नोट")} · {dateTime(n.created_at, lang)} · {(SOURCE_LABEL[n.source] ?? { en: n.source, hi: n.source })[lang]}</span>
                <p className="text-ink-soft">“{n.note}”</p>
              </div>
            </li>
          ))}
          {d.resolutions.map((r, i) => (
            <li key={`r${i}`} className="flex gap-2 text-sm">
              <ShieldCheck className="mt-0.5 size-4 shrink-0 text-[#0b6b49]" />
              <div>
                <span className="font-medium">{RESOLUTION_LABEL[r.resolution_type]?.[lang] ?? r.resolution_type}</span>
                {r.follow_up_qty ? <span> · {qty(r.follow_up_qty, d.unit, lang)}</span> : null}
                <span className="text-xs text-muted"> · {r.decided_by_name} · {dateTime(r.decided_at, lang)}</span>
                <p className="text-ink-soft">“{r.notes}”</p>
              </div>
            </li>
          ))}
        </ul>
      )}
      {children}
    </div>
  );
}

const SEGMENTS = [
  { key: "needs_review", color: "var(--color-chart-review)", en: "Needs review", hi: "जाँच ज़रूरी" },
  { key: "awaiting", color: "var(--color-chart-awaiting)", en: "Awaiting confirmation / dispatch", hi: "पुष्टि / डिस्पैच बाकी" },
  { key: "in_transit", color: "var(--color-chart-transit)", en: "In transit", hi: "रास्ते में" },
  { key: "delivered", color: "var(--color-chart-delivered)", en: "Delivered (incl. resolved)", hi: "डिलीवर (समाधान सहित)" },
] as const;

/** Part-to-whole: one horizontal stacked bar of order statuses, with labels so colour never carries meaning alone. */
export function StatusBar({ d }: { d: Dashboard }) {
  const { lang, t } = useApp();
  const [hover, setHover] = useState<string | null>(null);
  const values: Record<string, number> = {
    needs_review: d.needs_review,
    awaiting: d.pending_confirmation + d.confirmed_awaiting_dispatch,
    in_transit: d.in_transit,
    delivered: d.delivered,
  };
  const total = Object.values(values).reduce((a, b) => a + b, 0) || 1;
  return (
    <div>
      <div className="flex h-4 w-full gap-[2px] overflow-hidden rounded-full bg-ivory-deep" role="img"
        aria-label={SEGMENTS.map((s) => `${lang === "hi" ? s.hi : s.en}: ${values[s.key]}`).join(", ")}>
        {SEGMENTS.filter((s) => values[s.key] > 0).map((s) => (
          <div
            key={s.key}
            className={cx("h-full transition-opacity", hover && hover !== s.key && "opacity-40")}
            style={{ width: `${(values[s.key] / total) * 100}%`, background: s.color }}
            onMouseEnter={() => setHover(s.key)}
            onMouseLeave={() => setHover(null)}
            title={`${lang === "hi" ? s.hi : s.en}: ${values[s.key]} (${Math.round((values[s.key] / total) * 100)}%)`}
          />
        ))}
      </div>
      <ul className="mt-3 grid grid-cols-1 gap-y-1.5 text-sm">
        {SEGMENTS.map((s) => (
          <li key={s.key} className={cx("flex items-center gap-2", hover && hover !== s.key && "opacity-50")}
            onMouseEnter={() => setHover(s.key)} onMouseLeave={() => setHover(null)}>
            <span className="size-2.5 shrink-0 rounded-sm" style={{ background: s.color }} aria-hidden />
            <span className="text-muted">{lang === "hi" ? s.hi : s.en}</span>
            <span className="ml-auto font-semibold tabular text-ink">{values[s.key]}</span>
          </li>
        ))}
      </ul>
      <p className="mt-2 text-xs text-faint">{t("Counts are computed from the order records each time this page loads.", "ये गिनती हर बार ऑर्डर रिकॉर्ड से गिनी जाती हैं।")}</p>
    </div>
  );
}

export function statusText(status: keyof typeof STATUS_META, lang: "en" | "hi") {
  return STATUS_META[status][lang];
}
