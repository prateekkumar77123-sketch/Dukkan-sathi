import { Store, Truck, Package } from "lucide-react";
import { useState } from "react";
import { useApp } from "../lib/app";
import { PHOTOS } from "../lib/photos";
import { cx } from "./ui";

/** Local copy → Pexels CDN → illustrated fallback, so a missing file never breaks the page. */
export function Photo({ name, className, caption = true, eager }: { name: keyof typeof PHOTOS; className?: string; caption?: boolean; eager?: boolean }) {
  const { lang } = useApp();
  const info = PHOTOS[name];
  const [stage, setStage] = useState<0 | 1 | 2>(0);
  const src = stage === 0 ? info.local : info.remote;
  const Icon = name === "truck" ? Truck : name === "cement" ? Package : Store;
  return (
    <figure className={cx("relative overflow-hidden bg-ivory-deep", className)}>
      {stage < 2 ? (
        <img
          src={src}
          alt={info.alt[lang]}
          loading={eager ? "eager" : "lazy"}
          className="h-full w-full object-cover"
          onError={() => setStage((s) => (s === 0 ? 1 : 2))}
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[repeating-linear-gradient(45deg,#f3eee3,#f3eee3_12px,#efe8da_12px,#efe8da_24px)] text-muted" role="img" aria-label={info.alt[lang]}>
          <Icon className="size-10" aria-hidden />
          <span className="max-w-[80%] text-center text-xs">{info.alt[lang]}</span>
        </div>
      )}
      {caption && stage < 2 && (
        <figcaption className="absolute bottom-2 right-2 rounded bg-ink/55 px-2 py-0.5 text-[10px] text-white/90 backdrop-blur-sm">
          {lang === "hi" ? "फ़ोटो" : "Photo"}: <a className="underline" href={info.page} target="_blank" rel="noreferrer">{info.credit}</a>
          {info.place ? ` · ${info.place}` : ""}
        </figcaption>
      )}
    </figure>
  );
}
