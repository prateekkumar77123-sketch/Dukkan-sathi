import { Activity, CheckCircle2, ChevronDown, ChevronUp, PlugZap, Radio, XCircle } from "lucide-react";
import { useState } from "react";
import { useApp } from "../lib/app";
import { SOURCE_LABEL, timeOnly } from "../lib/format";
import type { ToolTrace } from "../lib/types";
import { cx } from "./ui";

export function ConnectionIndicator({ compact }: { compact?: boolean }) {
  const { health, healthError, t } = useApp();
  const gatewayOk = !!health;
  const mcpOk = !!health?.mcp.reachable;
  const state = !gatewayOk ? "down" : mcpOk ? "ok" : "mcp";
  const label =
    state === "ok"
      ? t("MCP server connected", "MCP सर्वर जुड़ा है")
      : state === "mcp"
        ? t("MCP server unreachable", "MCP सर्वर से संपर्क नहीं")
        : t("API gateway offline", "API गेटवे बंद है");
  return (
    <div
      className={cx(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium",
        state === "ok" && "border-[#bfe3d1] bg-[#e7f5ee] text-[#0b6b49]",
        state !== "ok" && "border-[#f2c6c1] bg-red-soft text-red",
      )}
      title={state === "ok" ? `${health?.mcp.url} · protocol ${health?.mcp.negotiated_protocol_version} · ${health?.mcp.tool_count} tools` : healthError ?? health?.mcp.error ?? ""}
      role="status"
    >
      <span className={cx("relative flex size-2")}>
        {state === "ok" && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#0e8a5f] opacity-60" />}
        <span className={cx("relative inline-flex size-2 rounded-full", state === "ok" ? "bg-[#0e8a5f]" : "bg-red")} />
      </span>
      {compact ? (state === "ok" ? "MCP" : "MCP ✕") : label}
      {!compact && state === "ok" && health?.mcp.negotiated_protocol_version && (
        <span className="hidden md:inline text-[#0b6b49]/70">· {health.mcp.negotiated_protocol_version}</span>
      )}
    </div>
  );
}

export function TraceRow({ trace, dense }: { trace: ToolTrace; dense?: boolean }) {
  const { lang } = useApp();
  const src = SOURCE_LABEL[trace.source] ?? { en: trace.source, hi: trace.source };
  return (
    <li className={cx("flex items-start gap-2.5", dense ? "py-1.5" : "py-2.5")}>
      {trace.ok ? <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-[#0e8a5f]" aria-label="ok" /> : <XCircle className="mt-0.5 size-4 shrink-0 text-red" aria-label="error" />}
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
          <code className="font-mono text-[13px] font-semibold text-ink">{trace.tool}</code>
          {trace.is_write && <span className="rounded bg-amber-soft px-1.5 text-[10px] font-semibold uppercase text-amber">write</span>}
          <span className={cx("rounded px-1.5 text-[10px] font-medium", trace.source === "alexa" ? "bg-[#e8f0fa] text-blue" : "bg-ivory-deep text-muted")}>
            {lang === "hi" ? src.hi : src.en}
          </span>
          <span className="text-[11px] text-faint tabular">{trace.elapsed_ms} ms · {timeOnly(trace.at, lang)}</span>
        </div>
        <p className="truncate font-mono text-[11px] text-muted" title={trace.input_summary}>→ {trace.input_summary}</p>
        <p className={cx("truncate text-xs", trace.ok ? "text-ink-soft" : "text-red")} title={trace.result_summary}>
          ← {trace.result_summary}
        </p>
      </div>
    </li>
  );
}

/** Traces returned with a specific API response: proves which tool produced what's on screen. */
export function TraceStrip({ traces, className }: { traces: ToolTrace[]; className?: string }) {
  const { t } = useApp();
  const [open, setOpen] = useState(false);
  if (!traces.length) return null;
  const last = traces[traces.length - 1];
  return (
    <div className={cx("rounded-xl border border-dashed border-line-strong bg-ivory/70 px-3 py-2 text-xs", className)}>
      <button className="flex w-full items-center gap-2 text-left text-muted" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <PlugZap className="size-3.5 text-teal" aria-hidden />
        <span>
          {t("Served by MCP tool", "MCP टूल से आया")}{" "}
          <code className="font-mono font-semibold text-ink">{traces.map((x) => x.tool).join(" → ")}</code>
          <span className="text-faint"> · {last.transport} · {last.protocol_version ?? "—"} · {traces.reduce((a, x) => a + x.elapsed_ms, 0)} ms</span>
        </span>
        <span className="ml-auto">{open ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}</span>
      </button>
      {open && (
        <ul className="mt-1 divide-y divide-line">
          {traces.map((x) => <TraceRow key={x.id} trace={x} dense />)}
        </ul>
      )}
    </div>
  );
}

/** Live feed of every MCP tool call the gateway makes — website, assistant, voice demo and Alexa. */
export function ActivityFeed({ limit = 40, filterSource }: { limit?: number; filterSource?: string }) {
  const { activity, t } = useApp();
  const items = [...activity].filter((a) => !filterSource || a.source === filterSource).reverse().slice(0, limit);
  if (!items.length) {
    return <p className="px-1 py-6 text-center text-sm text-muted">{t("No MCP calls yet. Use the app and they will appear here live.", "अभी कोई MCP कॉल नहीं। ऐप इस्तेमाल करें, कॉल यहाँ लाइव दिखेंगी।")}</p>;
  }
  return (
    <ul className="divide-y divide-line">
      {items.map((x) => <TraceRow key={x.id} trace={x} />)}
    </ul>
  );
}

export function ActivityDrawer() {
  const { t, activity } = useApp();
  const [open, setOpen] = useState(false);
  const alexaCalls = activity.filter((a) => a.source === "alexa").length;
  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col items-end">
      {open && (
        <div className="mb-2 w-[min(92vw,420px)] rounded-2xl border border-line bg-surface shadow-xl">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <div>
              <p className="flex items-center gap-2 font-semibold"><Radio className="size-4 text-teal" /> {t("Live MCP activity", "लाइव MCP गतिविधि")}</p>
              <p className="text-xs text-muted">{t("Every tool call the gateway makes over Streamable HTTP", "Streamable HTTP पर गेटवे की हर टूल कॉल")}</p>
            </div>
            <button className="text-sm text-muted hover:text-ink" onClick={() => setOpen(false)}>{t("Close", "बंद करें")}</button>
          </div>
          <div className="max-h-[50vh] overflow-y-auto px-4">
            <ActivityFeed limit={30} />
          </div>
        </div>
      )}
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-2 rounded-full border border-line-strong bg-surface px-4 py-2 text-sm font-medium shadow-lg hover:bg-ivory-deep"
        aria-expanded={open}
      >
        <Activity className="size-4 text-teal" aria-hidden />
        {t("MCP activity", "MCP गतिविधि")}
        <span className="rounded-full bg-teal px-2 text-xs text-white tabular">{activity.length}</span>
        {alexaCalls > 0 && <span className="rounded-full bg-blue px-2 text-xs text-white">Alexa {alexaCalls}</span>}
      </button>
    </div>
  );
}
