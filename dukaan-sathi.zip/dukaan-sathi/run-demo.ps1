<#
  Dukaan Sathi — one-command local demo for Windows (PowerShell 5.1 or 7+).

  Starts three processes in their own windows:
    1. MCP server        http://127.0.0.1:8001/mcp   (Streamable HTTP)
    2. API gateway       http://127.0.0.1:8000       (FastAPI, MCP client)
    3. Website           http://127.0.0.1:5173       (React + Vite)

  First run installs everything (Python venv + pip, npm install). Usage, from the repository root:
    powershell -ExecutionPolicy Bypass -File .\run-demo.ps1                # start (installs on first run)
    powershell -ExecutionPolicy Bypass -File .\run-demo.ps1 -Reset live    # reset data so DS-1042 is in transit, then start
    powershell -ExecutionPolicy Bypass -File .\run-demo.ps1 -Reset full    # restore the full sample dataset, then start
    powershell -ExecutionPolicy Bypass -File .\run-demo.ps1 -Install       # force reinstall of dependencies
  Stop everything with:  powershell -ExecutionPolicy Bypass -File .\stop-demo.ps1
#>
param(
  [ValidateSet("", "full", "live")] [string]$Reset = "",
  [switch]$Install,
  [switch]$NoBrowser
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Backend = Join-Path $Root "backend"
$Frontend = Join-Path $Root "frontend"
$VenvPy = Join-Path $Backend ".venv\Scripts\python.exe"
$PidFile = Join-Path $Root ".demo-pids"

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Fail($msg) { Write-Host "`nERROR: $msg" -ForegroundColor Red; exit 1 }

function Find-Python {
  # Prefer the Windows launcher with a known-good version; fall back to python on PATH.
  # Returns a hashtable (not an array, which PowerShell would unroll) with the executable and its arguments.
  foreach ($v in @("3.13", "3.12", "3.11", "3.14")) {
    try {
      $out = & py "-$v" -c "import sys; print(sys.version.split()[0])" 2>$null
      if ($LASTEXITCODE -eq 0 -and $out) { return @{ Exe = "py"; Args = @("-$v") } }
    } catch { }
  }
  try {
    $ver = & python -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
    if ($LASTEXITCODE -eq 0 -and [version]$ver -ge [version]"3.11") { return @{ Exe = "python"; Args = @() } }
  } catch { }
  return $null
}

function Wait-Http($url, $name, $seconds = 60) {
  $deadline = (Get-Date).AddSeconds($seconds)
  while ((Get-Date) -lt $deadline) {
    try {
      $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 3
      if ($r.StatusCode -lt 500) { Write-Host "    $name is up ($url)" -ForegroundColor Green; return $true }
    } catch { Start-Sleep -Milliseconds 700 }
  }
  Write-Host "    $name did not answer at $url within $seconds s - check its window for errors." -ForegroundColor Yellow
  return $false
}

function Test-PortFree($port) {
  $inUse = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
  return -not $inUse
}

# ---------------------------------------------------------------- prerequisites
Step "Checking prerequisites"
$py = Find-Python
if (-not $py) { Fail "Python 3.11-3.14 not found. Install Python 3.13 from https://www.python.org/downloads/ (tick 'Add python.exe to PATH')." }
$pyArgs = $py.Args
$pyVersion = & $py.Exe @pyArgs -c "import sys; print(sys.version.split()[0])"
Write-Host "    Python $pyVersion  ($($py.Exe) $($pyArgs -join ' '))"
try { $nodeVersion = (& node --version) } catch { Fail "Node.js not found. Install Node.js 22 LTS from https://nodejs.org/" }
if ([version]($nodeVersion.TrimStart("v")) -lt [version]"20.19.0") { Fail "Node.js $nodeVersion is too old for Vite 8. Install Node.js 22 LTS." }
Write-Host "    Node $nodeVersion, npm $(& npm --version)"

foreach ($port in 8001, 8000, 5173) {
  if (-not (Test-PortFree $port)) { Fail "Port $port is already in use. Run .\stop-demo.ps1 or close the program using it." }
}

# ---------------------------------------------------------------- install
if ($Install -or -not (Test-Path $VenvPy)) {
  Step "Creating Python virtual environment (backend\.venv)"
  & $py.Exe @pyArgs -m venv (Join-Path $Backend ".venv")
  if ($LASTEXITCODE -ne 0) { Fail "Could not create the virtual environment." }
  Step "Installing backend packages"
  & $VenvPy -m pip install --upgrade pip --quiet
  & $VenvPy -m pip install -r (Join-Path $Backend "requirements-dev.txt")
  if ($LASTEXITCODE -ne 0) { Fail "pip install failed. If you are on Python 3.14 and a package has no wheel yet, install Python 3.13 and re-run with -Install." }
}
if ($Install -or -not (Test-Path (Join-Path $Frontend "node_modules"))) {
  Step "Installing frontend packages (npm install)"
  Push-Location $Frontend
  & npm install --no-audit --no-fund
  $code = $LASTEXITCODE
  Pop-Location
  if ($code -ne 0) { Fail "npm install failed." }
}

if (-not (Test-Path (Join-Path $Root ".env")) -and (Test-Path (Join-Path $Root ".env.example"))) {
  Copy-Item (Join-Path $Root ".env.example") (Join-Path $Root ".env")
  Write-Host "    Created .env from .env.example (local development defaults)."
}

# ---------------------------------------------------------------- data
if ($Reset) {
  Step "Resetting demo data ($Reset mode)"
  Push-Location $Backend
  & $VenvPy -m app.seed $Reset
  Pop-Location
}

# ---------------------------------------------------------------- start
Step "Starting the MCP server (port 8001)"
$mcp = Start-Process powershell -PassThru -ArgumentList @("-NoExit", "-Command",
  "`$Host.UI.RawUI.WindowTitle = 'Dukaan Sathi - MCP server :8001'; Set-Location '$Backend'; & '$VenvPy' -m app.mcp_server.server")
Wait-Http "http://127.0.0.1:8001/health" "MCP server" | Out-Null

Step "Starting the API gateway (port 8000)"
$gw = Start-Process powershell -PassThru -ArgumentList @("-NoExit", "-Command",
  "`$Host.UI.RawUI.WindowTitle = 'Dukaan Sathi - API gateway :8000'; Set-Location '$Backend'; & '$VenvPy' -m app.gateway.main")
Wait-Http "http://127.0.0.1:8000/api/health" "API gateway" | Out-Null

Step "Starting the website (port 5173)"
$web = Start-Process powershell -PassThru -ArgumentList @("-NoExit", "-Command",
  "`$Host.UI.RawUI.WindowTitle = 'Dukaan Sathi - website :5173'; Set-Location '$Frontend'; npm run dev")
Wait-Http "http://127.0.0.1:5173/" "Website" 90 | Out-Null

"$($mcp.Id)`n$($gw.Id)`n$($web.Id)" | Set-Content -Path $PidFile

# ---------------------------------------------------------------- report
try {
  $health = Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/health" -TimeoutSec 5
  $mcpLine = if ($health.mcp.reachable) { "reachable · protocol $($health.mcp.negotiated_protocol_version) · $($health.mcp.tool_count) tools" } else { "NOT reachable" }
} catch { $mcpLine = "unknown (gateway health check failed)" }

Write-Host ""
Write-Host "  Dukaan Sathi is running" -ForegroundColor Green
Write-Host "  ------------------------------------------------------------"
Write-Host "  Website        http://127.0.0.1:5173"
Write-Host "  Live demo      http://127.0.0.1:5173/app"
Write-Host "  Voice demo     http://127.0.0.1:5173/app/voice"
Write-Host "  API gateway    http://127.0.0.1:8000/api/health"
Write-Host "  MCP endpoint   http://127.0.0.1:8001/mcp   ($mcpLine)"
Write-Host "  Alexa endpoint http://127.0.0.1:8000/alexa (expose with a tunnel - see docs\alexa-echo-setup.md)"
Write-Host "  ------------------------------------------------------------"
Write-Host "  Stop:  powershell -ExecutionPolicy Bypass -File .\stop-demo.ps1"
if (-not $NoBrowser) { Start-Process "http://127.0.0.1:5173/" }
