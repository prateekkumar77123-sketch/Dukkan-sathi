# Sources and image attributions

## How sources were gathered

The build environment could not open most websites directly. Facts were collected with a web-search tool that
returned page titles, URLs and excerpts from the publishers listed below. Each claim on the website is worded no more
strongly than the excerpt supports. **Please open each link once before submission** to confirm it still says what is
recorded here (government pages are sometimes reorganised).

No statistics about shortage rates, time saved, disputes, adoption or market size are claimed anywhere. Where no
defensible statistic existed, the website uses the clearly labelled, simulated 50-bag cement example instead.

## Factual claims used on the website

| # | Claim as used | Publisher · date | URL |
|---|---|---|---|
| 1 | Over 7.83 crore enterprises registered on the Udyam Registration Portal and Udyam Assist Platform since July 2020. | Press Information Bureau, Ministry of MSME · 2026 (release title: "Over 7.83 crore enterprises registered on Udyam Registration Portal (URP); growth trend indicated") | https://www.pib.gov.in/PressReleasePage.aspx?PRID=2246892 |
| 2 | MSME sector accounts for 30.1% of India's GDP (statement by the Union Minister for MSME). | Press Information Bureau · 2025 (release title: "MSME sector accounts for 30.1% of India's GDP, 35.4% of manufacturing and 45.73% of exports in the country: Union Minister for MSME") | https://www.pib.gov.in/PressReleseDetailm.aspx?PRID=2142170 |
| 3 | GST on cement reduced from 28% to 18%, effective 22 September 2025, as recommended by the 56th GST Council meeting. Cement HSN heading 2523. | Press Information Bureau, Ministry of Finance · Sept 2025 | https://www.pib.gov.in/PressReleasePage.aspx?PRID=2163555 |
| 4 | Under CGST Rule 138, a registered person causing movement of goods of consignment value exceeding ₹50,000 must generate an e-way bill; exemptions apply (e.g. certain goods, short intra-state distances). | Central Board of Indirect Taxes and Customs — E-way bill rules | https://cbic-gst.gov.in/ewaybill-rules.html |
| 5 | Under CGST Rule 55, goods can move on a serially numbered delivery challan in specified cases; for supply of goods it is prepared in triplicate (original for consignee, duplicate for transporter, triplicate for consignor). | Central Board of Indirect Taxes and Customs — CGST Rules (tax invoice / delivery challan rules) | https://cbic-gst.gov.in/gst-invoice-rules.html |
| 6 | IS 269:2015 specifies Ordinary Portland Cement grades including 53; IS 1489 (Part 1):2015 covers fly-ash-based Portland Pozzolana Cement. | Bureau of Indian Standards — product manuals | https://www.bis.gov.in/wp-content/uploads/2019/10/PM_IS_269.pdf · https://bis.gov.in/wp-content/uploads/2019/10/PM_IS_1489Part1.pdf |
| 7 | IS 1786:2008 covers high-strength deformed steel bars including grade Fe 500D, under mandatory BIS certification. | Bureau of Indian Standards — IS 1786 product manual; Ministry of Steel annual report (Steel and Steel Products Quality Control Order) | https://www.bis.gov.in/wp-content/uploads/2020/07/PM-IS-1786-JULY-2020-Revised-4.pdf |
| 8 | India is the world's second-largest cement producer (context only, listed under Sources). | IBEF — Indian Cement Industry Analysis | https://www.ibef.org/industry/cement-presentation |

**Engineering approximation (not a sourced statistic):** TMT bar weights in the catalogue use the common rule of thumb
*d²/162 kg per metre* (d in mm). For example, 8 mm × 12 m ≈ 4.74 kg.

**Product assumptions (ours, not external facts):** that some shops coordinate through calls, chat, sales
representatives, invoices and notebooks, and that practices vary. The website says so explicitly and does not claim
this describes all businesses.

## Technical references

* Model Context Protocol specification 2025-11-25: https://modelcontextprotocol.io/specification/2025-11-25
* MCP Python SDK (v2, `MCPServer`, Streamable HTTP): https://py.sdk.modelcontextprotocol.io/ (the installed package was
  inspected directly: `mcp` 2.3.0 lists handshake versions up to 2025-11-25 plus 2026-07-28)
* Alexa Skills Kit — Host a custom skill as a web service (request verification): https://developer.amazon.com/docs/custom-skills/host-a-custom-skill-as-a-web-service.html
* Alexa Skills Kit — How to update your Alexa skills for Hindi (Devanagari for Hindi words, Latin for English words): https://developer.amazon.com/en-IN/blogs/alexa/alexa-skills-kit/2019/07/how-to-update-your-alexa-skills-for-hindi
* Alexa+ MCP Toolkit quick start: https://www.developer.amazon.com/docs/alexaplus/add-ons/mcp-toolkit-quickstart
* Echo Plus (2nd generation) model number L9D29R: confirmed only from retail and teardown listings (e.g. TechInsights
  product code AMZ-L9D29R), not from an Amazon page. Any Echo works with custom skills in development mode.

## Photographs

All photos are from **Pexels** and used under the **Pexels License** (free to use, modification allowed, attribution
not required; you may not sell unaltered copies or imply endorsement). Credits are shown on the website anyway.
They are stock photos of real places. **They do not show Dukaan Sathi users, customers or deployments.**

| Used for | Pexels page | Credit (from search listing) | Location (from listing) |
|---|---|---|---|
| Landing hero: shopkeeper in a hardware store | https://www.pexels.com/photo/man-working-at-hardware-store-19756443/ | vijesh vijayan | not stated |
| Example section: goods truck loaded with sacks | https://www.pexels.com/photo/truck-filled-with-sacks-15733306/ | see Pexels page | Bagbahara, India |
| Example section: cement bags in a warehouse | https://www.pexels.com/photo/stack-of-cement-bags-in-warehouse-setting-29519165/ | see Pexels page | listed as Central Visayas, Philippines (captioned generically, not as India) |
| Example section: hardware storefront | https://www.pexels.com/photo/old-hardware-storefront-with-tools-and-supplies-29151932/ | see Pexels page | not stated |
| Trade-context section: construction worker | https://www.pexels.com/photo/construction-worker-renovating-interior-in-delhi-30580529/ | see Pexels page | Delhi, India |
| Spare: traditional Indian market | https://www.pexels.com/photo/traditional-indian-market-16747112/ | see Pexels page | India |

**Important.** I could not view these images from the build environment: Pexels was not reachable there, so in my
screenshots the site shows its illustrated fallbacks. They were chosen from Pexels' own titles and descriptions. Before recording:

1. Run `scripts\fetch-photos.ps1`. It saves copies to `frontend\public\images\photos\` (otherwise the site loads them from the Pexels CDN).
2. **Look at each photo.** Replace any that don't fit (save a Pexels or Unsplash photo under the same filename, and update the credit in
   `frontend/src/lib/photos.ts` and in this file).
3. Fill in the photographer names from each Pexels page where the table says "see Pexels page".

No brand logos are used. The fictional business names are not real companies and imply no partnership.
