# Optional: remote HTTPS access

Local development needs none of this. Use it when an external client (an Alexa skill, a remote MCP client, a judge's
machine) must reach your laptop.

## Rules first

1. **Change the tokens.** Put long random values in `.env`:
   ```powershell
   $r = [Convert]::ToBase64String((1..32 | % { [byte](Get-Random -Max 256) })); "MCP_RETAILER_TOKEN=$r"
   ```
   Do the same for `MCP_DISTRIBUTOR_TOKEN`. The MCP server refuses to start with `MCP_PUBLIC_URL` set while the
   default development tokens are in use.
2. **Never expose the database** or the `data/` folder. Only HTTP services go through the tunnel.
3. **Expose only what you need:** port **8000** for the Alexa skill (only `/alexa` is served on public hostnames),
   port **8001** for remote MCP clients (token required for every request).
4. Quick-tunnel URLs are **temporary** and change when the tunnel restarts. Don't hardcode them; keep them in `.env`
   (`MCP_PUBLIC_URL`) or in the Alexa console endpoint.

## Alexa skill endpoint (port 8000)

```powershell
cloudflared tunnel --url http://localhost:8000
# Alexa endpoint = https://<random>.trycloudflare.com/alexa
```

See `alexa-echo-setup.md`.

## Remote MCP endpoint (port 8001)

```powershell
cloudflared tunnel --url http://localhost:8001
```

Then in `.env`:

```
MCP_PUBLIC_URL=https://<random>.trycloudflare.com/mcp
```

Restart the MCP server window. `MCP_PUBLIC_URL`'s hostname is added to the server's allowed Host/Origin list (DNS-rebinding
protection). A remote client then connects to `https://<random>.trycloudflare.com/mcp` with
`Authorization: Bearer <MCP_RETAILER_TOKEN>`:

```powershell
backend\.venv\Scripts\python.exe scripts\mcp_smoke_test.py --url https://<random>.trycloudflare.com/mcp --token <token>
```

## A stable URL

For a URL that survives restarts, create a **named** Cloudflare tunnel on a domain you control (requires a free
Cloudflare account): `cloudflared tunnel login`, `cloudflared tunnel create dukaan-sathi`, route a hostname to it, and
run it with a config file mapping `mcp.yourdomain.com → http://localhost:8001` and `alexa.yourdomain.com → http://localhost:8000`.

## Production gaps

Before real businesses use this: replace the static demo tokens with per-user identity (e.g. OAuth 2.1, which the MCP
authorization specification describes), add per-business data isolation tests, move from SQLite to a managed
database with backups, add HTTPS termination you control, structured audit retention, monitoring and abuse limits.
