# Connect Dukaan Sathi to your Echo (Echo Plus 2nd gen · L9D29R)

This connects a **real Echo** to Dukaan Sathi through an **Alexa custom skill** that you create in your own Amazon
developer account, in development mode. Nothing is published to the Alexa Skills Store.

```
"Alexa, open dukaan sathi"            Echo Plus  ──►  Alexa cloud  ──►  HTTPS tunnel  ──►  POST /alexa (gateway :8000)
"check my cement delivery"                                                                    │ verifies Amazon signature
                                                                                               ▼
                                                           MCP client ── Streamable HTTP ──►  MCP server :8001/mcp ──► SQLite
```

The Echo calls the **same MCP tools** as the website. While you talk to it, the website's *MCP activity* panel and
the *Voice experience* page show each call tagged **Alexa (Echo)**, and any note you add by voice appears in the
order timeline as *via Alexa (Echo)*.

> **Honesty note.** The skill endpoint, signature verification and both interaction models are implemented and
> covered by automated tests with sample Alexa requests. I could not test them on a physical Echo from the build
> environment. The Amazon console steps below follow the current developer-console flow, but Amazon renames things
> from time to time, so follow the console if a label differs.

## What you need

* The **same Amazon account** on your Echo Plus and on the Amazon developer console (https://developer.amazon.com, free).
  Skills in development are available on devices registered to the developer account.
* Dukaan Sathi running locally (`run-demo.ps1`).
* A tunnel that gives your laptop a public **HTTPS** URL. These steps use **Cloudflare Tunnel** (`cloudflared`, free,
  no account needed for a quick tunnel):
  `winget install --id Cloudflare.cloudflared`
* Optional: a long random value for the two MCP tokens in `.env` (good practice whenever a tunnel is running).

## 1. Start Dukaan Sathi and the tunnel

```powershell
powershell -ExecutionPolicy Bypass -File .\run-demo.ps1 -Reset full
cloudflared tunnel --url http://localhost:8000
```

`cloudflared` prints a URL such as `https://random-words.trycloudflare.com`. Your skill endpoint is that URL plus
**`/alexa`**. The quick-tunnel URL **changes every time you restart cloudflared**. When it does, update the endpoint (step 4).

Through the tunnel hostname, the gateway serves only `/alexa` (and `/alexa/health`). The website API and the MCP server
are not exposed, and `/alexa` rejects anything that doesn't carry a valid Amazon signature.

Quick check in a browser: `https://random-words.trycloudflare.com/alexa/health` → `{"status":"ok",...}`.

## 2. Create the skill

1. https://developer.amazon.com/alexa/console/ask → **Create Skill**.
2. Name: `Dukaan Sathi`. Primary locale: **English (IN)**.
3. Type of experience: *Other* (or the closest option). Model: **Custom**. Hosting: **Provision your own**.
4. Template: **Start from Scratch** → Create.
5. **Add Hindi:** language dropdown (top left) → *Language settings* → **Add new language** → **Hindi (IN)** → Save.
   If your Echo uses *English / हिन्दी* multilingual mode, Alexa sends each request in the language you spoke, and the
   skill answers in that language.

## 3. Paste the interaction models

For each language (switch with the language dropdown):

1. *Build* tab → **Interaction Model → JSON Editor**.
2. Replace everything with the file from this repo:
   * English (IN): `alexa/skill-package/interactionModels/custom/en-IN.json` (invocation name **dukaan sathi**)
   * Hindi (IN): `alexa/skill-package/interactionModels/custom/hi-IN.json` (invocation name **दुकान साथी**)
3. **Save Model**, then **Build Model**. Wait for "Build successful".

Following Amazon's Hindi guidance, the Hindi model writes Hindi words in Devanagari and English trade words (order,
delivery, cement, stock) in Latin script, e.g. `मेरी {product} की delivery check करो`. Sample utterances contain no
numerals; quantities and order numbers come through `AMAZON.NUMBER` slots.

If the Hindi build rejects `AddNoteIntent` (it uses `AMAZON.SearchQuery`), delete that intent from the Hindi model and
build again. Everything else still works, and notes can still be added in English or on the website.

## 4. Set the endpoint

*Build* → **Endpoint** → **HTTPS**:

* Default Region: `https://random-words.trycloudflare.com/alexa`
* SSL certificate type: **"My development endpoint is a sub-domain of a domain that has a wildcard certificate from a
  certificate authority"**
* **Save Endpoints.**

## 5. Lock the endpoint to your skill (recommended)

Copy the **Skill ID** (`amzn1.ask.skill.…`, shown under the skill name or on the Endpoint page) into `.env`:

```
ALEXA_SKILL_ID=amzn1.ask.skill.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
ALEXA_VERIFY_SIGNATURES=true
```

Restart the gateway window (Ctrl+C, then run `.\.venv\Scripts\python.exe -m app.gateway.main` in `backend\`).

## 6. Enable testing and try the simulator

*Test* tab → set **Skill testing is enabled in: Development**. Type or say:

* English: `open dukaan sathi` → `check my cement delivery` → `yes` (reads the timeline)
* Hindi (switch the simulator language to Hindi): `दुकान साथी खोलो` → `किन orders में कमी है`

## 7. Talk to your Echo Plus

In the Alexa app → *Devices* → your Echo Plus → **Language**: *English (India)*, *हिन्दी* or *English / हिन्दी*.

| Say | What happens (MCP tools) |
|---|---|
| "Alexa, open dukaan sathi" | Welcome message |
| "Check my cement delivery" | `list_orders` → `get_order_status`: *"I found order D S 1 0 4 2 for 50 bags of OPC 53 Grade Cement. The distributor recorded 50 bags dispatched, but your receipt record shows 48 bags received — 2 bags short…"* |
| "Yes" | `get_order_timeline`: reads the latest events |
| "Where is order ten forty two" / "status of order one zero four two" | `get_order_status` |
| "Which deliveries need attention" | `list_discrepancies` → `list_orders` |
| "Give me my shop summary" | `get_dashboard_summary` |
| "Order thirty bags of PPC cement" → "Yes" | `search_products` → `validate_order` → (after yes) `create_draft_order` → `submit_order` |
| "Add a note saying two bags were missing at unloading" → "Yes" | `add_discrepancy_note` on DS-1042's open discrepancy |
| "Alexa, दुकान साथी खोलो" → "मेरी cement की delivery check करो" | Same tools, answer in Hindi |
| "किन orders में कमी है" / "मेरी दुकान का हिसाब बताओ" | Hindi answers from the same records |

Writes always need a spoken **yes**. Saying *no* or *stop* cancels and nothing is written.

## Troubleshooting

* **"There was a problem with the requested skill's response"**: look at the gateway window. `Rejected Alexa request`
  means signature or skill-ID verification failed (check `ALEXA_SKILL_ID`). No log line at all means the request never
  arrived: the tunnel URL changed, or the endpoint is missing `/alexa`.
* **Alexa opens a different skill:** say the full phrase "open dukaan sathi". If recognition struggles, change the
  invocation name in both models to something more distinctive (two or more words, lowercase, no numerals), then rebuild.
* **Hindi not responding:** check that the Hindi model is built, and that your device language is Hindi or
  English/Hindi.
* **Slow first answer:** the first request after starting may take a second while the tunnel warms up. Alexa allows
  about 8 seconds. Normal responses take a few hundred milliseconds.
* **Test without an Echo:** `backend\.venv\Scripts\python.exe scripts\alexa_local_test.py` runs the sample requests in
  `alexa/test-requests/` through the same handler.

## Alexa+ MCP pathway

Alexa+ add-ons can connect to a remote MCP server. The hackathon FAQ says some gated Alexa+ add-on tools are not
available to participants, and the rules allow an independently built, web-based simulated Alexa+ experience. This
project therefore:

* provides a real, standalone **Streamable HTTP MCP server** (`/mcp`, protocol 2025-11-25 via handshake), which is
  what an Alexa+ MCP integration would call;
* provides the web **Voice Experience** simulator and the classic **custom skill** above, both using that server;
* does **not** claim an Alexa+ connection.

If Alexa+ MCP access becomes available to you, you would additionally need: the add-on registration in the developer
console, a stable public HTTPS URL for `/mcp` (a named tunnel or a hosted deployment, see `remote-deployment.md`), the
authentication method Amazon requires for the MCP endpoint (likely OAuth 2.1 / account linking instead of the static demo
tokens), and Amazon's certification review. Follow the current *Alexa+ MCP Toolkit* documentation for the exact steps.
