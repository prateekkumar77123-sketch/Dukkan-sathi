# Demo video script (target 2:45, hard limit 3:00)

**Before recording**

1. `run-demo.ps1`, then **Demo controls → "Reset for live recording & open DS-1042"**. (CLI: `python -m app.seed live` in `backend\`.)
2. Chrome or Edge, 1440×900 or 1920×1080, zoom 100–110%. Close other tabs, and turn notifications off.
3. Allow microphone access on `127.0.0.1:5173`. Do one test phrase in the Voice experience, then reset again.
4. Optional: if your Echo is connected (`docs/alexa-echo-setup.md`), keep it next to the laptop and the *Voice experience*
   page open, so Alexa calls show up live.
5. Record with OBS Studio or the Windows Snipping Tool (Win+Shift+R). Speak clearly in English. Don't use background
   music unless you have the rights to it.

Lead with the strongest interaction: the live 48-bag receipt and the MCP-backed answer.

---

**0:00–0:15 · Problem (landing page, scroll slowly)**

> "Hardware shops and their distributors coordinate orders by phone, chat and invoices. When the confirmation, the dispatch
> and the receipt live in different places, a two-bag difference turns into a day of follow-up calls."

**0:15–0:30 · The shared record (dashboard)**

> "Dukaan Sathi gives both sides one shared order record. These numbers come live from our MCP server — here's the tool that served them."

*Point at the "Served by MCP tool get_dashboard_summary · streamable-http · 2025-11-25" strip.*

**0:30–0:55 · Natural-language order (New order or Voice experience)**

Say or type: *"Order 50 bags of OPC 53 cement."* Show the confirmation card.

> "The assistant turns plain language into a structured, validated order — exact grade, unit and stock — and nothing is sent
> until I confirm. It understands Hindi too."

*Optional 3-second cut:* type *"50 kg OPC 53 cement"* → "sold in bags, not kg".

**0:55–1:25 · Dispatch and receipt (DS-1042)**

Open DS-1042: requested 50, confirmed 50, dispatched 50, challan SBS/DC/26-27/0412.

> "The distributor confirmed and dispatched 50 bags. The shopkeeper counts 48."

Record receipt → 48 → Review (shows "2 bags below dispatch") → Record receipt.

**1:25–1:50 · The discrepancy**

> "The system compares the recorded quantities and flags a two-bag short delivery. It says where the numbers differ —
> not who's to blame. The original order, dispatch and receipt are all preserved in the timeline."

Click *Open as distributor* (or the Sharma role in the sidebar) → same order → **Acknowledge** with a note.

**1:50–2:25 · Voice + MCP (Voice experience)**

Ask: *"What happened to DS-1042?"*, then tap **Open timeline**. Switch to हिन्दी and ask *"मेरी सीमेंट डिलीवरी चेक करो"*.

> "The voice experience calls the same MCP tools over Streamable HTTP — get_order_status, get_order_timeline — you can see
> each call, its inputs and timing. Same records, in English or Hindi."

*If the Echo is connected:* "Alexa, open dukaan sathi" → "check my cement delivery". Point at the call that appears tagged
**Alexa (Echo)**. (Show the real device only if it actually works on the take. Never stage it.)

**2:25–2:45 · Resolution and close**

Back on DS-1042 → **Record resolution** → "Remaining 2 bags with next dispatch".

> "Both parties can see what was ordered, what arrived, and how the difference was settled. Dukaan Sathi — from order to
> delivery, everyone stays in the loop."

End on the dashboard or the landing hero.

---

**After recording:** upload to YouTube or Vimeo as a **publicly accessible** video, in English, under 3:00 (check the
official rules page for the exact visibility requirement). Put the
link in `SUBMISSION.md` and on Devpost.

**Second take:** Demo controls → reset for live recording. Each reset restores the same DS-1042 state.
