# Architecture

## Execution path

**Website → FastAPI API gateway → MCP client (Streamable HTTP) → self-hosted MCP server → business services → SQLite**

| Process | Port | Code | Role |
|---|---|---|---|
| React website | 5173 | `frontend/` | UI only. Calls the gateway over REST (`/api/*`, proxied by Vite). Never holds tokens, never speaks MCP. |
| API gateway | 8000 | `backend/app/gateway/` | Website API, bilingual assistant, Alexa endpoint, demo reset. Owns the MCP tokens. Every business endpoint is implemented as one or more MCP tool calls. |
| MCP server | 8001 | `backend/app/mcp_server/server.py` | Official MCP Python SDK `MCPServer`, Streamable HTTP at `/mcp` (stateless, JSON responses). 15 tools. Bearer-token auth middleware → demo role. |
| SQLite | file | `data/dukaan_sathi.db` | Single shared database, written only through the services the MCP server calls (plus the admin demo reset). |

```mermaid
sequenceDiagram
  participant B as Browser (Retailer)
  participant G as Gateway :8000
  participant M as MCP server :8001
  participant DB as SQLite
  B->>G: POST /api/orders/DS-1042/receipt {received 48}
  G->>M: initialize (protocol 2025-11-25), Bearer retailer token
  G->>M: tools/call record_delivery {order_id, lines}
  M->>DB: BEGIN; write received qty; compare 50 vs 48; insert DSC-2004; audit events; COMMIT
  M-->>G: structuredContent {order, discrepancies_created: [DSC-2004]}
  G-->>B: {data, mcp: [trace: tool, input, result, 79 ms, streamable-http, 2025-11-25]}
  Note over B: UI shows the discrepancy and the MCP trace strip
```

## Why each piece exists

* **Gateway between browser and MCP.** Tokens stay server-side. The gateway also adds the caller's channel
  (`X-Dukaan-Source: web | assistant | voice | alexa`), which the MCP server records on every audit event.
* **Stateless Streamable HTTP + JSON responses.** Each tool call is independent, which suits request/response
  business operations and keeps horizontal scaling simple. The gateway opens a short-lived client session per request
  (≈ 20–100 ms locally) and times out after `MCP_TIMEOUT_SECONDS`.
* **Protocol.** With `MCP_CLIENT_MODE=legacy` (default) the gateway uses the initialize handshake and negotiates
  **2025-11-25**, the hackathon baseline. The SDK also serves the newer **2026-07-28** per-request envelope (`auto` mode).
* **Typed tools.** Inputs are Pydantic models (`LineInput`, `ReceiptLineInput`…). Outputs are Pydantic models, so
  every tool publishes an `outputSchema` and returns `structuredContent`. Business errors become `isError` results
  carrying a JSON error with a stable `code`.

## Business rules (deterministic)

`backend/app/domain/rules.py`

* Canonical units per product (`bag`, `piece`, `length`, `kg`, `pack`, `metre`). Conversion only through an explicit
  per-product factor (100 screws = 1 pack, 3 m = 1 conduit length), and only to whole units. Anything else is rejected
  ("50 kg" is never "50 bags").
* Quantity validation: finite, non-negative, whole numbers for discrete units, 0.5 kg steps, a per-line ceiling.
* `compare_line(confirmed, dispatched, received, damaged)` → `match | short | excess | awaiting_dispatch | awaiting_receipt`,
  with neutral wording ("…2 bags below the recorded dispatched quantity… Cause not yet determined").

`backend/app/services/orders.py`: state machine

```
draft ──submit (retailer)──► pending_confirmation ──confirm (distributor)──► confirmed
confirmed ──record_dispatch (distributor)──► in_transit ──record_delivery (retailer)──► delivered | needs_review
needs_review ──resolve all discrepancies──► resolved        delivered ──report_discrepancy──► needs_review
```

Each transition runs in `BEGIN IMMEDIATE … COMMIT` and writes audit events. Confirmed, dispatched and received
quantities are written once. Resolutions are separate rows, so the evidence is never edited.

## Permissions

`backend/app/domain/actors.py`: the bearer token maps to `retailer` (Raj Hardware Store) or `distributor` (Sharma
Building Supplies). The service layer checks the role for every write, and scopes reads (a distributor cannot see
the retailer's unsent drafts). This is demonstration-grade; see `remote-deployment.md` for production gaps.

## Assistant

`backend/app/gateway/assistant/`

* `nlu.py`: rule-based intent parser for English, Devanagari Hindi and Hinglish (number words such as *पचास*, trade
  words such as *बोरी*, *सरिया*, order ids like *डीएस 1042*). It extracts intent and parameters only.
* `engine.py`: maps intents to MCP tool calls, builds the answer only from tool results, in the user's language,
  plus cards and follow-up actions. Writes return a `pending_action`; `/api/assistant/confirm` executes it.
* No external LLM is connected. A provider that turns text into the same `Intent` structure could be added without
  touching business logic.

## Alexa

`backend/app/gateway/alexa/`

* `verifier.py`: Amazon request verification: certificate URL rules, chain validation to a trusted root with SAN
  `echo-api.amazon.com`, `Signature-256` (RSA/SHA-256 over the raw body), 150-second timestamp window, optional skill ID.
* `handler.py`: maps custom-skill intents (en-IN / hi-IN) to the assistant engine, keeps `pending_action` and the last
  order in session attributes for yes/no and follow-ups, and returns SSML that speaks ids digit by digit.

## Frontend

React 19, TypeScript, Vite 8, Tailwind 4, lucide icons, self-hosted Inter and Noto Sans Devanagari fonts.
`useApi` re-fetches when the gateway's `data_version` changes, so a write from another tab, role or the Echo updates
the page within about 2 seconds. The live *MCP activity* feed polls `/api/mcp/activity`.
